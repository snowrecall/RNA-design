#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGGUCUGCAAGGGCCA&name=seq365&top=100"
./mcfold.static.exe >seq365_P5c.dada
