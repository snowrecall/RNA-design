#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGGGGGCAACCUUUA&name=seq484&top=100"
./mcfold.static.exe >seq484_p5clike_opposite_direction.data
