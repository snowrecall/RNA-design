#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUUUUUGCAAAAGAGA&name=seq206&top=100"
./mcfold.static.exe >seq206_p5clike_opposite_direction.data
