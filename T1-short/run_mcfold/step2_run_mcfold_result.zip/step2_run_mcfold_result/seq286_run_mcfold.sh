#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGAGAAGCAAUUUUCA&name=seq286&top=100"
./mcfold.static.exe >seq286_P5c.dada
