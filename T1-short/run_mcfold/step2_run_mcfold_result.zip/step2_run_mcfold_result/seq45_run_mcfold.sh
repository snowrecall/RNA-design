#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGUUUUUGCAAGAGGAA&name=seq45&top=100"
./mcfold.static.exe >seq45_P5c.dada
