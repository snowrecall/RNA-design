#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGAUCUUGCAAGGGAUA&name=seq190&explore=50&top=100"
./mcfold.static.exe >seq190_like_p5c_shift_2bp_type3.data
