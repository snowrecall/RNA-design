#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGCUUUCGCAAGGGGGA&name=seq235&top=100"
./mcfold.static.exe >seq235_P5c.dada
