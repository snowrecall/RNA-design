#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUUCUUGCAAAGGGAA&name=seq96&top=100"
./mcfold.static.exe >seq96_p5clike_opposite_direction.data
