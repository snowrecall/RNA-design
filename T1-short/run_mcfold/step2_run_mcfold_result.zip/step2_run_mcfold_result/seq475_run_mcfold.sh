#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGGGCCGCAAGGUUCA&name=seq475&top=100"
./mcfold.static.exe >seq475_P5c.dada
