#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGGAGGCAACUUUCA&name=seq181&top=100"
./mcfold.static.exe >seq181_p5clike_opposite_direction.data
