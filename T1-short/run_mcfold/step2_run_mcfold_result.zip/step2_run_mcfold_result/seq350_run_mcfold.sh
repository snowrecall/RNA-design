#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGGGAGGCAAUUCCCA&name=seq350&top=100"
./mcfold.static.exe >seq350_P5c.dada
