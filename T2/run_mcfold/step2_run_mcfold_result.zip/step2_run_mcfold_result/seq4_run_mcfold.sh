#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUUUUAGCAAUGAAAA&name=seq4&top=100"
./mcfold.static.exe >seq4_p5clike_opposite_direction.data
