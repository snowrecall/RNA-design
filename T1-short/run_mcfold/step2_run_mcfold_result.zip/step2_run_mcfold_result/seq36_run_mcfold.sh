#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGUUUUCGCAAGGAGAA&name=seq36&top=100"
./mcfold.static.exe >seq36_P5c.dada
