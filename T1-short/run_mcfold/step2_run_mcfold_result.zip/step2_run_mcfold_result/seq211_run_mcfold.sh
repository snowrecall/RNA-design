#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGCCUUUGCAAGAGGGA&name=seq211&top=100"
./mcfold.static.exe >seq211_P5c.dada
