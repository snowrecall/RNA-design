#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGCCUUUGCAAGGGGGA&name=seq216&top=100"
./mcfold.static.exe >seq216_P5c.dada
