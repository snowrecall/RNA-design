#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGGGAAGCAAUUUUCA&name=seq471&top=100"
./mcfold.static.exe >seq471_P5c.dada
