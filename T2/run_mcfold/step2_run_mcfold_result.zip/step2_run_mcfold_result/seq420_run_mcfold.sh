#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUGAAGGCAAUUUUGA&name=seq420&top=100"
./mcfold.static.exe >seq420_p5clike_opposite_direction.data
