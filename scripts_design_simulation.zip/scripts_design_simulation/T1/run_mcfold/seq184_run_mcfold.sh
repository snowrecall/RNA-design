#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGCGCGCACGGAAGGGCAACUUUCAAACCGCGCC&name=seq184&top=100"
./mcfold.static.exe >seq184_5bp_267_GCstem_3nt_bulges.data
