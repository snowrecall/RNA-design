#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGCGCGCACGGAAGGGCAACUUUCAACCCGCGCC&name=seq190&top=100"
./mcfold.static.exe >seq190_5bp_267_GCstem_3nt_bulges.data
