#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGGCUUGCAAAGGUCA&name=seq437&top=100"
./mcfold.static.exe >seq437_P5c.dada
