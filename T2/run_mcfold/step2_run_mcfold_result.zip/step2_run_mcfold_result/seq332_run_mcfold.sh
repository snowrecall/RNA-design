#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUCGGGGCAAUUUGGA&name=seq332&top=100"
./mcfold.static.exe >seq332_p5clike_opposite_direction.data
