#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGGGGUGCAAACUCCA&name=seq378&top=100"
./mcfold.static.exe >seq378_P5c.dada
