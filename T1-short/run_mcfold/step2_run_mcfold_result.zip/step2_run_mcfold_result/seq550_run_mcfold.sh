#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGUUUUGCAAAAGAUA&name=seq550&top=100"
./mcfold.static.exe >seq550_P5c.dada
