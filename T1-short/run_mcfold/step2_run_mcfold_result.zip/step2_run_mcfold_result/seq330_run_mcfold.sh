#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGGACCGCAAGGUCCA&name=seq330&top=100"
./mcfold.static.exe >seq330_P5c.dada
