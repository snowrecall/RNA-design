#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGCGCGCCUGGAAGGGCAACUUUCACCCCGCGCC&name=seq213&top=100"
./mcfold.static.exe >seq213_5bp_267_GCstem_3nt_bulges.data
