#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGAUUUCGCAAGAGGUA&name=seq123&top=100"
./mcfold.static.exe >seq123_P5c.dada
