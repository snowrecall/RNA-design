#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGCGCGCAAGGAAGGGCAACUUUCACCCCGCGCC&name=seq188&top=100"
./mcfold.static.exe >seq188_5bp_267_GCstem_3nt_bulges.data
