#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUGGAGGCAACUUCGA&name=seq338&top=100"
./mcfold.static.exe >seq338_p5clike_opposite_direction.data
