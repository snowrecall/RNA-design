#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGGGACGCAAGUCUCA&name=seq444&top=100"
./mcfold.static.exe >seq444_P5c.dada
