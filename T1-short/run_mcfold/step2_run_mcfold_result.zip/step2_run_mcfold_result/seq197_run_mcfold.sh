#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGAGGGUGCAAGCUUUA&name=seq197&top=100"
./mcfold.static.exe >seq197_P5c.dada
