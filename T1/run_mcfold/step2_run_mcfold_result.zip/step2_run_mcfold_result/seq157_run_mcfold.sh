#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGCGCGCUAGGAAGGGCAACUUUCAACUCGCGCC&name=seq157&top=100"
./mcfold.static.exe >seq157_5bp_267_GCstem_3nt_bulges.data
