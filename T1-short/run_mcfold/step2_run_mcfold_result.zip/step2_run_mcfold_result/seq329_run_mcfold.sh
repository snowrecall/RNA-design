#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGGAAGGCAAUUUCCA&name=seq329&top=100"
./mcfold.static.exe >seq329_P5c.dada
