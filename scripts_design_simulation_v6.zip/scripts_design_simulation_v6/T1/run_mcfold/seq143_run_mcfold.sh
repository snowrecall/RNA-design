#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGCGCGCCCGGAAGGGCAACUUUCAUCACGCGCC&name=seq143&top=100"
./mcfold.static.exe >seq143_5bp_267_GCstem_3nt_bulges.data
