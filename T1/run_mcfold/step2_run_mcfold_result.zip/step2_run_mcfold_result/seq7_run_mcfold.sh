#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGCGCGAAAGGAAGGGCAACUUUCAACACGCGCC&name=seq7&top=100"
./mcfold.static.exe >seq7_5bp_267_GCstem_3nt_bulges.data
