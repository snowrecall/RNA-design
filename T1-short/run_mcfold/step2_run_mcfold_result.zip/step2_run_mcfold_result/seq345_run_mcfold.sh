#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGGGUCGCAAGACCCA&name=seq345&top=100"
./mcfold.static.exe >seq345_P5c.dada
