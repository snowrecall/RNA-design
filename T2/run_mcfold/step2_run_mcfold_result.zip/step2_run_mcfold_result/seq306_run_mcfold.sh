#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUCUUGGCAAUAGGGA&name=seq306&top=100"
./mcfold.static.exe >seq306_p5clike_opposite_direction.data
