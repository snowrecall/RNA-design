#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGUUUUUGCAAGAAAGA&name=seq491&top=100"
./mcfold.static.exe >seq491_P5c.dada
