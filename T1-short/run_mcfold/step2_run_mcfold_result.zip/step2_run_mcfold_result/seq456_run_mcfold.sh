#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGGGUUGCAAGGCUCA&name=seq456&top=100"
./mcfold.static.exe >seq456_P5c.dada
