#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGCGCGCUUGGAAGGGCAACUUUCACCCCGCGCC&name=seq195&top=100"
./mcfold.static.exe >seq195_5bp_267_GCstem_3nt_bulges.data
