#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=UGCAUGCGCAAGUGUGA&name=seq126&explore=50&top=100"
./mcfold.static.exe >seq126_like_p5c_shift_2bp_type3.data
