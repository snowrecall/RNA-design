#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGAGGUUGCAAGGCUUA&name=seq172&top=100"
./mcfold.static.exe >seq172_P5c.dada
