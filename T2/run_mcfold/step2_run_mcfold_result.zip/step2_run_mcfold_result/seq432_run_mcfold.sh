#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUGGAGGCAACUUUGA&name=seq432&top=100"
./mcfold.static.exe >seq432_p5clike_opposite_direction.data
