#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGGUUUGCAAGAGCCA&name=seq363&top=100"
./mcfold.static.exe >seq363_P5c.dada
