#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUGGGGGCAACUUCAA&name=seq58&top=100"
./mcfold.static.exe >seq58_p5clike_opposite_direction.data
