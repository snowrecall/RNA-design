#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUCCCUGCAAAGGGGA&name=seq286&top=100"
./mcfold.static.exe >seq286_p5clike_opposite_direction.data
