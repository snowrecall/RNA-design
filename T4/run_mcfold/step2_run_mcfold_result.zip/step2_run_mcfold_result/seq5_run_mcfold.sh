#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGAGGUGCUUCGGCCCUUCC&name=seq5&explore=50&top=100"
./mcfold.static.exe >seq5_p5clike_1bulgeout.data
