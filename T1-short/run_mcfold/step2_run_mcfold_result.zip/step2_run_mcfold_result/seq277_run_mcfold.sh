#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGAUUUGCAAGAGUCA&name=seq277&top=100"
./mcfold.static.exe >seq277_P5c.dada
