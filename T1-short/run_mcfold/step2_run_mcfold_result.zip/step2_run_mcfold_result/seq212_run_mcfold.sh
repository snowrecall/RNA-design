#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGCCUCCGCAAGGGGGA&name=seq212&top=100"
./mcfold.static.exe >seq212_P5c.dada
