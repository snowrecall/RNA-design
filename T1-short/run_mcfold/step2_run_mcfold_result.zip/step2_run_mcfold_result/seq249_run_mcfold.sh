#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGUUUCGCAAGAGACA&name=seq249&top=100"
./mcfold.static.exe >seq249_P5c.dada
