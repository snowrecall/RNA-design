#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGCGAAGGGCAACUUUCGUA&name=seq3&explore=50&top=100"
./mcfold.static.exe >seq3_5bp_267_add2bp_all_possible.data
