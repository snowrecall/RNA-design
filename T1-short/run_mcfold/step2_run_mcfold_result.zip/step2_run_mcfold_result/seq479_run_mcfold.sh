#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGGGGCGCAAGCUUCA&name=seq479&top=100"
./mcfold.static.exe >seq479_P5c.dada
