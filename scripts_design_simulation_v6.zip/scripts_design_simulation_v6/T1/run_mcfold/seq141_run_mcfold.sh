#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGCGCGCCUGGAAGGGCAACUUUCACCACGCGCC&name=seq141&top=100"
./mcfold.static.exe >seq141_5bp_267_GCstem_3nt_bulges.data
