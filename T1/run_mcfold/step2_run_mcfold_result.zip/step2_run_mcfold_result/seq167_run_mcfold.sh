#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGCGCGCCCGGAAGGGCAACUUUCAUAUCGCGCC&name=seq167&top=100"
./mcfold.static.exe >seq167_5bp_267_GCstem_3nt_bulges.data
