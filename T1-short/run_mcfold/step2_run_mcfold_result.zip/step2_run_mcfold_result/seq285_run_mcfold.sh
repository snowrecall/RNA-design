#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGAGUUGCAAGAUUCA&name=seq285&top=100"
./mcfold.static.exe >seq285_P5c.dada
