#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGCGCGCCCGGAAGGGCAACUUUCAUUCCGCGCC&name=seq209&top=100"
./mcfold.static.exe >seq209_5bp_267_GCstem_3nt_bulges.data
