#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUUGAAGCAAUUUAGA&name=seq228&top=100"
./mcfold.static.exe >seq228_p5clike_opposite_direction.data
