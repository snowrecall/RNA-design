#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUUGGGGCAACUUAAA&name=seq46&top=100"
./mcfold.static.exe >seq46_p5clike_opposite_direction.data
