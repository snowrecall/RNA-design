#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGAGUUGCAAGGUUCA&name=seq299&top=100"
./mcfold.static.exe >seq299_P5c.dada
