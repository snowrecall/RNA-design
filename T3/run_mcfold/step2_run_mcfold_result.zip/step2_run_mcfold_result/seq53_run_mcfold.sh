#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=UGUAUUCGCAAGGAUAA&name=seq53&explore=50&top=100"
./mcfold.static.exe >seq53_like_p5c_shift_2bp_type3.data
