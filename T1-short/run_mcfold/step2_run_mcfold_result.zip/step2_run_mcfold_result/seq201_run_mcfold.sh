#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGAGGGUGCAAAUUUUA&name=seq201&top=100"
./mcfold.static.exe >seq201_P5c.dada
