#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUUUUGGCAAUAAGAA&name=seq63&top=100"
./mcfold.static.exe >seq63_p5clike_opposite_direction.data
