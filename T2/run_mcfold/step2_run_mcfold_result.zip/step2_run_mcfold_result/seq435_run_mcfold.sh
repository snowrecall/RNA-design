#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUGGGGGCAAUCUUGA&name=seq435&top=100"
./mcfold.static.exe >seq435_p5clike_opposite_direction.data
