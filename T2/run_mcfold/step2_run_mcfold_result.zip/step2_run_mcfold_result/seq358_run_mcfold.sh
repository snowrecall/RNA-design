#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUUUGGGCAACUAGGA&name=seq358&top=100"
./mcfold.static.exe >seq358_p5clike_opposite_direction.data
