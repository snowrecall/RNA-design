#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGGAGAGCAAUUUUCA&name=seq430&top=100"
./mcfold.static.exe >seq430_P5c.dada
