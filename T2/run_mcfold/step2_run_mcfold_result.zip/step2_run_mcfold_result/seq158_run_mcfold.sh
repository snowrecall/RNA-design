#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGGGGGCAACUCCCA&name=seq158&top=100"
./mcfold.static.exe >seq158_p5clike_opposite_direction.data
