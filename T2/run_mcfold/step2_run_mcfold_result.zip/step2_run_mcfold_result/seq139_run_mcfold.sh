#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUGAAGGCAAUUUUAA&name=seq139&top=100"
./mcfold.static.exe >seq139_p5clike_opposite_direction.data
