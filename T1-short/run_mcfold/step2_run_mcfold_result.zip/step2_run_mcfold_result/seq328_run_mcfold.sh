#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGGAAUGCAAGUUCCA&name=seq328&top=100"
./mcfold.static.exe >seq328_P5c.dada
