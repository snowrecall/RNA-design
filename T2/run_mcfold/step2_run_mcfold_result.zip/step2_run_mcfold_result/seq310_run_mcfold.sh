#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUCUCUGCAAAGGGGA&name=seq310&top=100"
./mcfold.static.exe >seq310_p5clike_opposite_direction.data
