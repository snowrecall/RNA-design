#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGAAGUGCUUCGGCCUUUCC&name=seq4&explore=50&top=100"
./mcfold.static.exe >seq4_p5clike_1bulgeout.data
