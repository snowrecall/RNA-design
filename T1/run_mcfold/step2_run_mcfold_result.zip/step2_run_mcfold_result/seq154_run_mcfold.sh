#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGCGCGCACGGAAGGGCAACUUUCAACUCGCGCC&name=seq154&top=100"
./mcfold.static.exe >seq154_5bp_267_GCstem_3nt_bulges.data
