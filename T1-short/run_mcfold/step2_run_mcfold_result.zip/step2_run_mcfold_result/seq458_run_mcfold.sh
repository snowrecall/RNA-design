#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGGGGAGCAAUUCUCA&name=seq458&top=100"
./mcfold.static.exe >seq458_P5c.dada
