#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUCCCUGCAAGGGGGA&name=seq289&top=100"
./mcfold.static.exe >seq289_p5clike_opposite_direction.data
