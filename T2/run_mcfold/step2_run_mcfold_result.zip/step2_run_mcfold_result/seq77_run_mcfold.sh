#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUUAGGGCAACCUGAA&name=seq77&top=100"
./mcfold.static.exe >seq77_p5clike_opposite_direction.data
