#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGCGCGCCCGGAAGGGCAACUUUCAUCUCGCGCC&name=seq179&top=100"
./mcfold.static.exe >seq179_5bp_267_GCstem_3nt_bulges.data
