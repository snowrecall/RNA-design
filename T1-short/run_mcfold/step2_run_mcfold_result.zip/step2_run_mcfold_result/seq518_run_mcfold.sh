#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGUCUUCGCAAGGGGGA&name=seq518&top=100"
./mcfold.static.exe >seq518_P5c.dada
