#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUUAGGGCAAUUUGAA&name=seq81&top=100"
./mcfold.static.exe >seq81_p5clike_opposite_direction.data
