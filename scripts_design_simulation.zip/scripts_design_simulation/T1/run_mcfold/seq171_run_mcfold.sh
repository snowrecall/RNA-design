#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGCGCGCCUGGAAGGGCAACUUUCACUUCGCGCC&name=seq171&top=100"
./mcfold.static.exe >seq171_5bp_267_GCstem_3nt_bulges.data
