#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUUUUCGCAAGGAGGA&name=seq353&top=100"
./mcfold.static.exe >seq353_p5clike_opposite_direction.data
