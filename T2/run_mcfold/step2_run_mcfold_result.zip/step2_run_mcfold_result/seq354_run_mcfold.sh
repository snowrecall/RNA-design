#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUUUUGGCAACGAGGA&name=seq354&top=100"
./mcfold.static.exe >seq354_p5clike_opposite_direction.data
