#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUUUGGGCAACUGAAA&name=seq38&top=100"
./mcfold.static.exe >seq38_p5clike_opposite_direction.data
