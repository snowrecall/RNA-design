#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUAAAGGCAACUUUGA&name=seq236&top=100"
./mcfold.static.exe >seq236_p5clike_opposite_direction.data
