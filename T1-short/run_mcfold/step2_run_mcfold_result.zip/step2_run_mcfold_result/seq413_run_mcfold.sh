#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGGUUCGCAAGAAUCA&name=seq413&top=100"
./mcfold.static.exe >seq413_P5c.dada
