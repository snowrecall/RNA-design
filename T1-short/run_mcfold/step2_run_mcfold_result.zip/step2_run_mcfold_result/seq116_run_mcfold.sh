#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGAUUUUGCAAGGAGUA&name=seq116&top=100"
./mcfold.static.exe >seq116_P5c.dada
