#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGGAAGGGGCAACCUUUCUA&name=seq8&explore=50&top=100"
./mcfold.static.exe >seq8_5bp_267_add2bp_all_possible.data
