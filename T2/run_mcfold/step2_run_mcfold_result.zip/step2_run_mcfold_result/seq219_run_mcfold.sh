#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUUUGGGCAAUCGAGA&name=seq219&top=100"
./mcfold.static.exe >seq219_p5clike_opposite_direction.data
