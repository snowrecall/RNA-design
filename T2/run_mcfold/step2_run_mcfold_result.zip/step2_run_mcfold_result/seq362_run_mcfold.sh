#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUUAAGGCAAUUUGGA&name=seq362&top=100"
./mcfold.static.exe >seq362_p5clike_opposite_direction.data
