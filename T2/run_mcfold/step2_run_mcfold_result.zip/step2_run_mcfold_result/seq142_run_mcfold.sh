#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUGAGAGCAAUUUUAA&name=seq142&top=100"
./mcfold.static.exe >seq142_p5clike_opposite_direction.data
