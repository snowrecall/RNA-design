#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUCAAGGCAACUUGGA&name=seq272&top=100"
./mcfold.static.exe >seq272_p5clike_opposite_direction.data
