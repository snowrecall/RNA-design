#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGAGGCCGCAAGGCUUA&name=seq163&top=100"
./mcfold.static.exe >seq163_P5c.dada
