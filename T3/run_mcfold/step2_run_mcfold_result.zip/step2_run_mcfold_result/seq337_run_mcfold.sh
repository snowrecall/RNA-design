#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGGGGAGCAAUCUCCA&name=seq337&explore=50&top=100"
./mcfold.static.exe >seq337_like_p5c_shift_2bp_type3.data
