#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGAAGGGCAAUCUUUA&name=seq441&top=100"
./mcfold.static.exe >seq441_p5clike_opposite_direction.data
