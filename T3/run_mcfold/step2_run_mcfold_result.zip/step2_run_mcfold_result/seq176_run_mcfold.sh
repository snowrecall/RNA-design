#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGUGCUUGCAAGAGCAA&name=seq176&explore=50&top=100"
./mcfold.static.exe >seq176_like_p5c_shift_2bp_type3.data
