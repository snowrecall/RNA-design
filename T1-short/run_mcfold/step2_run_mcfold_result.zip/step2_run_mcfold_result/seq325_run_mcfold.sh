#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGGUUUGCAAGGACCA&name=seq325&top=100"
./mcfold.static.exe >seq325_P5c.dada
