#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGUUUUGCAAAGAACA&name=seq240&top=100"
./mcfold.static.exe >seq240_P5c.dada
