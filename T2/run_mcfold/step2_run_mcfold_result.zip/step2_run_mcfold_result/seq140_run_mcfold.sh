#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUGAGGGCAACCUUAA&name=seq140&top=100"
./mcfold.static.exe >seq140_p5clike_opposite_direction.data
