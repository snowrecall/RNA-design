#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGGAAAGCAAUUUUCA&name=seq420&top=100"
./mcfold.static.exe >seq420_P5c.dada
