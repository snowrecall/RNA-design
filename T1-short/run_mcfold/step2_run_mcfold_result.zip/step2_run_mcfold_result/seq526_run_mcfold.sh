#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGUUUUCGCAAGGAGGA&name=seq526&top=100"
./mcfold.static.exe >seq526_P5c.dada
