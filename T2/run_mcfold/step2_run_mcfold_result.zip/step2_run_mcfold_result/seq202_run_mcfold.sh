#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUUGGGGCAAUCCAGA&name=seq202&top=100"
./mcfold.static.exe >seq202_p5clike_opposite_direction.data
