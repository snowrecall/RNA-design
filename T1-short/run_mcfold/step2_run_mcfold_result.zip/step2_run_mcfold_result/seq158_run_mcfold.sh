#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGAGGUUGCAAGACUUA&name=seq158&top=100"
./mcfold.static.exe >seq158_P5c.dada
