#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGGCUCGCAAGGGCCA&name=seq342&top=100"
./mcfold.static.exe >seq342_P5c.dada
