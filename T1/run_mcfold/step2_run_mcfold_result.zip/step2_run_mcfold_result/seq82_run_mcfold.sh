#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGCGCGUACGGAAGGGCAACUUUCAACCCGCGCC&name=seq82&top=100"
./mcfold.static.exe >seq82_5bp_267_GCstem_3nt_bulges.data
