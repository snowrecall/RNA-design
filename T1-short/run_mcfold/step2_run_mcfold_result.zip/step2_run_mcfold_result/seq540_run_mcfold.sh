#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGUUCCGCAAGGAAUA&name=seq540&top=100"
./mcfold.static.exe >seq540_P5c.dada
