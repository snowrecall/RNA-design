#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGGAUUGCAAAGUCCA&name=seq332&top=100"
./mcfold.static.exe >seq332_P5c.dada
