#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGGGAAGGGCAACUUUCUUA&name=seq23&explore=50&top=100"
./mcfold.static.exe >seq23_5bp_267_add2bp_all_possible.data
