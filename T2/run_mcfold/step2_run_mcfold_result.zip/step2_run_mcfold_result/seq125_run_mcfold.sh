#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUUUUUGCAAAGGGAA&name=seq125&top=100"
./mcfold.static.exe >seq125_p5clike_opposite_direction.data
