#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGCUUUUGCAAGAAGGA&name=seq219&top=100"
./mcfold.static.exe >seq219_P5c.dada
