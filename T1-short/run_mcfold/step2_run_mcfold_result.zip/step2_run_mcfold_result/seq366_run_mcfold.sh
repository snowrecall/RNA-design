#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGGUUUGCAAAGGCCA&name=seq366&top=100"
./mcfold.static.exe >seq366_P5c.dada
