#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGCCUUUGCAAAGGGGA&name=seq214&top=100"
./mcfold.static.exe >seq214_P5c.dada
