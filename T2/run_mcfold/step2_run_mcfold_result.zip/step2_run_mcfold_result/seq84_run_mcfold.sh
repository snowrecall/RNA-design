#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUUCUUGCAAGAGGAA&name=seq84&top=100"
./mcfold.static.exe >seq84_p5clike_opposite_direction.data
