#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUGGAAGCAAUUUCGA&name=seq337&top=100"
./mcfold.static.exe >seq337_p5clike_opposite_direction.data
