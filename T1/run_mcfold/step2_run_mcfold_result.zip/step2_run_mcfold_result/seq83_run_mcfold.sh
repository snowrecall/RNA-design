#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGCGCGUACGGAAGGGCAACUUUCAUCCCGCGCC&name=seq83&top=100"
./mcfold.static.exe >seq83_5bp_267_GCstem_3nt_bulges.data
