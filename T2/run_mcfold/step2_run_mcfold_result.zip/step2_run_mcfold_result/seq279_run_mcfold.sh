#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUCCUUGCAAAAGGGA&name=seq279&top=100"
./mcfold.static.exe >seq279_p5clike_opposite_direction.data
