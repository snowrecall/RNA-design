#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGUUUUCGCAAGAGAGA&name=seq503&top=100"
./mcfold.static.exe >seq503_P5c.dada
