#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGUCCUGCAAGGGGCA&name=seq401&top=100"
./mcfold.static.exe >seq401_P5c.dada
