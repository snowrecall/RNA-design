#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGUCCUGCAAGGGAUA&name=seq546&top=100"
./mcfold.static.exe >seq546_P5c.dada
