#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUUUGGGCAAUCAGGA&name=seq350&top=100"
./mcfold.static.exe >seq350_p5clike_opposite_direction.data
