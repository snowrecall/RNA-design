#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGUUUCUGCAAGGAAGA&name=seq493&top=100"
./mcfold.static.exe >seq493_P5c.dada
