#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=UGUAGGGGCAACUUUAA&name=seq71&explore=50&top=100"
./mcfold.static.exe >seq71_like_p5c_shift_2bp_type3.data
