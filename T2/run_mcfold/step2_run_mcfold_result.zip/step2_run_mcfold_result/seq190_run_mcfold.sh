#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUUUGGGCAACCAAGA&name=seq190&top=100"
./mcfold.static.exe >seq190_p5clike_opposite_direction.data
