#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUUCAGGCAAUUGGAA&name=seq88&top=100"
./mcfold.static.exe >seq88_p5clike_opposite_direction.data
