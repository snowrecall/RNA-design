#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGAGGAGGCAAUUCUUA&name=seq162&top=100"
./mcfold.static.exe >seq162_P5c.dada
