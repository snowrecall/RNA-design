#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGGUCCGCAAGGACCA&name=seq321&top=100"
./mcfold.static.exe >seq321_P5c.dada
