#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGAGGUGCAAGCUUCA&name=seq296&top=100"
./mcfold.static.exe >seq296_P5c.dada
