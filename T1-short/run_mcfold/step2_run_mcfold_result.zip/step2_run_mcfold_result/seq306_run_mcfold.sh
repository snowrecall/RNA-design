#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGCCCUGCAAGGGGCA&name=seq306&top=100"
./mcfold.static.exe >seq306_P5c.dada
