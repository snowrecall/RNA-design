#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGUUUCCGCAAGGAGAA&name=seq34&top=100"
./mcfold.static.exe >seq34_P5c.dada
