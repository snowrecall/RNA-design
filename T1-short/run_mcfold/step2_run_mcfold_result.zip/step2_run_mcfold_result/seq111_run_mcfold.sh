#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGAUUUUGCAAGAAGUA&name=seq111&top=100"
./mcfold.static.exe >seq111_P5c.dada
