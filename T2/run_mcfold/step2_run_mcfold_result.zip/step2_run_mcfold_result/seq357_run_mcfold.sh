#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUUUGAGCAAUUAGGA&name=seq357&top=100"
./mcfold.static.exe >seq357_p5clike_opposite_direction.data
