#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGCGCGACAGGAAGGGCAACUUUCAACACGCGCC&name=seq31&top=100"
./mcfold.static.exe >seq31_5bp_267_GCstem_3nt_bulges.data
