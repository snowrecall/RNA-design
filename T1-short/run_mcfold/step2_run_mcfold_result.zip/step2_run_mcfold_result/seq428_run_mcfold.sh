#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGGAUUGCAAGGUUCA&name=seq428&top=100"
./mcfold.static.exe >seq428_P5c.dada
