#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGUUCCUGCAAGGGGGA&name=seq529&top=100"
./mcfold.static.exe >seq529_P5c.dada
