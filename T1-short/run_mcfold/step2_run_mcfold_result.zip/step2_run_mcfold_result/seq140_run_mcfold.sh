#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGAGAAGGCAAUUUUUA&name=seq140&top=100"
./mcfold.static.exe >seq140_P5c.dada
