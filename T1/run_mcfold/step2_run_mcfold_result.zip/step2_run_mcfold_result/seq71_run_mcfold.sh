#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGCGCGACCGGAAGGGCAACUUUCAUCCCGCGCC&name=seq71&top=100"
./mcfold.static.exe >seq71_5bp_267_GCstem_3nt_bulges.data
