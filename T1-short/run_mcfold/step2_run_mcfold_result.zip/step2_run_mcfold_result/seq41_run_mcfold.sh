#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGUUCUCGCAAGGGGAA&name=seq41&top=100"
./mcfold.static.exe >seq41_P5c.dada
