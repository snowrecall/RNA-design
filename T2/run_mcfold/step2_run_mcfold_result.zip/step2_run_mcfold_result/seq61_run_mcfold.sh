#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUUUUGGCAACAAGAA&name=seq61&top=100"
./mcfold.static.exe >seq61_p5clike_opposite_direction.data
