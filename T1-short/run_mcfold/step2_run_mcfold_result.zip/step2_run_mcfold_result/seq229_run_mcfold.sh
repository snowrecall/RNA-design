#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGCUUUUGCAAAAGGGA&name=seq229&top=100"
./mcfold.static.exe >seq229_P5c.dada
