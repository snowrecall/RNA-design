#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGAGGUGCAAGUUUCA&name=seq304&top=100"
./mcfold.static.exe >seq304_P5c.dada
