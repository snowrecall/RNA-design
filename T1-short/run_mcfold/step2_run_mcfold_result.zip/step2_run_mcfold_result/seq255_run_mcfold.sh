#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGUUUUGCAAGGGACA&name=seq255&top=100"
./mcfold.static.exe >seq255_P5c.dada
