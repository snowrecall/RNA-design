#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGAUUUUGCAAGAGGUA&name=seq124&top=100"
./mcfold.static.exe >seq124_P5c.dada
