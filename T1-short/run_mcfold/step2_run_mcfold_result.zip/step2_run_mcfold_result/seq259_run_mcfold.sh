#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGAACCGCAAGGUUCA&name=seq259&top=100"
./mcfold.static.exe >seq259_P5c.dada
