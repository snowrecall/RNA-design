#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGCGCGACAGGAAGGGCAACUUUCACACCGCGCC&name=seq56&top=100"
./mcfold.static.exe >seq56_5bp_267_GCstem_3nt_bulges.data
