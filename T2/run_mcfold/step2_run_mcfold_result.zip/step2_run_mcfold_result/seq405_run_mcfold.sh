#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUUUCCGCAAGGGGGA&name=seq405&top=100"
./mcfold.static.exe >seq405_p5clike_opposite_direction.data
