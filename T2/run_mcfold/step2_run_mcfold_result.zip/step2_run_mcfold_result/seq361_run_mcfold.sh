#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUUAAGGCAACUUGGA&name=seq361&top=100"
./mcfold.static.exe >seq361_p5clike_opposite_direction.data
