#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGACUCUGCAAGGGGUA&name=seq105&top=100"
./mcfold.static.exe >seq105_P5c.dada
