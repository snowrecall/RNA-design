#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUUUCUGCAAGGGAAA&name=seq28&top=100"
./mcfold.static.exe >seq28_p5clike_opposite_direction.data
