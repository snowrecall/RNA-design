#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGUUUUUGCAAAGGAGA&name=seq506&top=100"
./mcfold.static.exe >seq506_P5c.dada
