#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGGGGUGCAAGUCUCA&name=seq460&top=100"
./mcfold.static.exe >seq460_P5c.dada
