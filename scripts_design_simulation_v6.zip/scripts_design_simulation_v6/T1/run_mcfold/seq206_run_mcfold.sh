#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGCGCGCCAGGAAGGGCAACUUUCACUCCGCGCC&name=seq206&top=100"
./mcfold.static.exe >seq206_5bp_267_GCstem_3nt_bulges.data
