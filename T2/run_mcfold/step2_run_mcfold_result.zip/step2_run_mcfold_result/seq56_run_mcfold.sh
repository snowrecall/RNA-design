#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUGGGGGCAAUCUCAA&name=seq56&top=100"
./mcfold.static.exe >seq56_p5clike_opposite_direction.data
