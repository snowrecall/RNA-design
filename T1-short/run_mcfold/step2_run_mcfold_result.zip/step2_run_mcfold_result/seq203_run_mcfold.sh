#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGAGGGCGCAAGUUUUA&name=seq203&top=100"
./mcfold.static.exe >seq203_P5c.dada
