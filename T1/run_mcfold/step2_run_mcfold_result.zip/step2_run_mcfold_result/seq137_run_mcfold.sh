#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGCGCGCCCGGAAGGGCAACUUUCAUUACGCGCC&name=seq137&top=100"
./mcfold.static.exe >seq137_5bp_267_GCstem_3nt_bulges.data
