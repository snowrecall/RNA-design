#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGGUCCGCAAGGGCCA&name=seq364&top=100"
./mcfold.static.exe >seq364_P5c.dada
