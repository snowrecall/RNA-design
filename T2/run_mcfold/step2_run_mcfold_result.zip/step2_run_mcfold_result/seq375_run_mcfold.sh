#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUUCCUGCAAAGGGGA&name=seq375&top=100"
./mcfold.static.exe >seq375_p5clike_opposite_direction.data
