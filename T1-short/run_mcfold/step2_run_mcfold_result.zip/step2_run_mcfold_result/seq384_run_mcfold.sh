#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGGGUUGCAAAGUCCA&name=seq384&top=100"
./mcfold.static.exe >seq384_P5c.dada
