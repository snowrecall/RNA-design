#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGUUCCGCAAGGAACA&name=seq238&top=100"
./mcfold.static.exe >seq238_P5c.dada
