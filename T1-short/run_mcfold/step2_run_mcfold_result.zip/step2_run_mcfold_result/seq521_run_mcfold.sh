#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGUUUUCGCAAGAAGGA&name=seq521&top=100"
./mcfold.static.exe >seq521_P5c.dada
