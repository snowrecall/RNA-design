#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGACUUUGCAAGAGGUA&name=seq103&top=100"
./mcfold.static.exe >seq103_P5c.dada
