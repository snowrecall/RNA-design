#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUUAAGGCAACUUGAA&name=seq75&top=100"
./mcfold.static.exe >seq75_p5clike_opposite_direction.data
