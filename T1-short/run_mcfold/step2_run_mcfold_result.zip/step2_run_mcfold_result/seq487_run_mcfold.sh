#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGGGGCGCAAGUUUCA&name=seq487&top=100"
./mcfold.static.exe >seq487_P5c.dada
