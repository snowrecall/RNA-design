#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGUUUCUGCAAGGAAAA&name=seq2&top=100"
./mcfold.static.exe >seq2_P5c.dada
