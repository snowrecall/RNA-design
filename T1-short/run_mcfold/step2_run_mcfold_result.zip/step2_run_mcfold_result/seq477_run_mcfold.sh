#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGGGGUGCAAACUUCA&name=seq477&top=100"
./mcfold.static.exe >seq477_P5c.dada
