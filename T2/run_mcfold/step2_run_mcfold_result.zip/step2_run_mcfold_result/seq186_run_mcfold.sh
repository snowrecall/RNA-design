#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGGGGGCAACUUUCA&name=seq186&top=100"
./mcfold.static.exe >seq186_p5clike_opposite_direction.data
