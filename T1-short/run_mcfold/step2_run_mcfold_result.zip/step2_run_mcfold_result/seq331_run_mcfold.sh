#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGGACUGCAAGGUCCA&name=seq331&top=100"
./mcfold.static.exe >seq331_P5c.dada
