#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGCUUCCGCAAGGAGGA&name=seq220&top=100"
./mcfold.static.exe >seq220_P5c.dada
