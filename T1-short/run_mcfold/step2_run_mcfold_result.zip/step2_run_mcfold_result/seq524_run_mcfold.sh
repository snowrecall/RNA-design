#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGUUUCUGCAAGGAGGA&name=seq524&top=100"
./mcfold.static.exe >seq524_P5c.dada
