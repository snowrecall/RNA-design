#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGAAGGCAAUUUUUA&name=seq470&top=100"
./mcfold.static.exe >seq470_p5clike_opposite_direction.data
