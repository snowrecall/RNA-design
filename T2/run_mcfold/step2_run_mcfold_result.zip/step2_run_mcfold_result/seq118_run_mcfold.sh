#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUUUCAGCAAUGGGAA&name=seq118&top=100"
./mcfold.static.exe >seq118_p5clike_opposite_direction.data
