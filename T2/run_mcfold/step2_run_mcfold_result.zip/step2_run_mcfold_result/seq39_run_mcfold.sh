#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUUUGGGCAAUUGAAA&name=seq39&top=100"
./mcfold.static.exe >seq39_p5clike_opposite_direction.data
