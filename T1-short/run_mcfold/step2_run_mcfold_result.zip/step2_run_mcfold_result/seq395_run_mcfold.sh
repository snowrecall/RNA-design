#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGUUCCGCAAGGAGCA&name=seq395&top=100"
./mcfold.static.exe >seq395_P5c.dada
