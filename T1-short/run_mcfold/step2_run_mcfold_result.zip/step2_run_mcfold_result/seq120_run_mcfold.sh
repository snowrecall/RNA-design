#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGAUCUCGCAAGGGGUA&name=seq120&top=100"
./mcfold.static.exe >seq120_P5c.dada
