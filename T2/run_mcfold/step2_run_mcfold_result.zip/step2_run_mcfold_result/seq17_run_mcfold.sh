#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUUUUUGCAAAAGAAA&name=seq17&top=100"
./mcfold.static.exe >seq17_p5clike_opposite_direction.data
