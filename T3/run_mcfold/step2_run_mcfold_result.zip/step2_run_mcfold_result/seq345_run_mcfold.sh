#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGUUUCGCAAGAAGCA&name=seq345&explore=50&top=100"
./mcfold.static.exe >seq345_like_p5c_shift_2bp_type3.data
