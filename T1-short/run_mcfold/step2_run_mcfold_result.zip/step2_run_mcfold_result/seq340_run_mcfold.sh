#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGGAGGGCAAUUUCCA&name=seq340&top=100"
./mcfold.static.exe >seq340_P5c.dada
