#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUGAGGGCAACUUUGA&name=seq424&top=100"
./mcfold.static.exe >seq424_p5clike_opposite_direction.data
