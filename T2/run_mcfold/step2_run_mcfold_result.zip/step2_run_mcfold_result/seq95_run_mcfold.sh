#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUUCGGGCAACCGGAA&name=seq95&top=100"
./mcfold.static.exe >seq95_p5clike_opposite_direction.data
