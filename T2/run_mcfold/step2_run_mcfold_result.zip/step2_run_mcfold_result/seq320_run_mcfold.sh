#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUCUUGGCAACGGGGA&name=seq320&top=100"
./mcfold.static.exe >seq320_p5clike_opposite_direction.data
