#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUUCUGGCAAUAGGGA&name=seq371&top=100"
./mcfold.static.exe >seq371_p5clike_opposite_direction.data
