#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGCGCGAUCGGAAGGGCAACUUUCAUCACGCGCC&name=seq17&top=100"
./mcfold.static.exe >seq17_5bp_267_GCstem_3nt_bulges.data
