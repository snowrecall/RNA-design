#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUUUUGGCAAUAGGGA&name=seq399&top=100"
./mcfold.static.exe >seq399_p5clike_opposite_direction.data
