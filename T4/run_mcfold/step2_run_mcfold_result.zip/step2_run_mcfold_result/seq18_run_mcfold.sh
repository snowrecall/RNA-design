#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGAGGGUGCUUCGGCCUUUUC&name=seq18&explore=50&top=100"
./mcfold.static.exe >seq18_p5clike_1bulgeout.data
