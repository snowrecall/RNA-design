#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGGGGUGCAAGCCUCA&name=seq452&top=100"
./mcfold.static.exe >seq452_P5c.dada
