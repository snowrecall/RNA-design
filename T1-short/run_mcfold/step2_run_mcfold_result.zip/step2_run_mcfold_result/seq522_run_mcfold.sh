#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGUUUUUGCAAGAAGGA&name=seq522&top=100"
./mcfold.static.exe >seq522_P5c.dada
