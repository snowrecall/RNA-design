#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGUUUUCGCAAGAGAAA&name=seq12&top=100"
./mcfold.static.exe >seq12_P5c.dada
