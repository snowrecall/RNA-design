#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGAAUUGCAAAGUUCA&name=seq261&top=100"
./mcfold.static.exe >seq261_P5c.dada
