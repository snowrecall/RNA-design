#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGUUUUGCAAGAAAUA&name=seq539&top=100"
./mcfold.static.exe >seq539_P5c.dada
