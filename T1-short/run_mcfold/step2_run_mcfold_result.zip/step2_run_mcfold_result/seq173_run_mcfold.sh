#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGAGGGUGCAAAUCUUA&name=seq173&top=100"
./mcfold.static.exe >seq173_P5c.dada
