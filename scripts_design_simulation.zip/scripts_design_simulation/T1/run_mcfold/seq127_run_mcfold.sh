#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGCGCGCCAGGAAGGGCAACUUUCAAAACGCGCC&name=seq127&top=100"
./mcfold.static.exe >seq127_5bp_267_GCstem_3nt_bulges.data
