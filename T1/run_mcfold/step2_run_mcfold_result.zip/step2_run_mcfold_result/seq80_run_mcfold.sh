#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGCGCGUAAGGAAGGGCAACUUUCACCCCGCGCC&name=seq80&top=100"
./mcfold.static.exe >seq80_5bp_267_GCstem_3nt_bulges.data
