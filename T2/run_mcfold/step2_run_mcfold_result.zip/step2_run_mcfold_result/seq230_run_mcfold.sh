#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUUGAGGCAAUUUAGA&name=seq230&top=100"
./mcfold.static.exe >seq230_p5clike_opposite_direction.data
