#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGAGGCGCAAGUUUCA&name=seq302&top=100"
./mcfold.static.exe >seq302_P5c.dada
