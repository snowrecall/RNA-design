#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUUUAAGCAAUUGGGA&name=seq400&top=100"
./mcfold.static.exe >seq400_p5clike_opposite_direction.data
