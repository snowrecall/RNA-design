#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGGGGGCAAUUCCCA&name=seq159&top=100"
./mcfold.static.exe >seq159_p5clike_opposite_direction.data
