#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUUUGGGCAACCAAAA&name=seq1&top=100"
./mcfold.static.exe >seq1_p5clike_opposite_direction.data
