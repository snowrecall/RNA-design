#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGUUUUGCAAGGAAUA&name=seq544&top=100"
./mcfold.static.exe >seq544_P5c.dada
