#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGUUUUUGCAAAGGGAA&name=seq48&top=100"
./mcfold.static.exe >seq48_P5c.dada
