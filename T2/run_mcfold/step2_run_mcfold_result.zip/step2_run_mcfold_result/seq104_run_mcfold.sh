#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUUCGGGCAAUUGGAA&name=seq104&top=100"
./mcfold.static.exe >seq104_p5clike_opposite_direction.data
