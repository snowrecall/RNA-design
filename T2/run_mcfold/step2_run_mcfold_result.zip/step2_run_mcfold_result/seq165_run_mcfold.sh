#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGGGAGCAAUUUCCA&name=seq165&top=100"
./mcfold.static.exe >seq165_p5clike_opposite_direction.data
