#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUGAAAGCAAUUUUAA&name=seq137&top=100"
./mcfold.static.exe >seq137_p5clike_opposite_direction.data
