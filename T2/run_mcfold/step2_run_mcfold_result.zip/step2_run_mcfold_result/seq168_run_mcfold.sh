#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGAAAGCAAUUUUCA&name=seq168&top=100"
./mcfold.static.exe >seq168_p5clike_opposite_direction.data
