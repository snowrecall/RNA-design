#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGAGAAUGCAAGUUUUA&name=seq139&top=100"
./mcfold.static.exe >seq139_P5c.dada
