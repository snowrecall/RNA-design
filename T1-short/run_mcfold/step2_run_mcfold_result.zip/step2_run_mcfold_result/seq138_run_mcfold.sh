#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGAGAACGCAAGUUUUA&name=seq138&top=100"
./mcfold.static.exe >seq138_P5c.dada
