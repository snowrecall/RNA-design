#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUUGGGGCAAUUUAAA&name=seq47&top=100"
./mcfold.static.exe >seq47_p5clike_opposite_direction.data
