#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUUUUUGCAAGAAGGA&name=seq347&top=100"
./mcfold.static.exe >seq347_p5clike_opposite_direction.data
