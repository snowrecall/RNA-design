#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUCUUUGCAAAAGGGA&name=seq303&top=100"
./mcfold.static.exe >seq303_p5clike_opposite_direction.data
