#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGCUUUGCAAAAGGCA&name=seq310&top=100"
./mcfold.static.exe >seq310_P5c.dada
