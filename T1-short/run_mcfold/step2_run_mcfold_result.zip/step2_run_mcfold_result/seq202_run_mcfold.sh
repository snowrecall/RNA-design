#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGAGGGAGCAAUUUUUA&name=seq202&top=100"
./mcfold.static.exe >seq202_P5c.dada
