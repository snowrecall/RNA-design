#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGUGCGUGCAAGCGCAA&name=seq177&explore=50&top=100"
./mcfold.static.exe >seq177_like_p5c_shift_2bp_type3.data
