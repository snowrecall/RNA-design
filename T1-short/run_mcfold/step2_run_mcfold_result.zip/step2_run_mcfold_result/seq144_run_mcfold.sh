#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGAGAUCGCAAGGUUUA&name=seq144&top=100"
./mcfold.static.exe >seq144_P5c.dada
