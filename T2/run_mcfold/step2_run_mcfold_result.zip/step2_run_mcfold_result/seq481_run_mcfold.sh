#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGGAAGCAAUUUUUA&name=seq481&top=100"
./mcfold.static.exe >seq481_p5clike_opposite_direction.data
