#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGGGUUGCAAGAUCCA&name=seq371&top=100"
./mcfold.static.exe >seq371_P5c.dada
