#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUUUAAGCAAUUGGAA&name=seq114&top=100"
./mcfold.static.exe >seq114_p5clike_opposite_direction.data
