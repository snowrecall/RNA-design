#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGGAGUGCUUCGGCCUUCCC&name=seq1&explore=50&top=100"
./mcfold.static.exe >seq1_p5clike_1bulgeout.data
