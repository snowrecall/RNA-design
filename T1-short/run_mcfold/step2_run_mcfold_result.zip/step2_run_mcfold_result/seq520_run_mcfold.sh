#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGUUUUUGCAAAAAGGA&name=seq520&top=100"
./mcfold.static.exe >seq520_P5c.dada
