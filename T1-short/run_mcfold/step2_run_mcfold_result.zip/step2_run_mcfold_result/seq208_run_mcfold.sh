#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGCCCUUGCAAGGGGGA&name=seq208&top=100"
./mcfold.static.exe >seq208_P5c.dada
