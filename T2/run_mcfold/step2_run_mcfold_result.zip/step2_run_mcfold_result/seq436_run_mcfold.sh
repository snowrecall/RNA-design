#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUGGGAGCAAUUUUGA&name=seq436&top=100"
./mcfold.static.exe >seq436_p5clike_opposite_direction.data
