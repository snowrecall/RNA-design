#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUGGGAGCAAUUUCGA&name=seq342&top=100"
./mcfold.static.exe >seq342_p5clike_opposite_direction.data
