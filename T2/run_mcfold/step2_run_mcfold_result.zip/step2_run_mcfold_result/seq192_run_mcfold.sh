#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUUUUUGCAAAGAAGA&name=seq192&top=100"
./mcfold.static.exe >seq192_p5clike_opposite_direction.data
