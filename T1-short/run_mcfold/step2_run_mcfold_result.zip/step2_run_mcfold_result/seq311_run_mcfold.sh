#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGCUUCGCAAGAGGCA&name=seq311&top=100"
./mcfold.static.exe >seq311_P5c.dada
