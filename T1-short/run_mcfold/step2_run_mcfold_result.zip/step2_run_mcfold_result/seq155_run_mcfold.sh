#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGAGCUUGCAAGGGUUA&name=seq155&top=100"
./mcfold.static.exe >seq155_P5c.dada
