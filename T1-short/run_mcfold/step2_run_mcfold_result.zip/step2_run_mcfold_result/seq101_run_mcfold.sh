#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGACUUUGCAAAAGGUA&name=seq101&top=100"
./mcfold.static.exe >seq101_P5c.dada
