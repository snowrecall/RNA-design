#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUUUGAGCAAUUGGAA&name=seq130&top=100"
./mcfold.static.exe >seq130_p5clike_opposite_direction.data
