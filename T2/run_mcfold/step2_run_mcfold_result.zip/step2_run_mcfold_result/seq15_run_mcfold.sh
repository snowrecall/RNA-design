#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUUGGGGCAACUCAAA&name=seq15&top=100"
./mcfold.static.exe >seq15_p5clike_opposite_direction.data
