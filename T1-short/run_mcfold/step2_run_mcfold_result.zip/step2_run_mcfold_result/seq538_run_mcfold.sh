#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGUUUCGCAAGAAAUA&name=seq538&top=100"
./mcfold.static.exe >seq538_P5c.dada
