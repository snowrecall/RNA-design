#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGGGUCGCAAGAUUCA&name=seq469&top=100"
./mcfold.static.exe >seq469_P5c.dada
