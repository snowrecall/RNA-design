#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUGGGAGCAAUUCCAA&name=seq49&top=100"
./mcfold.static.exe >seq49_p5clike_opposite_direction.data
