#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGAGUUUGCAAGAAUUA&name=seq131&top=100"
./mcfold.static.exe >seq131_P5c.dada
