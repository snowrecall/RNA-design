#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUUUGGGCAACUGGGA&name=seq412&top=100"
./mcfold.static.exe >seq412_p5clike_opposite_direction.data
