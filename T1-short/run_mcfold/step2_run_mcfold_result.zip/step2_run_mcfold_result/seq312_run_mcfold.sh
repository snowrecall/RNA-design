#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGCUUUGCAAGAGGCA&name=seq312&top=100"
./mcfold.static.exe >seq312_P5c.dada
