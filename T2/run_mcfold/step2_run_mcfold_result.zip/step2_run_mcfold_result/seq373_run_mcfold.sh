#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUUCAGGCAACUGGGA&name=seq373&top=100"
./mcfold.static.exe >seq373_p5clike_opposite_direction.data
