#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUUUGGGCAAUUAAGA&name=seq200&top=100"
./mcfold.static.exe >seq200_p5clike_opposite_direction.data
