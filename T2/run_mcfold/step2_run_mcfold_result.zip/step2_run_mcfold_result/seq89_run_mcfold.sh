#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUUCCUGCAAAGGGAA&name=seq89&top=100"
./mcfold.static.exe >seq89_p5clike_opposite_direction.data
