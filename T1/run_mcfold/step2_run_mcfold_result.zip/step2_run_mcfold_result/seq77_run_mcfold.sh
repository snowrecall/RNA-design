#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGCGCGUACGGAAGGGCAACUUUCAUACCGCGCC&name=seq77&top=100"
./mcfold.static.exe >seq77_5bp_267_GCstem_3nt_bulges.data
