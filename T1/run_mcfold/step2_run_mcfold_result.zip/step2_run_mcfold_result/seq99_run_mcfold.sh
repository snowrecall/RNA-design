#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGCGCGUCUGGAAGGGCAACUUUCACUCCGCGCC&name=seq99&top=100"
./mcfold.static.exe >seq99_5bp_267_GCstem_3nt_bulges.data
