#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGGAACGCAAGUUCCA&name=seq327&top=100"
./mcfold.static.exe >seq327_P5c.dada
