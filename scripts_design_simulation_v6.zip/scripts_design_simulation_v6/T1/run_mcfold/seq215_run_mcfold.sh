#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGCGCGCCCGGAAGGGCAACUUUCAUCCCGCGCC&name=seq215&top=100"
./mcfold.static.exe >seq215_5bp_267_GCstem_3nt_bulges.data
