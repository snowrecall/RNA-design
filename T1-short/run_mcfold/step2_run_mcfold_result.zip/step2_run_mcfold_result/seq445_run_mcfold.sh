#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGGGAUGCAAGUCUCA&name=seq445&top=100"
./mcfold.static.exe >seq445_P5c.dada
