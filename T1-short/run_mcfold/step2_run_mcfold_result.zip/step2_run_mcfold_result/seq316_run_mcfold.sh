#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGCUUCGCAAGGGGCA&name=seq316&top=100"
./mcfold.static.exe >seq316_P5c.dada
