#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGAAACCGCAAGGUUUA&name=seq50&top=100"
./mcfold.static.exe >seq50_P5c.dada
