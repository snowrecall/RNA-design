#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGUCUCGCAAGGGAUA&name=seq548&top=100"
./mcfold.static.exe >seq548_P5c.dada
