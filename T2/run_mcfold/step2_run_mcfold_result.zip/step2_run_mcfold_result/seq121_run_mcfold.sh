#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUUUCUGCAAGGGGAA&name=seq121&top=100"
./mcfold.static.exe >seq121_p5clike_opposite_direction.data
