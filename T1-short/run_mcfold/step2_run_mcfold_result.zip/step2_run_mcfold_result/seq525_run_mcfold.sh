#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGUUUUUGCAAAGAGGA&name=seq525&top=100"
./mcfold.static.exe >seq525_P5c.dada
