#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGUCUCGCAAGGGGCA&name=seq403&top=100"
./mcfold.static.exe >seq403_P5c.dada
