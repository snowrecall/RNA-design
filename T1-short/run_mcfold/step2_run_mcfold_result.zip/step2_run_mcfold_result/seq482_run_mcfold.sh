#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGGGGGGCAAUCUUCA&name=seq482&top=100"
./mcfold.static.exe >seq482_P5c.dada
