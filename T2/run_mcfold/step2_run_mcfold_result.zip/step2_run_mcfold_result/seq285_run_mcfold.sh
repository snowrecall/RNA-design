#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUCCAGGCAAUUGGGA&name=seq285&top=100"
./mcfold.static.exe >seq285_p5clike_opposite_direction.data
