#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGAGAAGCAAUUUUUA&name=seq450&top=100"
./mcfold.static.exe >seq450_p5clike_opposite_direction.data
