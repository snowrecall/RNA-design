#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGCCUUCGCAAGAGGGA&name=seq210&top=100"
./mcfold.static.exe >seq210_P5c.dada
