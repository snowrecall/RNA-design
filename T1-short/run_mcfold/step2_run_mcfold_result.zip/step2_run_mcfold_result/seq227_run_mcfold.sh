#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGCUCUUGCAAAGGGGA&name=seq227&top=100"
./mcfold.static.exe >seq227_P5c.dada
