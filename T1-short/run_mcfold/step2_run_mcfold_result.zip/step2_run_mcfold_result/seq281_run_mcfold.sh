#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGAUUCGCAAGGGUCA&name=seq281&top=100"
./mcfold.static.exe >seq281_P5c.dada
