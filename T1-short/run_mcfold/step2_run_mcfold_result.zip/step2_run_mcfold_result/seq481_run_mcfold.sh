#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGGGGUGCAAGCUUCA&name=seq481&top=100"
./mcfold.static.exe >seq481_P5c.dada
