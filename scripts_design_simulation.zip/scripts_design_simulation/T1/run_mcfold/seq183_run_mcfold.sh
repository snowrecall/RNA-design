#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGCGCGCAUGGAAGGGCAACUUUCACACCGCGCC&name=seq183&top=100"
./mcfold.static.exe >seq183_5bp_267_GCstem_3nt_bulges.data
