#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGGGCCGCAAGGUCCA&name=seq376&top=100"
./mcfold.static.exe >seq376_P5c.dada
