#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGUUUCUGCAAGGGGAA&name=seq47&top=100"
./mcfold.static.exe >seq47_P5c.dada
