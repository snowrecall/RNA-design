#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUUUUAGCAAUGGAGA&name=seq221&top=100"
./mcfold.static.exe >seq221_p5clike_opposite_direction.data
