#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUUUUAGCAAUGAGAA&name=seq66&top=100"
./mcfold.static.exe >seq66_p5clike_opposite_direction.data
