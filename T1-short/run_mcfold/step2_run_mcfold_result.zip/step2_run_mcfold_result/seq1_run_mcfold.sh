#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGUUUCCGCAAGGAAAA&name=seq1&top=100"
./mcfold.static.exe >seq1_P5c.dada
