#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGUCUUUGCAAGGGGGA&name=seq519&top=100"
./mcfold.static.exe >seq519_P5c.dada
