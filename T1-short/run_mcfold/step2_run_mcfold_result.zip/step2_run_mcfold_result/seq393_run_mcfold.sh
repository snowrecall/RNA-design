#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGUUUCGCAAGAAGCA&name=seq393&top=100"
./mcfold.static.exe >seq393_P5c.dada
