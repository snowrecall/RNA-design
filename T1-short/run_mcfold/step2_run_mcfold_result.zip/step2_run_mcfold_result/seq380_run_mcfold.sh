#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGGGGCGCAAGCUCCA&name=seq380&top=100"
./mcfold.static.exe >seq380_P5c.dada
