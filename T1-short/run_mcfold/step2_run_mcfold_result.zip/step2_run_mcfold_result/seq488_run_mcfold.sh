#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGGGGGGCAACUUUCA&name=seq488&top=100"
./mcfold.static.exe >seq488_P5c.dada
