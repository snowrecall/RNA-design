#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGCUUUCGCAAGGAGGA&name=seq223&top=100"
./mcfold.static.exe >seq223_P5c.dada
