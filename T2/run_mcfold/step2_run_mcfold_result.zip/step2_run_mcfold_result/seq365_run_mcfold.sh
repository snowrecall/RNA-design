#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUUAGAGCAAUUUGGA&name=seq365&top=100"
./mcfold.static.exe >seq365_p5clike_opposite_direction.data
