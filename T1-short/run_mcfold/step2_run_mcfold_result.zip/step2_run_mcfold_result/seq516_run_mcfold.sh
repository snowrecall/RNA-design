#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGUCUCCGCAAGGGGGA&name=seq516&top=100"
./mcfold.static.exe >seq516_P5c.dada
