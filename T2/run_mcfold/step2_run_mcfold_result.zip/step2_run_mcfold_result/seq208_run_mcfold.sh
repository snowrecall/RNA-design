#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUUUUGGCAAUAGAGA&name=seq208&top=100"
./mcfold.static.exe >seq208_p5clike_opposite_direction.data
