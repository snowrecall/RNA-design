#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUUUUGGCAAUAGGAA&name=seq113&top=100"
./mcfold.static.exe >seq113_p5clike_opposite_direction.data
