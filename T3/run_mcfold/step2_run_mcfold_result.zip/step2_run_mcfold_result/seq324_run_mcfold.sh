#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGGAGGGCAAUUUCCA&name=seq324&explore=50&top=100"
./mcfold.static.exe >seq324_like_p5c_shift_2bp_type3.data
