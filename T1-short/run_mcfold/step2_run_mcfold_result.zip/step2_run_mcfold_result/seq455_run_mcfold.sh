#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGGGUCGCAAGGCUCA&name=seq455&top=100"
./mcfold.static.exe >seq455_P5c.dada
