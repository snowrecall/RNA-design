#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUUUUUGCAAGGGAAA&name=seq36&top=100"
./mcfold.static.exe >seq36_p5clike_opposite_direction.data
