#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGAGAGUGCAAAUUUUA&name=seq146&top=100"
./mcfold.static.exe >seq146_P5c.dada
