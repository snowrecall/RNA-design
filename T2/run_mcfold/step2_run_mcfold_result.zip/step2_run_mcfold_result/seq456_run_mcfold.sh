#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGAGGGGCAAUUUUUA&name=seq456&top=100"
./mcfold.static.exe >seq456_p5clike_opposite_direction.data
