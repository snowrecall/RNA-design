#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUCUUGGCAACAAGGA&name=seq257&top=100"
./mcfold.static.exe >seq257_p5clike_opposite_direction.data
