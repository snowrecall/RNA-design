#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUUGGAGCAAUUUAGA&name=seq233&top=100"
./mcfold.static.exe >seq233_p5clike_opposite_direction.data
