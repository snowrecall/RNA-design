#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUGGGGGCAAUCCUAA&name=seq146&top=100"
./mcfold.static.exe >seq146_p5clike_opposite_direction.data
