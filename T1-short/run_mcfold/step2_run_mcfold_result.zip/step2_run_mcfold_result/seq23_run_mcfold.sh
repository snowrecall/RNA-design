#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGUCUUUGCAAAAGGAA&name=seq23&top=100"
./mcfold.static.exe >seq23_P5c.dada
