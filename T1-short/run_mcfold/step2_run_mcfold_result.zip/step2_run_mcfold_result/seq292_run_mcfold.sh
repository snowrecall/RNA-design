#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGAGGUGCAAACUUCA&name=seq292&top=100"
./mcfold.static.exe >seq292_P5c.dada
