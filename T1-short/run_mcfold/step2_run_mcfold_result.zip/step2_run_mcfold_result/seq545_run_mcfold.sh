#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGUCCCGCAAGGGAUA&name=seq545&top=100"
./mcfold.static.exe >seq545_P5c.dada
