#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUUAGGGCAACCUGGA&name=seq363&top=100"
./mcfold.static.exe >seq363_p5clike_opposite_direction.data
