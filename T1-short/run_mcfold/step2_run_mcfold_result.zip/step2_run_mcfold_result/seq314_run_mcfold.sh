#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGCUCUGCAAGGGGCA&name=seq314&top=100"
./mcfold.static.exe >seq314_P5c.dada
