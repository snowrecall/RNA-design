#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGAAGGCAACUUUUA&name=seq469&top=100"
./mcfold.static.exe >seq469_p5clike_opposite_direction.data
