#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGGAUAGGGCAACUUAUCUA&name=seq18&explore=50&top=100"
./mcfold.static.exe >seq18_5bp_267_add2bp_all_possible.data
