#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGUUUUCGCAAGAAGAA&name=seq32&top=100"
./mcfold.static.exe >seq32_P5c.dada
