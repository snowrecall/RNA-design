#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGAUUUCGCAAGGAGUA&name=seq115&top=100"
./mcfold.static.exe >seq115_P5c.dada
