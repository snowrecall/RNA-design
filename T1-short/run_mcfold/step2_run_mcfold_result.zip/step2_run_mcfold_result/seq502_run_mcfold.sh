#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGUUUUUGCAAAAGAGA&name=seq502&top=100"
./mcfold.static.exe >seq502_P5c.dada
