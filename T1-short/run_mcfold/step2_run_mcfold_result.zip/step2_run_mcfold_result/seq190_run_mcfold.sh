#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGAGGAGGCAAUUUUUA&name=seq190&top=100"
./mcfold.static.exe >seq190_P5c.dada
