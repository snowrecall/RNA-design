#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGCGCGCAAGGAAGGGCAACUUUCACCUCGCGCC&name=seq152&top=100"
./mcfold.static.exe >seq152_5bp_267_GCstem_3nt_bulges.data
