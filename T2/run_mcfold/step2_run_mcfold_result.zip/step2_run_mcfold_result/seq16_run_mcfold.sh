#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUUGGGGCAAUUCAAA&name=seq16&top=100"
./mcfold.static.exe >seq16_p5clike_opposite_direction.data
