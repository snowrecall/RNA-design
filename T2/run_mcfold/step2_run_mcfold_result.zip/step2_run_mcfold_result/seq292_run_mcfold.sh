#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUCCUUGCAAAGGGGA&name=seq292&top=100"
./mcfold.static.exe >seq292_p5clike_opposite_direction.data
