#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGAGAUGCAAGUUUCA&name=seq288&top=100"
./mcfold.static.exe >seq288_P5c.dada
