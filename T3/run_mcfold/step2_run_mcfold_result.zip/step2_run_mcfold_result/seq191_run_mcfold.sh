#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGAUUUCGCAAGGGAUA&name=seq191&explore=50&top=100"
./mcfold.static.exe >seq191_like_p5c_shift_2bp_type3.data
