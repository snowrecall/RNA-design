#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGAAAGCAAUUUUUA&name=seq468&top=100"
./mcfold.static.exe >seq468_p5clike_opposite_direction.data
