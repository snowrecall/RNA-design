#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGAGGAGCAAUUCUUA&name=seq447&top=100"
./mcfold.static.exe >seq447_p5clike_opposite_direction.data
