#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGUCUUUGCAAGAGGGA&name=seq515&top=100"
./mcfold.static.exe >seq515_P5c.dada
