#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGUUUUUGCAAGGGAGA&name=seq508&top=100"
./mcfold.static.exe >seq508_P5c.dada
