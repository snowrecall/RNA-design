#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGCGCGCACGGAAGGGCAACUUUCAUAACGCGCC&name=seq113&top=100"
./mcfold.static.exe >seq113_5bp_267_GCstem_3nt_bulges.data
