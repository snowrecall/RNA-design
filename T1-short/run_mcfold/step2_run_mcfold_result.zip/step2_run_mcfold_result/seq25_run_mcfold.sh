#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGUCUUUGCAAGAGGAA&name=seq25&top=100"
./mcfold.static.exe >seq25_P5c.dada
