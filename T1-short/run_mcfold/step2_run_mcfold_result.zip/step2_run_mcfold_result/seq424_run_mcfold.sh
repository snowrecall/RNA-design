#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGGACCGCAAGGUUCA&name=seq424&top=100"
./mcfold.static.exe >seq424_P5c.dada
