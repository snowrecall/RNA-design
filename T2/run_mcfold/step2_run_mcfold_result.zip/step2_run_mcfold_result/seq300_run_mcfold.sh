#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUCCGGGCAAUUGGGA&name=seq300&top=100"
./mcfold.static.exe >seq300_p5clike_opposite_direction.data
