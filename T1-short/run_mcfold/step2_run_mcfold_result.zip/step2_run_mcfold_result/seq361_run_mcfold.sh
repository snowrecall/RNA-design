#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGGUUUGCAAAAGCCA&name=seq361&top=100"
./mcfold.static.exe >seq361_P5c.dada
