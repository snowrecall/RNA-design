#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=CGUCUUCGCAAGGAGGA&name=seq405&explore=50&top=100"
./mcfold.static.exe >seq405_like_p5c_shift_2bp_type3.data
