#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUUUUUGCAAGGAAGA&name=seq196&top=100"
./mcfold.static.exe >seq196_p5clike_opposite_direction.data
