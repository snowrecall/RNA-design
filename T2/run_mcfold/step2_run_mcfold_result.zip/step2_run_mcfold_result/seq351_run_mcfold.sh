#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUUUUUGCAAAGAGGA&name=seq351&top=100"
./mcfold.static.exe >seq351_p5clike_opposite_direction.data
