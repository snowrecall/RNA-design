#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUGAGGGCAAUCUUAA&name=seq141&top=100"
./mcfold.static.exe >seq141_p5clike_opposite_direction.data
