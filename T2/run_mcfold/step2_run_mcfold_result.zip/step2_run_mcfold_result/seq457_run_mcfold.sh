#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGGGGGCAAUCCCUA&name=seq457&top=100"
./mcfold.static.exe >seq457_p5clike_opposite_direction.data
