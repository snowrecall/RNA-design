#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGAGAGUGCAAGUUUUA&name=seq149&top=100"
./mcfold.static.exe >seq149_P5c.dada
