#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGAAGCGCAAGUUUUA&name=seq379&explore=50&top=100"
./mcfold.static.exe >seq379_like_p5c_shift_2bp_type3.data
