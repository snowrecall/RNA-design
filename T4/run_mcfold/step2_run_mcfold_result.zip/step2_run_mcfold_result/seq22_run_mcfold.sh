#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGAGGUGCUUCGGCCCUUUC&name=seq22&explore=50&top=100"
./mcfold.static.exe >seq22_p5clike_1bulgeout.data
