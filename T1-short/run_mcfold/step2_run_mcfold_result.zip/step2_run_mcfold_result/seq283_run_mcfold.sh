#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGAGUUGCAAAAUUCA&name=seq283&top=100"
./mcfold.static.exe >seq283_P5c.dada
