#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGCGCGCCCGGAAGGGCAACUUUCACCACGCGCC&name=seq144&top=100"
./mcfold.static.exe >seq144_5bp_267_GCstem_3nt_bulges.data
