#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUGGGGGCAACCCUAA&name=seq145&top=100"
./mcfold.static.exe >seq145_p5clike_opposite_direction.data
