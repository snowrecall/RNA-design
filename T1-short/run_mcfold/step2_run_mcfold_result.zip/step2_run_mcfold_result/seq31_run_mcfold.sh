#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGUUUUUGCAAAAAGAA&name=seq31&top=100"
./mcfold.static.exe >seq31_P5c.dada
