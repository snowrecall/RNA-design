#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGUUUUUGCAAAGAAAA&name=seq3&top=100"
./mcfold.static.exe >seq3_P5c.dada
