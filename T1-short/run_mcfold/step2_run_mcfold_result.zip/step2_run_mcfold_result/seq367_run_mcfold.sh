#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGGUUCGCAAGGGCCA&name=seq367&top=100"
./mcfold.static.exe >seq367_P5c.dada
