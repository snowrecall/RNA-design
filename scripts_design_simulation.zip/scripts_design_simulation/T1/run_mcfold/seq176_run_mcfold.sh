#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGCGCGCCAGGAAGGGCAACUUUCACCUCGCGCC&name=seq176&top=100"
./mcfold.static.exe >seq176_5bp_267_GCstem_3nt_bulges.data
