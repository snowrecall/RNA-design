#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGUCCUCGCAAGGGGAA&name=seq21&top=100"
./mcfold.static.exe >seq21_P5c.dada
