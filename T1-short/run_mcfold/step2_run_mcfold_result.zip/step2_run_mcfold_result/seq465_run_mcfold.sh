#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGGUUUGCAAAGGUCA&name=seq465&top=100"
./mcfold.static.exe >seq465_P5c.dada
