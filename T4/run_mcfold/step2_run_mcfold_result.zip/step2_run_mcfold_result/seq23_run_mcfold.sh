#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGAGGUGCUUCGGCCUUUUC&name=seq23&explore=50&top=100"
./mcfold.static.exe >seq23_p5clike_1bulgeout.data
