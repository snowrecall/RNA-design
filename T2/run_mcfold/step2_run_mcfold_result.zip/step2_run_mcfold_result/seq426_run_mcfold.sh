#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUGGGGGCAACCCUGA&name=seq426&top=100"
./mcfold.static.exe >seq426_p5clike_opposite_direction.data
