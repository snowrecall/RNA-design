#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGAUCCCGCAAGGGGUA&name=seq117&top=100"
./mcfold.static.exe >seq117_P5c.dada
