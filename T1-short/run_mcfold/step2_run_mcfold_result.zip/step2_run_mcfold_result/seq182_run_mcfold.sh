#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGAGUUCGCAAGGGUUA&name=seq182&top=100"
./mcfold.static.exe >seq182_P5c.dada
