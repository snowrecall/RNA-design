#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGCUUUUGCAAGGAGGA&name=seq224&top=100"
./mcfold.static.exe >seq224_P5c.dada
