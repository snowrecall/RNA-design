#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGAGGGCGCAAGCCUUA&name=seq166&top=100"
./mcfold.static.exe >seq166_P5c.dada
