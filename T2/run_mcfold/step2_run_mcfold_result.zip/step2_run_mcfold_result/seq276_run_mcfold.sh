#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUCAGAGCAAUUUGGA&name=seq276&top=100"
./mcfold.static.exe >seq276_p5clike_opposite_direction.data
