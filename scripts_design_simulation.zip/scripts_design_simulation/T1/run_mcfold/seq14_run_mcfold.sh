#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGCGCGAUAGGAAGGGCAACUUUCACCACGCGCC&name=seq14&top=100"
./mcfold.static.exe >seq14_5bp_267_GCstem_3nt_bulges.data
