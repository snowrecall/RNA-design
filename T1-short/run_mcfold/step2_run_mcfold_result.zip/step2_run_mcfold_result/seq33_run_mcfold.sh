#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGUUUUUGCAAGAAGAA&name=seq33&top=100"
./mcfold.static.exe >seq33_P5c.dada
