#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGUUUUUGCAAGGGAAA&name=seq18&top=100"
./mcfold.static.exe >seq18_P5c.dada
