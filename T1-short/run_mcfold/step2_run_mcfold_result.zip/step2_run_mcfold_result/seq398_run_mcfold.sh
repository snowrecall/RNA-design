#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGUUUCGCAAGGAGCA&name=seq398&top=100"
./mcfold.static.exe >seq398_P5c.dada
