#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGUUUCGCAAGGGGCA&name=seq411&top=100"
./mcfold.static.exe >seq411_P5c.dada
