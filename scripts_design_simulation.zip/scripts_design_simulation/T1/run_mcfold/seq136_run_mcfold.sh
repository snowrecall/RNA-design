#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGCGCGCCCGGAAGGGCAACUUUCAAUACGCGCC&name=seq136&top=100"
./mcfold.static.exe >seq136_5bp_267_GCstem_3nt_bulges.data
