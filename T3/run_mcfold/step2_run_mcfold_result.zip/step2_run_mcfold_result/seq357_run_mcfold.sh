#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGGAGUGCAAGCUUCA&name=seq357&explore=50&top=100"
./mcfold.static.exe >seq357_like_p5c_shift_2bp_type3.data
