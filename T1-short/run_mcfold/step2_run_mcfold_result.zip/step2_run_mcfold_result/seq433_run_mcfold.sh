#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGGAGUGCAAGUUUCA&name=seq433&top=100"
./mcfold.static.exe >seq433_P5c.dada
