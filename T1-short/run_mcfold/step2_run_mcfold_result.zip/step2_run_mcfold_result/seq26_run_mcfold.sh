#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGUCUCCGCAAGGGGAA&name=seq26&top=100"
./mcfold.static.exe >seq26_P5c.dada
