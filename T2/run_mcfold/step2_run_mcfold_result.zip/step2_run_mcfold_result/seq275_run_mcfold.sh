#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUCAGGGCAAUCUGGA&name=seq275&top=100"
./mcfold.static.exe >seq275_p5clike_opposite_direction.data
