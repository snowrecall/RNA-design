#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGCGCGACCGGAAGGGCAACUUUCAUUCCGCGCC&name=seq65&top=100"
./mcfold.static.exe >seq65_5bp_267_GCstem_3nt_bulges.data
