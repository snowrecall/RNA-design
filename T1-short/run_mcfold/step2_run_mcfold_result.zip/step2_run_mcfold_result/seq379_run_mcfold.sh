#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGGGGAGCAAUCUCCA&name=seq379&top=100"
./mcfold.static.exe >seq379_P5c.dada
