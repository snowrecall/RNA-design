#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGAUUUGCAAGGGUCA&name=seq282&top=100"
./mcfold.static.exe >seq282_P5c.dada
