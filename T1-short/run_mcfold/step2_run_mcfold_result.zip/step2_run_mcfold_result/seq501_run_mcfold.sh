#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGUUCUUGCAAGGGAGA&name=seq501&top=100"
./mcfold.static.exe >seq501_P5c.dada
