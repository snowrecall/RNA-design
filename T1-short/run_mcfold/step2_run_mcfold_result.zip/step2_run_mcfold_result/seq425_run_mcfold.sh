#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGGACUGCAAGGUUCA&name=seq425&top=100"
./mcfold.static.exe >seq425_P5c.dada
