#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUGGGGGCAAUUCUGA&name=seq430&top=100"
./mcfold.static.exe >seq430_p5clike_opposite_direction.data
