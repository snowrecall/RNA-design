#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUUUGGGCAAUCAAGA&name=seq191&top=100"
./mcfold.static.exe >seq191_p5clike_opposite_direction.data
