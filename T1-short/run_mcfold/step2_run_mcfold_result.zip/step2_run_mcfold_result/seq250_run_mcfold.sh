#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGUUUUGCAAGAGACA&name=seq250&top=100"
./mcfold.static.exe >seq250_P5c.dada
