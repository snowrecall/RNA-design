#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUUUGGGCAACCGAGA&name=seq218&top=100"
./mcfold.static.exe >seq218_p5clike_opposite_direction.data
