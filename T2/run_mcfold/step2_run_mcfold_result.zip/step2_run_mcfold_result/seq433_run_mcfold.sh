#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUGGAGGCAAUUUUGA&name=seq433&top=100"
./mcfold.static.exe >seq433_p5clike_opposite_direction.data
