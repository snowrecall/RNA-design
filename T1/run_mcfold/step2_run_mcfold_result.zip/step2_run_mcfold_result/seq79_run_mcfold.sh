#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGCGCGUAAGGAAGGGCAACUUUCAACCCGCGCC&name=seq79&top=100"
./mcfold.static.exe >seq79_5bp_267_GCstem_3nt_bulges.data
