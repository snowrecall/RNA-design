#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUUCGAGCAAUUGGGA&name=seq388&top=100"
./mcfold.static.exe >seq388_p5clike_opposite_direction.data
