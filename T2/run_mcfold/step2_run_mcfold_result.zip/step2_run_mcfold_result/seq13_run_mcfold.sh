#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUUGGGGCAAUCCAAA&name=seq13&top=100"
./mcfold.static.exe >seq13_p5clike_opposite_direction.data
