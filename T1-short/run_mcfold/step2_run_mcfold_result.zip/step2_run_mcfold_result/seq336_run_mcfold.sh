#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGGAGAGCAAUUUCCA&name=seq336&top=100"
./mcfold.static.exe >seq336_P5c.dada
