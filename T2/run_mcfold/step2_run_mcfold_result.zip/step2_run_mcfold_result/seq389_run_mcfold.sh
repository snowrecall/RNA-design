#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUUCGGGCAACUGGGA&name=seq389&top=100"
./mcfold.static.exe >seq389_p5clike_opposite_direction.data
