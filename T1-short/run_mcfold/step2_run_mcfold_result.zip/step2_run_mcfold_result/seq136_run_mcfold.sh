#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGAGUUUGCAAGGAUUA&name=seq136&top=100"
./mcfold.static.exe >seq136_P5c.dada
