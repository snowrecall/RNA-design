#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGGGUUGCAAAACUCA&name=seq440&top=100"
./mcfold.static.exe >seq440_P5c.dada
