#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUCCUGGCAAUAGGGA&name=seq282&top=100"
./mcfold.static.exe >seq282_p5clike_opposite_direction.data
