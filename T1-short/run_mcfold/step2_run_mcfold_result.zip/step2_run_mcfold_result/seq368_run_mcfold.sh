#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGGUUUGCAAGGGCCA&name=seq368&top=100"
./mcfold.static.exe >seq368_P5c.dada
