#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUUUUCGCAAGGGAGA&name=seq222&top=100"
./mcfold.static.exe >seq222_p5clike_opposite_direction.data
