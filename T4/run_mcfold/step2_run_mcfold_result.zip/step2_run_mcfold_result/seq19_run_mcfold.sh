#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGGAGUGCUUCGGCCUUCUC&name=seq19&explore=50&top=100"
./mcfold.static.exe >seq19_p5clike_1bulgeout.data
