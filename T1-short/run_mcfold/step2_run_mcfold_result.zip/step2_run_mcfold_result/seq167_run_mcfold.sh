#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGAGGGGGCAACCCUUA&name=seq167&top=100"
./mcfold.static.exe >seq167_P5c.dada
