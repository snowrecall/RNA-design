#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGUUCUUGCAAGGGAAA&name=seq10&top=100"
./mcfold.static.exe >seq10_P5c.dada
