#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGGGUUGCAAGGUCCA&name=seq385&top=100"
./mcfold.static.exe >seq385_P5c.dada
