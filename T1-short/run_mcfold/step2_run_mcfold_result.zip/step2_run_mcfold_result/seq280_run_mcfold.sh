#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGAUUUGCAAAGGUCA&name=seq280&top=100"
./mcfold.static.exe >seq280_P5c.dada
