#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGGGUCGCAAGGUUCA&name=seq484&top=100"
./mcfold.static.exe >seq484_P5c.dada
