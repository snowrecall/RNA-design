#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGUUUUUGCAAAGAAGA&name=seq494&top=100"
./mcfold.static.exe >seq494_P5c.dada
