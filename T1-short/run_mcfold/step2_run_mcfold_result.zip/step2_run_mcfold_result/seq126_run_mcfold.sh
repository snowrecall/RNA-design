#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGAUUCUGCAAGGGGUA&name=seq126&top=100"
./mcfold.static.exe >seq126_P5c.dada
