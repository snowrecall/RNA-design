#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGAGGGGGCAACUUUUA&name=seq204&top=100"
./mcfold.static.exe >seq204_P5c.dada
