#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGCUCUUGCAAGGGGGA&name=seq228&top=100"
./mcfold.static.exe >seq228_P5c.dada
