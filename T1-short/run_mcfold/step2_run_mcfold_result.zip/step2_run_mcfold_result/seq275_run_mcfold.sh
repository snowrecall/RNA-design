#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGAUUUGCAAAAGUCA&name=seq275&top=100"
./mcfold.static.exe >seq275_P5c.dada
