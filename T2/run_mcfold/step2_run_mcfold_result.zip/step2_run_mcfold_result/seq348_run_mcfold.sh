#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUUUUGGCAAUAAGGA&name=seq348&top=100"
./mcfold.static.exe >seq348_p5clike_opposite_direction.data
