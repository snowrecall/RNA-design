#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGAGGGUGCUUCGGCCUCUUC&name=seq15&explore=50&top=100"
./mcfold.static.exe >seq15_p5clike_1bulgeout.data
