#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUGGGGGCAACUCCGA&name=seq335&top=100"
./mcfold.static.exe >seq335_p5clike_opposite_direction.data
