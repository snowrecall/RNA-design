#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGACUCCGCAAGGGGUA&name=seq104&top=100"
./mcfold.static.exe >seq104_P5c.dada
