#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGGUCCGCAAGGAUCA&name=seq415&top=100"
./mcfold.static.exe >seq415_P5c.dada
