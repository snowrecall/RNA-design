#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGGAGUGCUUCGGCCUUUUC&name=seq26&explore=50&top=100"
./mcfold.static.exe >seq26_p5clike_1bulgeout.data
