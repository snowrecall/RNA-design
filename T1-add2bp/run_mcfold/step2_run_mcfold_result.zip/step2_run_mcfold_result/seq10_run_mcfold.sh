#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGGAAGGGGCAACUUUUCUA&name=seq10&explore=50&top=100"
./mcfold.static.exe >seq10_5bp_267_add2bp_all_possible.data
