#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGGGGGGCAAUCUCCA&name=seq383&top=100"
./mcfold.static.exe >seq383_P5c.dada
