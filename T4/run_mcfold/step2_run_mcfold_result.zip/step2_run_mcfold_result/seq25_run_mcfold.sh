#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGGGGUGCUUCGGCCUCUUC&name=seq25&explore=50&top=100"
./mcfold.static.exe >seq25_p5clike_1bulgeout.data
