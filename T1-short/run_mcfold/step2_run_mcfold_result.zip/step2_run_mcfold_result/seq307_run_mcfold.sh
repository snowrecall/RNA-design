#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGCCUUGCAAAGGGCA&name=seq307&top=100"
./mcfold.static.exe >seq307_P5c.dada
