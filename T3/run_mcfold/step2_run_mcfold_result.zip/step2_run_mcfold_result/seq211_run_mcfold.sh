#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGACUUCGCAAGGGGUA&name=seq211&explore=50&top=100"
./mcfold.static.exe >seq211_like_p5c_shift_2bp_type3.data
