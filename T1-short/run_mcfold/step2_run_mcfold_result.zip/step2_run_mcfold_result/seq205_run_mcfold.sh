#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGAGGGUGCAAGUUUUA&name=seq205&top=100"
./mcfold.static.exe >seq205_P5c.dada
