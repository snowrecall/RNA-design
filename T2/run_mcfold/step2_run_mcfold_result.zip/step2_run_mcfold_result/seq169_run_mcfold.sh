#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGAAGGCAACUUUCA&name=seq169&top=100"
./mcfold.static.exe >seq169_p5clike_opposite_direction.data
