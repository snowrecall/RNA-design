#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGCGCGCCAGGAAGGGCAACUUUCAAUACGCGCC&name=seq133&top=100"
./mcfold.static.exe >seq133_5bp_267_GCstem_3nt_bulges.data
