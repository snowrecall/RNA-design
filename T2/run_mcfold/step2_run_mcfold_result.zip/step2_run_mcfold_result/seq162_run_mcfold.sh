#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGGAGGCAAUUUCCA&name=seq162&top=100"
./mcfold.static.exe >seq162_p5clike_opposite_direction.data
