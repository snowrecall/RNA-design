#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUCUUGGCAAUGGGGA&name=seq322&top=100"
./mcfold.static.exe >seq322_p5clike_opposite_direction.data
