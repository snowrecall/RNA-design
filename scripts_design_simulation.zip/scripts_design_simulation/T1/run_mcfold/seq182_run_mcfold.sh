#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGCGCGCAAGGAAGGGCAACUUUCACACCGCGCC&name=seq182&top=100"
./mcfold.static.exe >seq182_5bp_267_GCstem_3nt_bulges.data
