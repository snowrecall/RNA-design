#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGAAUCGCAAGGUUCA&name=seq262&top=100"
./mcfold.static.exe >seq262_P5c.dada
