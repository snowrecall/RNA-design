#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGCGCGAAAGGAAGGGCAACUUUCACCCCGCGCC&name=seq44&top=100"
./mcfold.static.exe >seq44_5bp_267_GCstem_3nt_bulges.data
