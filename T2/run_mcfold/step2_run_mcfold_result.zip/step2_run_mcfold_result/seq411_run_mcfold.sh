#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUUUGAGCAAUUGGGA&name=seq411&top=100"
./mcfold.static.exe >seq411_p5clike_opposite_direction.data
