#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGCUUCUGCAAGGAGGA&name=seq221&top=100"
./mcfold.static.exe >seq221_P5c.dada
