#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGUUUUGCAAAGGACA&name=seq253&top=100"
./mcfold.static.exe >seq253_P5c.dada
