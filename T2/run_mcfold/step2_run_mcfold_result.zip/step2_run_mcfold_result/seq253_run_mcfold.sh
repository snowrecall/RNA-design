#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUAGGAGCAAUUUUGA&name=seq253&top=100"
./mcfold.static.exe >seq253_p5clike_opposite_direction.data
