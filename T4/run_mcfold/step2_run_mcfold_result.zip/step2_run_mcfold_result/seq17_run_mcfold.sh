#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGAGGGUGCUUCGGCCCUUUC&name=seq17&explore=50&top=100"
./mcfold.static.exe >seq17_p5clike_1bulgeout.data
