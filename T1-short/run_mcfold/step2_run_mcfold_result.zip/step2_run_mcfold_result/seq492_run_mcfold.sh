#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGUUUCCGCAAGGAAGA&name=seq492&top=100"
./mcfold.static.exe >seq492_P5c.dada
