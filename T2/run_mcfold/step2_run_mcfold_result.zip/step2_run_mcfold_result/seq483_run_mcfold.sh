#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGGAGGCAAUUUUUA&name=seq483&top=100"
./mcfold.static.exe >seq483_p5clike_opposite_direction.data
