#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGAGGGGCAAUCUUCA&name=seq297&top=100"
./mcfold.static.exe >seq297_P5c.dada
