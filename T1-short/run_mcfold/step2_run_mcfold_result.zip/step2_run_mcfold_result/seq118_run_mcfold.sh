#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGAUCCUGCAAGGGGUA&name=seq118&top=100"
./mcfold.static.exe >seq118_P5c.dada
