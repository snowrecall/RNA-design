#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGUUCUCGCAAGGGGGA&name=seq531&top=100"
./mcfold.static.exe >seq531_P5c.dada
