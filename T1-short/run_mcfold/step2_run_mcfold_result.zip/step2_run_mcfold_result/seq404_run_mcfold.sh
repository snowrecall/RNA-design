#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGUCUUGCAAGGGGCA&name=seq404&top=100"
./mcfold.static.exe >seq404_P5c.dada
