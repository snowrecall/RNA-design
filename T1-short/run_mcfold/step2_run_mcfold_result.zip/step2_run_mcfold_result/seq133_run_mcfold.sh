#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGAGUCUGCAAGGAUUA&name=seq133&top=100"
./mcfold.static.exe >seq133_P5c.dada
