#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGGGAUGCAAGUCCCA&name=seq349&top=100"
./mcfold.static.exe >seq349_P5c.dada
