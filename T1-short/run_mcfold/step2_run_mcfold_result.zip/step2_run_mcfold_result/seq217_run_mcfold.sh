#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGCUUUUGCAAAAAGGA&name=seq217&top=100"
./mcfold.static.exe >seq217_P5c.dada
