#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGUCUUGCAAAGGGCA&name=seq402&top=100"
./mcfold.static.exe >seq402_P5c.dada
