#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUGGGGGCAAUUCCGA&name=seq336&top=100"
./mcfold.static.exe >seq336_p5clike_opposite_direction.data
