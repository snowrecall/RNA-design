#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGAGUUUGCAAAGGUUA&name=seq181&top=100"
./mcfold.static.exe >seq181_P5c.dada
