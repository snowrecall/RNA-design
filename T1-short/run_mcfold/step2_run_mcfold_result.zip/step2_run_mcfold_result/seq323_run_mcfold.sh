#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGGUUUGCAAAGACCA&name=seq323&top=100"
./mcfold.static.exe >seq323_P5c.dada
