#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGCGCGAAUGGAAGGGCAACUUUCACCACGCGCC&name=seq9&top=100"
./mcfold.static.exe >seq9_5bp_267_GCstem_3nt_bulges.data
