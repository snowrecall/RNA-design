#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGUCCUUGCAAGGGGGA&name=seq512&top=100"
./mcfold.static.exe >seq512_P5c.dada
