#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUUCUUGCAAAGGGGA&name=seq382&top=100"
./mcfold.static.exe >seq382_p5clike_opposite_direction.data
