#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGAGGAAGCAAUUCUUA&name=seq159&top=100"
./mcfold.static.exe >seq159_P5c.dada
