#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGGGAGGCAAUUCUCA&name=seq446&top=100"
./mcfold.static.exe >seq446_P5c.dada
