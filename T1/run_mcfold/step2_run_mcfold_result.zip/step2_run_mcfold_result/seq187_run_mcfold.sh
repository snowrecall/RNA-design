#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGCGCGCAAGGAAGGGCAACUUUCAACCCGCGCC&name=seq187&top=100"
./mcfold.static.exe >seq187_5bp_267_GCstem_3nt_bulges.data
