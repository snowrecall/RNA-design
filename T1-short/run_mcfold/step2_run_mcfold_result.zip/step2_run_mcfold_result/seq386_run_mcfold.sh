#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGGGGUGCAAAUUCCA&name=seq386&top=100"
./mcfold.static.exe >seq386_P5c.dada
