#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGGGGGGCAAUUCUCA&name=seq461&top=100"
./mcfold.static.exe >seq461_P5c.dada
