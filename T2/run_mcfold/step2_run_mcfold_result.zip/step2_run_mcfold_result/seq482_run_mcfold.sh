#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGGAGGCAACUUUUA&name=seq482&top=100"
./mcfold.static.exe >seq482_p5clike_opposite_direction.data
