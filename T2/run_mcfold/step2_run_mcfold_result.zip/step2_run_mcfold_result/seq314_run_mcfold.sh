#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUCUCGGCAAUGGGGA&name=seq314&top=100"
./mcfold.static.exe >seq314_p5clike_opposite_direction.data
