#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGCCUCUGCAAGGGGGA&name=seq213&top=100"
./mcfold.static.exe >seq213_P5c.dada
