#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGAGGCGCAAGUUUCA&name=seq290&explore=50&top=100"
./mcfold.static.exe >seq290_like_p5c_shift_2bp_type3.data
