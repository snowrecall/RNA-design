#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGGUCUGCAAGGAUCA&name=seq416&top=100"
./mcfold.static.exe >seq416_P5c.dada
