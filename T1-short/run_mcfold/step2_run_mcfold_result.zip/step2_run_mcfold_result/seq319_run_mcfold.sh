#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGGUUCGCAAGAACCA&name=seq319&top=100"
./mcfold.static.exe >seq319_P5c.dada
