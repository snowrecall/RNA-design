#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGCGCGCCAGGAAGGGCAACUUUCAAUCCGCGCC&name=seq205&top=100"
./mcfold.static.exe >seq205_5bp_267_GCstem_3nt_bulges.data
