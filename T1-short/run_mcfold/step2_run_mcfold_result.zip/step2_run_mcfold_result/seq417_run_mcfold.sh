#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGGUUUGCAAAGAUCA&name=seq417&top=100"
./mcfold.static.exe >seq417_P5c.dada
