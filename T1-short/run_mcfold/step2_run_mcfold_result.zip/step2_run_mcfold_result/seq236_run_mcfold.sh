#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGUUUCGCAAGAAACA&name=seq236&top=100"
./mcfold.static.exe >seq236_P5c.dada
