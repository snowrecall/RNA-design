#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGCGCGUUUGGAAGGGCAACUUUCACCCCGCGCC&name=seq87&top=100"
./mcfold.static.exe >seq87_5bp_267_GCstem_3nt_bulges.data
