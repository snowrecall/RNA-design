#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGCGCGCAAGGAAGGGCAACUUUCACCACGCGCC&name=seq116&top=100"
./mcfold.static.exe >seq116_5bp_267_GCstem_3nt_bulges.data
