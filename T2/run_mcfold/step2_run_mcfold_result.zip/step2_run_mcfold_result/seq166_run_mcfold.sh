#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGGGGGCAACUUCCA&name=seq166&top=100"
./mcfold.static.exe >seq166_p5clike_opposite_direction.data
