#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGCCUCGCAAGGGGCA&name=seq308&top=100"
./mcfold.static.exe >seq308_P5c.dada
