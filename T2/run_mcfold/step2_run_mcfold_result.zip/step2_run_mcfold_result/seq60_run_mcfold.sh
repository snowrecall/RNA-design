#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUUUUUGCAAAAAGAA&name=seq60&top=100"
./mcfold.static.exe >seq60_p5clike_opposite_direction.data
