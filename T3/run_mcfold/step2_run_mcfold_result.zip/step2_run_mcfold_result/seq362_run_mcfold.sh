#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGGUGCGCAAGCGUCA&name=seq362&explore=50&top=100"
./mcfold.static.exe >seq362_like_p5c_shift_2bp_type3.data
