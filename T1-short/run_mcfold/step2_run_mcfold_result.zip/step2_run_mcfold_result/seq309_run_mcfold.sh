#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGCCUUGCAAGGGGCA&name=seq309&top=100"
./mcfold.static.exe >seq309_P5c.dada
