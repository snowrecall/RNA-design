#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGAGAUUGCAAGGUUUA&name=seq145&top=100"
./mcfold.static.exe >seq145_P5c.dada
