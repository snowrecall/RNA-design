#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGAGGUUGCAAAGCUUA&name=seq170&top=100"
./mcfold.static.exe >seq170_P5c.dada
