#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGGCUUGCAAGGGCCA&name=seq343&top=100"
./mcfold.static.exe >seq343_P5c.dada
