#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGGGCUGCAAGGCCCA&name=seq351&top=100"
./mcfold.static.exe >seq351_P5c.dada
