#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGGUUUGCAAGGAUCA&name=seq419&top=100"
./mcfold.static.exe >seq419_P5c.dada
