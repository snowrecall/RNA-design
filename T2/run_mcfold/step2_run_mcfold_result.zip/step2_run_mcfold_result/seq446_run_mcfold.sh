#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGAGGGGCAAUCCUUA&name=seq446&top=100"
./mcfold.static.exe >seq446_p5clike_opposite_direction.data
