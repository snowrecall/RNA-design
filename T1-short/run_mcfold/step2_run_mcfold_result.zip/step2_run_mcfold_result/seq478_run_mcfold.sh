#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGGGGAGCAAUCUUCA&name=seq478&top=100"
./mcfold.static.exe >seq478_P5c.dada
