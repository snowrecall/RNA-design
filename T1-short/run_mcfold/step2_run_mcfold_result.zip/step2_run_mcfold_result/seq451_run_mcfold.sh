#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGGGGGGCAACCCUCA&name=seq451&top=100"
./mcfold.static.exe >seq451_P5c.dada
