#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGAAGGGCAACUUUCA&name=seq267&top=100"
./mcfold.static.exe >seq267_P5c.dada
