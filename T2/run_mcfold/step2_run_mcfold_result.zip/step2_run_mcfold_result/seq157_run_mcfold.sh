#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGGGAGCAAUUCCCA&name=seq157&top=100"
./mcfold.static.exe >seq157_p5clike_opposite_direction.data
