#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUUCUUGCAAAAGGAA&name=seq82&top=100"
./mcfold.static.exe >seq82_p5clike_opposite_direction.data
