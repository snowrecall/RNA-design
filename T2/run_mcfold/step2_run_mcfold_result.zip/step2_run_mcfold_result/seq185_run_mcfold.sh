#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGGGAGCAAUUUUCA&name=seq185&top=100"
./mcfold.static.exe >seq185_p5clike_opposite_direction.data
