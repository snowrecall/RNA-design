#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGGGUUGCAAAAUUCA&name=seq468&top=100"
./mcfold.static.exe >seq468_P5c.dada
