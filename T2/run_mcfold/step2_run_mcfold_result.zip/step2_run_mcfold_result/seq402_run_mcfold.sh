#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUUUAGGCAAUUGGGA&name=seq402&top=100"
./mcfold.static.exe >seq402_p5clike_opposite_direction.data
