#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUCCUGGCAACGGGGA&name=seq295&top=100"
./mcfold.static.exe >seq295_p5clike_opposite_direction.data
