#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGGCCCGCAAGGGUCA&name=seq435&top=100"
./mcfold.static.exe >seq435_P5c.dada
