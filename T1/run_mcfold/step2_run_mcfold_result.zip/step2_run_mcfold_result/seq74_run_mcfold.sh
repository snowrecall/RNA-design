#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGCGCGUAAGGAAGGGCAACUUUCACACCGCGCC&name=seq74&top=100"
./mcfold.static.exe >seq74_5bp_267_GCstem_3nt_bulges.data
