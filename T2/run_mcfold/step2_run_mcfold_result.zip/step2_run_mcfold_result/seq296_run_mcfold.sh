#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUCCUUGCAAGGGGGA&name=seq296&top=100"
./mcfold.static.exe >seq296_p5clike_opposite_direction.data
