#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGGAGUGCUUCGGCCUUUCC&name=seq8&explore=50&top=100"
./mcfold.static.exe >seq8_p5clike_1bulgeout.data
