#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUCUUGGCAACGAGGA&name=seq265&top=100"
./mcfold.static.exe >seq265_p5clike_opposite_direction.data
