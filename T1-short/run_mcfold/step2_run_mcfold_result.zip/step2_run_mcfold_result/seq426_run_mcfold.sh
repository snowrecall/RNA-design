#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGGAUUGCAAAGUUCA&name=seq426&top=100"
./mcfold.static.exe >seq426_P5c.dada
