#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGACCUUGCAAGGGGUA&name=seq100&top=100"
./mcfold.static.exe >seq100_P5c.dada
