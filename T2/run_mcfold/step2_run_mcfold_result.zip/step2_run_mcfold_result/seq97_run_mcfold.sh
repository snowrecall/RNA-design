#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUUCUAGCAAUGGGAA&name=seq97&top=100"
./mcfold.static.exe >seq97_p5clike_opposite_direction.data
