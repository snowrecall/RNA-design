#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGAGGGCAACUUCA&name=seq3&top=100"
./mcfold.static.exe >seq3_5bp_267_minus1bp_all_possible.data
