#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGACUUGCAAAGGUCA&name=seq272&top=100"
./mcfold.static.exe >seq272_P5c.dada
