#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUGGGGGCAAUCCCGA&name=seq333&top=100"
./mcfold.static.exe >seq333_p5clike_opposite_direction.data
