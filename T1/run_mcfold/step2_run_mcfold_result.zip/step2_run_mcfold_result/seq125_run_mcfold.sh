#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGCGCGCUCGGAAGGGCAACUUUCAUCACGCGCC&name=seq125&top=100"
./mcfold.static.exe >seq125_5bp_267_GCstem_3nt_bulges.data
