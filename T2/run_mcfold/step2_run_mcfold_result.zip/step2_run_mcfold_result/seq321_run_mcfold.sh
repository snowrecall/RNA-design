#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUCUUUGCAAGGGGGA&name=seq321&top=100"
./mcfold.static.exe >seq321_p5clike_opposite_direction.data
