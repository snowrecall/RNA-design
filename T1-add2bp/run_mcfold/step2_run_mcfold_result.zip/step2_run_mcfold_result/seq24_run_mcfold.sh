#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGGGAAGGGCAACUUUUCUA&name=seq24&explore=50&top=100"
./mcfold.static.exe >seq24_5bp_267_add2bp_all_possible.data
