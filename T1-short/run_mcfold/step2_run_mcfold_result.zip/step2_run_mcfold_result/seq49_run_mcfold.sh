#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGUUUUCGCAAGGGGAA&name=seq49&top=100"
./mcfold.static.exe >seq49_P5c.dada
