#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGUUCCGCAAGGGGCA&name=seq408&top=100"
./mcfold.static.exe >seq408_P5c.dada
