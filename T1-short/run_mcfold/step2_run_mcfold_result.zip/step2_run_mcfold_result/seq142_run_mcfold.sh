#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGAGACUGCAAGGUUUA&name=seq142&top=100"
./mcfold.static.exe >seq142_P5c.dada
