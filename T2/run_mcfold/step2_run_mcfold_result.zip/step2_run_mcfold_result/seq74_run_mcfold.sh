#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUUAAAGCAAUUUGAA&name=seq74&top=100"
./mcfold.static.exe >seq74_p5clike_opposite_direction.data
