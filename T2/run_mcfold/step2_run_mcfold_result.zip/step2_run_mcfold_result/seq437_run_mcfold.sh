#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUGGGGGCAACUUUGA&name=seq437&top=100"
./mcfold.static.exe >seq437_p5clike_opposite_direction.data
