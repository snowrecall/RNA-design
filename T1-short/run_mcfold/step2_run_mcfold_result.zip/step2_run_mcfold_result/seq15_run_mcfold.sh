#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGUUUCUGCAAGGGAAA&name=seq15&top=100"
./mcfold.static.exe >seq15_P5c.dada
