#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGUUUUGCAAGGAGCA&name=seq399&top=100"
./mcfold.static.exe >seq399_P5c.dada
