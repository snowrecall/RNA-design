#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGGGAGCAAUUCUCA&name=seq178&top=100"
./mcfold.static.exe >seq178_p5clike_opposite_direction.data
