#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGUUUUGCAAAAGGCA&name=seq405&top=100"
./mcfold.static.exe >seq405_P5c.dada
