#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUCCUGGCAAUGGGGA&name=seq297&top=100"
./mcfold.static.exe >seq297_p5clike_opposite_direction.data
