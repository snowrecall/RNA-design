#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGGAGUGCAAAUUUCA&name=seq429&top=100"
./mcfold.static.exe >seq429_P5c.dada
