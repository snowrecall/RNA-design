#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUUUGGGCAACUAAGA&name=seq199&top=100"
./mcfold.static.exe >seq199_p5clike_opposite_direction.data
