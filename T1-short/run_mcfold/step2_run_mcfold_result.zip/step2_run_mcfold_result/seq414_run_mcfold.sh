#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGGUUUGCAAGAAUCA&name=seq414&top=100"
./mcfold.static.exe >seq414_P5c.dada
