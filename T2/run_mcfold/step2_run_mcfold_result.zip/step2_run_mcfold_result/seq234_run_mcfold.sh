#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUUGGGGCAACUUAGA&name=seq234&top=100"
./mcfold.static.exe >seq234_p5clike_opposite_direction.data
