#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUGGGGGCAAUUCUAA&name=seq149&top=100"
./mcfold.static.exe >seq149_p5clike_opposite_direction.data
