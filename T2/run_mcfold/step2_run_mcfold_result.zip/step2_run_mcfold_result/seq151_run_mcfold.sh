#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUGGAGGCAACUUUAA&name=seq151&top=100"
./mcfold.static.exe >seq151_p5clike_opposite_direction.data
