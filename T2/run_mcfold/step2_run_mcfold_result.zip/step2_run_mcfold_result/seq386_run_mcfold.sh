#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUUCUUGCAAGGGGGA&name=seq386&top=100"
./mcfold.static.exe >seq386_p5clike_opposite_direction.data
