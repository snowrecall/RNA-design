#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGAGGGUGCAAGUCUUA&name=seq177&top=100"
./mcfold.static.exe >seq177_P5c.dada
