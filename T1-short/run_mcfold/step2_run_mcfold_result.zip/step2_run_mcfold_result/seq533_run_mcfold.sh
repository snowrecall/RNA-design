#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGUUUUUGCAAAAGGGA&name=seq533&top=100"
./mcfold.static.exe >seq533_P5c.dada
