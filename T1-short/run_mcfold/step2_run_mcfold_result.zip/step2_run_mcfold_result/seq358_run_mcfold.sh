#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGGGGGGCAACUCCCA&name=seq358&top=100"
./mcfold.static.exe >seq358_P5c.dada
