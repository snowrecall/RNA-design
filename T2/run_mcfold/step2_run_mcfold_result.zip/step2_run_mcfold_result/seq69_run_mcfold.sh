#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUUUUUGCAAGGAGAA&name=seq69&top=100"
./mcfold.static.exe >seq69_p5clike_opposite_direction.data
