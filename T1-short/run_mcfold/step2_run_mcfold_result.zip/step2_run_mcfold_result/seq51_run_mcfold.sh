#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGAAACUGCAAGGUUUA&name=seq51&top=100"
./mcfold.static.exe >seq51_P5c.dada
