#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGAGUCGCAAGAUUCA&name=seq284&top=100"
./mcfold.static.exe >seq284_P5c.dada
