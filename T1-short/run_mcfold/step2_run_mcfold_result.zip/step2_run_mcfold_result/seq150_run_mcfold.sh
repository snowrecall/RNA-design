#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGAGAGGGCAAUUUUUA&name=seq150&top=100"
./mcfold.static.exe >seq150_P5c.dada
