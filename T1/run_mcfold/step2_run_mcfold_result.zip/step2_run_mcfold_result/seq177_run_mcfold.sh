#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGCGCGCCUGGAAGGGCAACUUUCACCUCGCGCC&name=seq177&top=100"
./mcfold.static.exe >seq177_5bp_267_GCstem_3nt_bulges.data
