#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGAGGGCAACCUUCA&name=seq171&top=100"
./mcfold.static.exe >seq171_p5clike_opposite_direction.data
