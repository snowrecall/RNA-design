#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGUUCUGCAAGGGGCA&name=seq409&top=100"
./mcfold.static.exe >seq409_P5c.dada
