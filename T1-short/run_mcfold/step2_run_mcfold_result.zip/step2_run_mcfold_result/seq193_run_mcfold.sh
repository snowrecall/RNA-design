#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGAGGGUGCAAACUUUA&name=seq193&top=100"
./mcfold.static.exe >seq193_P5c.dada
