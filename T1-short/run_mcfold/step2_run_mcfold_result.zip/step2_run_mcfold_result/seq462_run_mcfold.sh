#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGGUUUGCAAAAGUCA&name=seq462&top=100"
./mcfold.static.exe >seq462_P5c.dada
