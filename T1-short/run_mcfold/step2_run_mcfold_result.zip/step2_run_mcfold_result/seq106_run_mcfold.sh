#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGACUUUGCAAAGGGUA&name=seq106&top=100"
./mcfold.static.exe >seq106_P5c.dada
