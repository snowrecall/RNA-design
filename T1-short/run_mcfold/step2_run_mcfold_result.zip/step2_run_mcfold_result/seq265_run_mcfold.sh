#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGAAGAGCAAUUUUCA&name=seq265&top=100"
./mcfold.static.exe >seq265_P5c.dada
