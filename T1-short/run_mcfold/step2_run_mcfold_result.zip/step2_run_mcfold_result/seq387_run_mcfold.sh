#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGGGGAGCAAUUUCCA&name=seq387&top=100"
./mcfold.static.exe >seq387_P5c.dada
