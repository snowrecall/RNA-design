#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGUUUUGCAAAGGGCA&name=seq410&top=100"
./mcfold.static.exe >seq410_P5c.dada
