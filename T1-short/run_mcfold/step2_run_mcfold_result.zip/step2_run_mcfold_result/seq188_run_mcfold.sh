#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGAGGACGCAAGUUUUA&name=seq188&top=100"
./mcfold.static.exe >seq188_P5c.dada
