#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGGAACGCAAGUUUCA&name=seq421&top=100"
./mcfold.static.exe >seq421_P5c.dada
