#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGCUUUGCAAGGGGCA&name=seq317&top=100"
./mcfold.static.exe >seq317_P5c.dada
