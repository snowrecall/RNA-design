#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGCUUUGCAAAGGGCA&name=seq315&top=100"
./mcfold.static.exe >seq315_P5c.dada
