#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGGCAAGGGCAACUUUGCUA&name=seq20&explore=50&top=100"
./mcfold.static.exe >seq20_5bp_267_add2bp_all_possible.data
