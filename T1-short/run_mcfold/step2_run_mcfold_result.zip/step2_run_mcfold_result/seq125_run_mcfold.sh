#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGAUUCCGCAAGGGGUA&name=seq125&top=100"
./mcfold.static.exe >seq125_P5c.dada
