#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGUCCCUGCAAGGGGGA&name=seq509&top=100"
./mcfold.static.exe >seq509_P5c.dada
