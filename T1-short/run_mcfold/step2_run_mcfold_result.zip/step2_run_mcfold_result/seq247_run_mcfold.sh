#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGUCUUGCAAGGGACA&name=seq247&top=100"
./mcfold.static.exe >seq247_P5c.dada
