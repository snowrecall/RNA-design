#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGAGGGGCAACCUUUA&name=seq452&top=100"
./mcfold.static.exe >seq452_p5clike_opposite_direction.data
