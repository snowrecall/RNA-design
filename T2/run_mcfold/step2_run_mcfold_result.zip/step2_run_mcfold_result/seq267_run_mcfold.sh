#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUCUUGGCAAUGAGGA&name=seq267&top=100"
./mcfold.static.exe >seq267_p5clike_opposite_direction.data
