#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGGGGGCAAUUUCUA&name=seq467&top=100"
./mcfold.static.exe >seq467_p5clike_opposite_direction.data
