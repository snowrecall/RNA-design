#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGAGGAGCAAUCUUCA&name=seq293&top=100"
./mcfold.static.exe >seq293_P5c.dada
