#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUCUAGGCAAUUGGGA&name=seq309&top=100"
./mcfold.static.exe >seq309_p5clike_opposite_direction.data
