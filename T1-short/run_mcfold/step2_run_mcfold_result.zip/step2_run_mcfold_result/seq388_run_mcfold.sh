#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGGGGCGCAAGUUCCA&name=seq388&top=100"
./mcfold.static.exe >seq388_P5c.dada
