#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUCUGAGCAAUUGGGA&name=seq323&top=100"
./mcfold.static.exe >seq323_p5clike_opposite_direction.data
