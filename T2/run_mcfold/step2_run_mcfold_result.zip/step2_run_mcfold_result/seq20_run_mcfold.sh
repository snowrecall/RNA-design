#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUUUUGGCAAUAGAAA&name=seq20&top=100"
./mcfold.static.exe >seq20_p5clike_opposite_direction.data
