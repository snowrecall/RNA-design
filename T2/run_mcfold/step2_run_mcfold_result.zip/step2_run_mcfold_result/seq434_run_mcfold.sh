#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUGGGGGCAACCUUGA&name=seq434&top=100"
./mcfold.static.exe >seq434_p5clike_opposite_direction.data
