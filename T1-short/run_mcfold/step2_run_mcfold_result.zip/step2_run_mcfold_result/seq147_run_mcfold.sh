#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGAGAGCGCAAGUUUUA&name=seq147&top=100"
./mcfold.static.exe >seq147_P5c.dada
