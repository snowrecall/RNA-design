#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGAGGAUGCAAGUUUUA&name=seq189&top=100"
./mcfold.static.exe >seq189_P5c.dada
