#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGAGGGGGCAAUUCUUA&name=seq178&top=100"
./mcfold.static.exe >seq178_P5c.dada
