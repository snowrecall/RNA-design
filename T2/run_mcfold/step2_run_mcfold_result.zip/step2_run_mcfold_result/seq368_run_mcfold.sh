#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUUCUUGCAAAAGGGA&name=seq368&top=100"
./mcfold.static.exe >seq368_p5clike_opposite_direction.data
