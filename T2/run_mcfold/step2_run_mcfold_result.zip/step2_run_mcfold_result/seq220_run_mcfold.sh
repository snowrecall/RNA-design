#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUUUUUGCAAAGGAGA&name=seq220&top=100"
./mcfold.static.exe >seq220_p5clike_opposite_direction.data
