#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGCUCCCGCAAGGGGGA&name=seq225&top=100"
./mcfold.static.exe >seq225_P5c.dada
