#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGUCUUUGCAAGGGGAA&name=seq30&top=100"
./mcfold.static.exe >seq30_P5c.dada
