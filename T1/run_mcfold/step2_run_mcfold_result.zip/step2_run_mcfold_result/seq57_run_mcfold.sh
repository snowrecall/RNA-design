#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGCGCGACUGGAAGGGCAACUUUCACACCGCGCC&name=seq57&top=100"
./mcfold.static.exe >seq57_5bp_267_GCstem_3nt_bulges.data
