#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGUCCUGCAAGGGACA&name=seq244&top=100"
./mcfold.static.exe >seq244_P5c.dada
