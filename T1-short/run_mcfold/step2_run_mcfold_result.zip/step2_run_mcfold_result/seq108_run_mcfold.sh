#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGACUUUGCAAGGGGUA&name=seq108&top=100"
./mcfold.static.exe >seq108_P5c.dada
