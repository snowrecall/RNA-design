#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGGGUUGCAAGACUCA&name=seq442&top=100"
./mcfold.static.exe >seq442_P5c.dada
