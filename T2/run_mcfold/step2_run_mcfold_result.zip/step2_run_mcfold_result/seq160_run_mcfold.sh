#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGGAAGCAAUUUCCA&name=seq160&top=100"
./mcfold.static.exe >seq160_p5clike_opposite_direction.data
