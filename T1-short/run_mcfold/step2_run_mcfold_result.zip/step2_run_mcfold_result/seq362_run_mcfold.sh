#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGGUUCGCAAGAGCCA&name=seq362&top=100"
./mcfold.static.exe >seq362_P5c.dada
