#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGGUUCGCAAGGGUCA&name=seq466&top=100"
./mcfold.static.exe >seq466_P5c.dada
