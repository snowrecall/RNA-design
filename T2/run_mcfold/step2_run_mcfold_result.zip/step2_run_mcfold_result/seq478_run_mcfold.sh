#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGGGAGCAAUUCUUA&name=seq478&top=100"
./mcfold.static.exe >seq478_p5clike_opposite_direction.data
