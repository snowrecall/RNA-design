#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGUUUUGCAAGGAACA&name=seq242&top=100"
./mcfold.static.exe >seq242_P5c.dada
