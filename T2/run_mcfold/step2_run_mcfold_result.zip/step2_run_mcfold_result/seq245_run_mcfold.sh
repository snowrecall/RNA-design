#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUAGGAGCAAUUCUGA&name=seq245&top=100"
./mcfold.static.exe >seq245_p5clike_opposite_direction.data
