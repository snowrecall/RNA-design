#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGAGGACGCAAGUCUUA&name=seq160&top=100"
./mcfold.static.exe >seq160_P5c.dada
