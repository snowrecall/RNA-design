#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGGAUCGCAAGGUUCA&name=seq427&top=100"
./mcfold.static.exe >seq427_P5c.dada
