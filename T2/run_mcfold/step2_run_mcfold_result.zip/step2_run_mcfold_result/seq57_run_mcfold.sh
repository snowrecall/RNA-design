#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUGGGAGCAAUUUCAA&name=seq57&top=100"
./mcfold.static.exe >seq57_p5clike_opposite_direction.data
