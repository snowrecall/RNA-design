#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUUGGGGCAACUUGAA&name=seq135&top=100"
./mcfold.static.exe >seq135_p5clike_opposite_direction.data
