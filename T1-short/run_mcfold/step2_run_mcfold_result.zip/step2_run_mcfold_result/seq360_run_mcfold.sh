#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGGGGGGCAAUUCCCA&name=seq360&top=100"
./mcfold.static.exe >seq360_P5c.dada
