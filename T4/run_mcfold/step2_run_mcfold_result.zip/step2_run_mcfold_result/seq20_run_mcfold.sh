#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGGGGUGCUUCGGCCUUCUC&name=seq20&explore=50&top=100"
./mcfold.static.exe >seq20_p5clike_1bulgeout.data
