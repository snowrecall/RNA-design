#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGCGCGCCCGGAAGGGCAACUUUCAUACCGCGCC&name=seq203&top=100"
./mcfold.static.exe >seq203_5bp_267_GCstem_3nt_bulges.data
