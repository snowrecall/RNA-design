#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUUUAGGCAAUUGGAA&name=seq116&top=100"
./mcfold.static.exe >seq116_p5clike_opposite_direction.data
