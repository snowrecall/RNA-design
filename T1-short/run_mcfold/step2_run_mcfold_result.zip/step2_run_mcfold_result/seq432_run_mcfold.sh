#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGGAGGGCAACUUUCA&name=seq432&top=100"
./mcfold.static.exe >seq432_P5c.dada
