#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGAGUUCGCAAGAAUUA&name=seq130&top=100"
./mcfold.static.exe >seq130_P5c.dada
