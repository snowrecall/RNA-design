#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUUUGGGCAACCAGGA&name=seq349&top=100"
./mcfold.static.exe >seq349_p5clike_opposite_direction.data
