#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGUUUUUGCAAAAGGAA&name=seq43&top=100"
./mcfold.static.exe >seq43_P5c.dada
