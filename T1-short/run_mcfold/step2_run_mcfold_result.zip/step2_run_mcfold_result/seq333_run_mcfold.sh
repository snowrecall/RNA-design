#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGGAUCGCAAGGUCCA&name=seq333&top=100"
./mcfold.static.exe >seq333_P5c.dada
