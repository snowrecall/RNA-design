#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGUUUUUGCAAAGGAAA&name=seq16&top=100"
./mcfold.static.exe >seq16_P5c.dada
