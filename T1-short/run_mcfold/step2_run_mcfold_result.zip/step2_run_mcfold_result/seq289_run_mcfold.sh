#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGAGAGGCAAUUUUCA&name=seq289&top=100"
./mcfold.static.exe >seq289_P5c.dada
