#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGCUCCUGCAAGGGGGA&name=seq226&top=100"
./mcfold.static.exe >seq226_P5c.dada
