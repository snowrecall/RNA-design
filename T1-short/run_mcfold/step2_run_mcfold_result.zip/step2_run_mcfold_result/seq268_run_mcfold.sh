#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGAAGUGCAAGUUUCA&name=seq268&top=100"
./mcfold.static.exe >seq268_P5c.dada
