#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGAAUUGCAAGGUUCA&name=seq263&top=100"
./mcfold.static.exe >seq263_P5c.dada
