#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGUUUUCGCAAGGAAAA&name=seq4&top=100"
./mcfold.static.exe >seq4_P5c.dada
