#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGGGUUGCAAAAUCCA&name=seq369&top=100"
./mcfold.static.exe >seq369_P5c.dada
