#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGAAGAGCAAUUUUUA&name=seq442&top=100"
./mcfold.static.exe >seq442_p5clike_opposite_direction.data
