#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGAUCUUGCAAAGGGUA&name=seq119&top=100"
./mcfold.static.exe >seq119_P5c.dada
