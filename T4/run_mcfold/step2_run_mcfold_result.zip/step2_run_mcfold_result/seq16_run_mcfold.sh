#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGAGAGUGCUUCGGCCUUUUC&name=seq16&explore=50&top=100"
./mcfold.static.exe >seq16_p5clike_1bulgeout.data
