#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGAGCCCGCAAGGGUUA&name=seq151&top=100"
./mcfold.static.exe >seq151_P5c.dada
