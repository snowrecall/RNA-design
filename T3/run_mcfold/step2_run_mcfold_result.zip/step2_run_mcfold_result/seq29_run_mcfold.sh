#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=AGGGUGCGCAAGCACUA&name=seq29&explore=50&top=100"
./mcfold.static.exe >seq29_like_p5c_shift_2bp_type3.data
