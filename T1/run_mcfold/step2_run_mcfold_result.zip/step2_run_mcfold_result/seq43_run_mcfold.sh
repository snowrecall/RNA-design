#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGCGCGAAAGGAAGGGCAACUUUCAACCCGCGCC&name=seq43&top=100"
./mcfold.static.exe >seq43_5bp_267_GCstem_3nt_bulges.data
