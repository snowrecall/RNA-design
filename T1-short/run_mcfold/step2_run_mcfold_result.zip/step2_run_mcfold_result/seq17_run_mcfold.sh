#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGUUUUCGCAAGGGAAA&name=seq17&top=100"
./mcfold.static.exe >seq17_P5c.dada
