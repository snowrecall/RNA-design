#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUUCAGGCAACUGGAA&name=seq87&top=100"
./mcfold.static.exe >seq87_p5clike_opposite_direction.data
