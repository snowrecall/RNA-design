#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUUUUAGCAAUGAGGA&name=seq352&top=100"
./mcfold.static.exe >seq352_p5clike_opposite_direction.data
