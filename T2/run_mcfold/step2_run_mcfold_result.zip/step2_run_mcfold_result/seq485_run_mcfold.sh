#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGGGGGCAAUCUUUA&name=seq485&top=100"
./mcfold.static.exe >seq485_p5clike_opposite_direction.data
