#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGUCUUUGCAAAGGGGA&name=seq517&top=100"
./mcfold.static.exe >seq517_P5c.dada
