#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGCGCGUCAGGAAGGGCAACUUUCACACCGCGCC&name=seq92&top=100"
./mcfold.static.exe >seq92_5bp_267_GCstem_3nt_bulges.data
