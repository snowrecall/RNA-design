#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGAGUCCGCAAGGAUUA&name=seq132&top=100"
./mcfold.static.exe >seq132_P5c.dada
