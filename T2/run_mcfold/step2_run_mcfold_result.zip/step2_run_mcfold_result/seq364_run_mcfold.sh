#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUUAGGGCAAUCUGGA&name=seq364&top=100"
./mcfold.static.exe >seq364_p5clike_opposite_direction.data
