#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUGGAGGCAAUUUCGA&name=seq339&top=100"
./mcfold.static.exe >seq339_p5clike_opposite_direction.data
