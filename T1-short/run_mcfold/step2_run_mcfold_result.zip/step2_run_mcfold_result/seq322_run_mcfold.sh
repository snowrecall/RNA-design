#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGGUCUGCAAGGACCA&name=seq322&top=100"
./mcfold.static.exe >seq322_P5c.dada
