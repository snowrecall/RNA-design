#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUUGGGGCAAUCCGAA&name=seq106&top=100"
./mcfold.static.exe >seq106_p5clike_opposite_direction.data
