#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUGGGGGCAACUCUGA&name=seq429&top=100"
./mcfold.static.exe >seq429_p5clike_opposite_direction.data
