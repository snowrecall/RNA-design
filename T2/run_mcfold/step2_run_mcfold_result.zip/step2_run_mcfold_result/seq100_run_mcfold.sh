#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUUCUUGCAAGGGGAA&name=seq100&top=100"
./mcfold.static.exe >seq100_p5clike_opposite_direction.data
