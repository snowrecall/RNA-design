#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGAGGGGGCAAUCCUUA&name=seq169&top=100"
./mcfold.static.exe >seq169_P5c.dada
