#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGAAACGCAAGUUUCA&name=seq256&top=100"
./mcfold.static.exe >seq256_P5c.dada
