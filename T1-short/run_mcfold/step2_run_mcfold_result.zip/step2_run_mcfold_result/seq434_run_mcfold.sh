#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGGAGGGCAAUUUUCA&name=seq434&top=100"
./mcfold.static.exe >seq434_P5c.dada
