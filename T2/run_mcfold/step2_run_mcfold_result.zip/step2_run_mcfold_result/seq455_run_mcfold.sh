#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGAGGGGCAACUUUUA&name=seq455&top=100"
./mcfold.static.exe >seq455_p5clike_opposite_direction.data
