#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGUUUCCGCAAGGGGAA&name=seq46&top=100"
./mcfold.static.exe >seq46_P5c.dada
