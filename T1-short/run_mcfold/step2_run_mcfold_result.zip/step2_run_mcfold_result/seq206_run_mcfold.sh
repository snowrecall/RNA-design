#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGCCCUUGCAAAGGGGA&name=seq206&top=100"
./mcfold.static.exe >seq206_P5c.dada
