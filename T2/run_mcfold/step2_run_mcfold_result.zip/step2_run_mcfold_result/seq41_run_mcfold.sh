#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUUGAGGCAACUUAAA&name=seq41&top=100"
./mcfold.static.exe >seq41_p5clike_opposite_direction.data
