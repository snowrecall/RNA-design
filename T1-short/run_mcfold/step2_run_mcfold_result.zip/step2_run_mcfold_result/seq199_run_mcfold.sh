#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGAGGUUGCAAAGUUUA&name=seq199&top=100"
./mcfold.static.exe >seq199_P5c.dada
