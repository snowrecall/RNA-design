#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGAAGGCAAUUUCA&name=seq5&top=100"
./mcfold.static.exe >seq5_5bp_267_minus1bp_all_possible.data
