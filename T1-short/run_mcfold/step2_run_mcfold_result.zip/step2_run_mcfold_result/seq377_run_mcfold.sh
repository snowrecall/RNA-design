#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGGGCUGCAAGGUCCA&name=seq377&top=100"
./mcfold.static.exe >seq377_P5c.dada
