#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUUUAGGCAACUGAAA&name=seq22&top=100"
./mcfold.static.exe >seq22_p5clike_opposite_direction.data
