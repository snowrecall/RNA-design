#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGAGCUCGCAAGGGUUA&name=seq154&top=100"
./mcfold.static.exe >seq154_P5c.dada
