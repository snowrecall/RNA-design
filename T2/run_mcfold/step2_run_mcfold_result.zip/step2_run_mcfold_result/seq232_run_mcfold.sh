#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUUGGGGCAAUCUAGA&name=seq232&top=100"
./mcfold.static.exe >seq232_p5clike_opposite_direction.data
