#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGUUCUGCAAGGAGCA&name=seq396&top=100"
./mcfold.static.exe >seq396_P5c.dada
