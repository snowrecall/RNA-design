#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGGGGUGCUUCGGCCCCUCC&name=seq7&explore=50&top=100"
./mcfold.static.exe >seq7_p5clike_1bulgeout.data
