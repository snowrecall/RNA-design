#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGUUUUGCAAGAAACA&name=seq237&top=100"
./mcfold.static.exe >seq237_P5c.dada
