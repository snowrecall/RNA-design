#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUUUCUGCAAAGGGAA&name=seq117&top=100"
./mcfold.static.exe >seq117_p5clike_opposite_direction.data
