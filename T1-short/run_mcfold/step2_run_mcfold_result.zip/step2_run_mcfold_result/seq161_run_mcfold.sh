#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGAGGAUGCAAGUCUUA&name=seq161&top=100"
./mcfold.static.exe >seq161_P5c.dada
