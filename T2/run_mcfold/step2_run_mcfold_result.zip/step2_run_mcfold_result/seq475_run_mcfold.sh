#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGAGGGCAAUUUUUA&name=seq475&top=100"
./mcfold.static.exe >seq475_p5clike_opposite_direction.data
