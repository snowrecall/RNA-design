#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUCUUUGCAAGAAGGA&name=seq258&top=100"
./mcfold.static.exe >seq258_p5clike_opposite_direction.data
