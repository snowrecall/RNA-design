#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUGGGGGCAACCUCGA&name=seq340&top=100"
./mcfold.static.exe >seq340_p5clike_opposite_direction.data
