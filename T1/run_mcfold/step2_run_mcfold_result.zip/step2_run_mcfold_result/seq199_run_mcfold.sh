#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGCGCGCCAGGAAGGGCAACUUUCAAACCGCGCC&name=seq199&top=100"
./mcfold.static.exe >seq199_5bp_267_GCstem_3nt_bulges.data
