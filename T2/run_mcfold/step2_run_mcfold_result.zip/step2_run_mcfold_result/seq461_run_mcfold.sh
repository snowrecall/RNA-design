#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGGAAGCAAUUUCUA&name=seq461&top=100"
./mcfold.static.exe >seq461_p5clike_opposite_direction.data
