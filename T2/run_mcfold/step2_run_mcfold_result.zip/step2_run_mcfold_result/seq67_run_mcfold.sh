#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUUUUCGCAAGGAGAA&name=seq67&top=100"
./mcfold.static.exe >seq67_p5clike_opposite_direction.data
