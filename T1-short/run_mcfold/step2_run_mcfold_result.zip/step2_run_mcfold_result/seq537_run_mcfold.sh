#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGUUUCUGCAAGGGGGA&name=seq537&top=100"
./mcfold.static.exe >seq537_P5c.dada
