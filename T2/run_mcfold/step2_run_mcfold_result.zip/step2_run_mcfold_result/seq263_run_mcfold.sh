#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUCUUAGCAAUGAGGA&name=seq263&top=100"
./mcfold.static.exe >seq263_p5clike_opposite_direction.data
