#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUCUCAGCAAUGGGGA&name=seq311&top=100"
./mcfold.static.exe >seq311_p5clike_opposite_direction.data
