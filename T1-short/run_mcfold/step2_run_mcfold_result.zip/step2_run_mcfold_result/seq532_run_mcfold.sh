#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGUUCUUGCAAGGGGGA&name=seq532&top=100"
./mcfold.static.exe >seq532_P5c.dada
