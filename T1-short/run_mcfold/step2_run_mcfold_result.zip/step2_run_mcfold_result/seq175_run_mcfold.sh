#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGAGGGCGCAAGUCUUA&name=seq175&top=100"
./mcfold.static.exe >seq175_P5c.dada
