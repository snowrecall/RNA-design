#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUUUGAGCAAUUAAAA&name=seq9&top=100"
./mcfold.static.exe >seq9_p5clike_opposite_direction.data
