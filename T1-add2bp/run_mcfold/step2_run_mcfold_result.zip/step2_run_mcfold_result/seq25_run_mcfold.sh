#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGGUAAGGGCAACUUUACUA&name=seq25&explore=50&top=100"
./mcfold.static.exe >seq25_5bp_267_add2bp_all_possible.data
