#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGGGUUGCAAGAUUCA&name=seq470&top=100"
./mcfold.static.exe >seq470_P5c.dada
