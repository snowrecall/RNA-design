#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGCGCGCCCGGAAGGGCAACUUUCAUUUCGCGCC&name=seq173&top=100"
./mcfold.static.exe >seq173_5bp_267_GCstem_3nt_bulges.data
