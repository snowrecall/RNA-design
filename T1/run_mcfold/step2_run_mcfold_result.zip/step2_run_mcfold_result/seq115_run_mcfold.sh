#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGCGCGCAAGGAAGGGCAACUUUCAACACGCGCC&name=seq115&top=100"
./mcfold.static.exe >seq115_5bp_267_GCstem_3nt_bulges.data
