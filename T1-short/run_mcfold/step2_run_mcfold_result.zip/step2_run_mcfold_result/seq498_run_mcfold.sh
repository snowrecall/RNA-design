#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGUUCCUGCAAGGGAGA&name=seq498&top=100"
./mcfold.static.exe >seq498_P5c.dada
