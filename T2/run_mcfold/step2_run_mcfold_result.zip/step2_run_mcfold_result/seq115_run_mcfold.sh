#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUUUAGGCAACUGGAA&name=seq115&top=100"
./mcfold.static.exe >seq115_p5clike_opposite_direction.data
