#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGCGCGCUCGGAAGGGCAACUUUCAACACGCGCC&name=seq124&top=100"
./mcfold.static.exe >seq124_5bp_267_GCstem_3nt_bulges.data
