#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUAGGGGCAACCUUGA&name=seq251&top=100"
./mcfold.static.exe >seq251_p5clike_opposite_direction.data
