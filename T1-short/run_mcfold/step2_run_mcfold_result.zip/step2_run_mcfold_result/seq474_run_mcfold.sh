#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGGGAGGCAAUUUUCA&name=seq474&top=100"
./mcfold.static.exe >seq474_P5c.dada
