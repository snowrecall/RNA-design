#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGGGGGCAAUUCUCA&name=seq179&top=100"
./mcfold.static.exe >seq179_p5clike_opposite_direction.data
