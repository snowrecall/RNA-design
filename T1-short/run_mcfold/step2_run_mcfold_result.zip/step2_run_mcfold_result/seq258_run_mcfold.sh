#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGAAAGGCAAUUUUCA&name=seq258&top=100"
./mcfold.static.exe >seq258_P5c.dada
