#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUGGGGGCAAUCCUGA&name=seq427&top=100"
./mcfold.static.exe >seq427_p5clike_opposite_direction.data
