#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGAGGGAGCAAUUCUUA&name=seq174&top=100"
./mcfold.static.exe >seq174_P5c.dada
