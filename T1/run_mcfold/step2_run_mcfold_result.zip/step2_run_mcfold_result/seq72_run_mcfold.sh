#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGCGCGACCGGAAGGGCAACUUUCACCCCGCGCC&name=seq72&top=100"
./mcfold.static.exe >seq72_5bp_267_GCstem_3nt_bulges.data
