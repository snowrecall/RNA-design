#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUCUGGGCAACUAGGA&name=seq269&top=100"
./mcfold.static.exe >seq269_p5clike_opposite_direction.data
