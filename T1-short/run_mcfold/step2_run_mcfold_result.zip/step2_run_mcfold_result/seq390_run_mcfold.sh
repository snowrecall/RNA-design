#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGGGGUGCAAGUUCCA&name=seq390&top=100"
./mcfold.static.exe >seq390_P5c.dada
