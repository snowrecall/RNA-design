#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGAUUUUGCAAAGGGUA&name=seq127&top=100"
./mcfold.static.exe >seq127_P5c.dada
