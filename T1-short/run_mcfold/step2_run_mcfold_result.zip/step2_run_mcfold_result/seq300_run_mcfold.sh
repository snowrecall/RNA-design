#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGAGGUGCAAAUUUCA&name=seq300&top=100"
./mcfold.static.exe >seq300_P5c.dada
