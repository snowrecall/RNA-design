#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGUUCCGCAAGGGACA&name=seq251&top=100"
./mcfold.static.exe >seq251_P5c.dada
