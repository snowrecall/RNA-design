#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGCGCGCCUGGAAGGGCAACUUUCACAUCGCGCC&name=seq165&top=100"
./mcfold.static.exe >seq165_5bp_267_GCstem_3nt_bulges.data
