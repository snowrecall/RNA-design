#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUCUGGGCAAUCGGGA&name=seq316&top=100"
./mcfold.static.exe >seq316_p5clike_opposite_direction.data
