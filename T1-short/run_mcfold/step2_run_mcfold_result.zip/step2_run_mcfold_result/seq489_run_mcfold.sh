#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGGGGUGCAAGUUUCA&name=seq489&top=100"
./mcfold.static.exe >seq489_P5c.dada
