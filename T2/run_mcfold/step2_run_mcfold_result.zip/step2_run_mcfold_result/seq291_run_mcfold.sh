#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUCCGGGCAAUCGGGA&name=seq291&top=100"
./mcfold.static.exe >seq291_p5clike_opposite_direction.data
