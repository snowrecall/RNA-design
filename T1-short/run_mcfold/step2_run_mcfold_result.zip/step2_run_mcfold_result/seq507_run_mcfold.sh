#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGUUUUCGCAAGGGAGA&name=seq507&top=100"
./mcfold.static.exe >seq507_P5c.dada
