#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGGAGCGCAAGUUCCA&name=seq337&top=100"
./mcfold.static.exe >seq337_P5c.dada
