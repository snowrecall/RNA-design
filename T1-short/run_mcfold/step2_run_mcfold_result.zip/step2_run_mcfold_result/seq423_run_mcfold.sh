#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGGAAGGCAAUUUUCA&name=seq423&top=100"
./mcfold.static.exe >seq423_P5c.dada
