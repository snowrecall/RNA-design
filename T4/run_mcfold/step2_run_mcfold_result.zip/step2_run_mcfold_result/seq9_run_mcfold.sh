#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGGGGUGCUUCGGCCCUUCC&name=seq9&explore=50&top=100"
./mcfold.static.exe >seq9_p5clike_1bulgeout.data
