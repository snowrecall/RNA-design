#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUAGAGGCAAUUUUGA&name=seq250&top=100"
./mcfold.static.exe >seq250_p5clike_opposite_direction.data
