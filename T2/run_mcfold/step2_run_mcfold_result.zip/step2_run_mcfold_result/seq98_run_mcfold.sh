#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUUCUCGCAAGGGGAA&name=seq98&top=100"
./mcfold.static.exe >seq98_p5clike_opposite_direction.data
