#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGUUCUGCAAGGGACA&name=seq252&top=100"
./mcfold.static.exe >seq252_P5c.dada
