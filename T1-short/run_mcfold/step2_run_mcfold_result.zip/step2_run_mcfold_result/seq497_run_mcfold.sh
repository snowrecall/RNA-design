#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGUUCCCGCAAGGGAGA&name=seq497&top=100"
./mcfold.static.exe >seq497_P5c.dada
