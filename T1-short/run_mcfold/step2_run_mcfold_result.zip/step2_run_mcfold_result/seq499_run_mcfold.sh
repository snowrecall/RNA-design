#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGUUCUUGCAAAGGAGA&name=seq499&top=100"
./mcfold.static.exe >seq499_P5c.dada
