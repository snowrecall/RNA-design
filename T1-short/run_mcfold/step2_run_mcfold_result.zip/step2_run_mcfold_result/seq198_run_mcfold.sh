#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGAGGGGGCAAUCUUUA&name=seq198&top=100"
./mcfold.static.exe >seq198_P5c.dada
