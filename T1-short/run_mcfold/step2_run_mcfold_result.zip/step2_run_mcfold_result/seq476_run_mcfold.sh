#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGGGCUGCAAGGUUCA&name=seq476&top=100"
./mcfold.static.exe >seq476_P5c.dada
