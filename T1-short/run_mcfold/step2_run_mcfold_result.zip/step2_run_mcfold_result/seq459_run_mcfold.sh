#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGGGGCGCAAGUCUCA&name=seq459&top=100"
./mcfold.static.exe >seq459_P5c.dada
