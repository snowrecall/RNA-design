#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGAAGUGCAAAUUUCA&name=seq264&top=100"
./mcfold.static.exe >seq264_P5c.dada
