#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGUUUUUGCAAGGAGGA&name=seq527&top=100"
./mcfold.static.exe >seq527_P5c.dada
