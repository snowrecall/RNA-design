#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGUCCUUGCAAAGGGGA&name=seq510&top=100"
./mcfold.static.exe >seq510_P5c.dada
