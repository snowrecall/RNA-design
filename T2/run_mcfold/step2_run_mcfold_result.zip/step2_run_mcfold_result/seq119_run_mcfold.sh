#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUUUCCGCAAGGGGAA&name=seq119&top=100"
./mcfold.static.exe >seq119_p5clike_opposite_direction.data
