#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUCUUCGCAAGGAGGA&name=seq264&top=100"
./mcfold.static.exe >seq264_p5clike_opposite_direction.data
