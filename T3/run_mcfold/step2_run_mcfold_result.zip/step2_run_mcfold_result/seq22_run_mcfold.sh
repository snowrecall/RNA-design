#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=AGGAGUAGCAAUGCUUA&name=seq22&explore=50&top=100"
./mcfold.static.exe >seq22_like_p5c_shift_2bp_type3.data
