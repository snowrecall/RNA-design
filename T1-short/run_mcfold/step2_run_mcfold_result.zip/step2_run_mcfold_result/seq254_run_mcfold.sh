#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGUUUCGCAAGGGACA&name=seq254&top=100"
./mcfold.static.exe >seq254_P5c.dada
