#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGGGGUGCAAGCUCCA&name=seq382&top=100"
./mcfold.static.exe >seq382_P5c.dada
