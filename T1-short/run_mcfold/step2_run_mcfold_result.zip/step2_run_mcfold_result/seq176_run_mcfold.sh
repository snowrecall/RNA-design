#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGAGGGGGCAACUCUUA&name=seq176&top=100"
./mcfold.static.exe >seq176_P5c.dada
