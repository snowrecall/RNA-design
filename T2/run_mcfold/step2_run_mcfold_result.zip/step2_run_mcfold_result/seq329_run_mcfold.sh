#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUCGGGGCAAUCUGGA&name=seq329&top=100"
./mcfold.static.exe >seq329_p5clike_opposite_direction.data
