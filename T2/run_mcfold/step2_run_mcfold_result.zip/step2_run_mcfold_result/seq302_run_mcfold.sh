#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUCGGGGCAAUCCGGA&name=seq302&top=100"
./mcfold.static.exe >seq302_p5clike_opposite_direction.data
