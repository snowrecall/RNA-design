#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUUAGGGCAACUUGAA&name=seq80&top=100"
./mcfold.static.exe >seq80_p5clike_opposite_direction.data
