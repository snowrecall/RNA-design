#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGAGGGUGCAAGCCUUA&name=seq168&top=100"
./mcfold.static.exe >seq168_P5c.dada
