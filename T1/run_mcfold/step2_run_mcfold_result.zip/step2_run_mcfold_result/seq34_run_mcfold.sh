#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGCGCGACCGGAAGGGCAACUUUCAACACGCGCC&name=seq34&top=100"
./mcfold.static.exe >seq34_5bp_267_GCstem_3nt_bulges.data
