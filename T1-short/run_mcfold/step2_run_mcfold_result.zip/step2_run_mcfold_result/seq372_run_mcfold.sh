#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGGGAAGCAAUUUCCA&name=seq372&top=100"
./mcfold.static.exe >seq372_P5c.dada
