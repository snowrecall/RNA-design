#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUCUUCGCAAGGGGGA&name=seq319&top=100"
./mcfold.static.exe >seq319_p5clike_opposite_direction.data
