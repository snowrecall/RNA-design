#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUUUCGGCAAUGGGGA&name=seq408&top=100"
./mcfold.static.exe >seq408_p5clike_opposite_direction.data
