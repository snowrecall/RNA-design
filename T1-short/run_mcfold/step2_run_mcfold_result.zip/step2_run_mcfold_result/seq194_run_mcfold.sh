#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGAGGGAGCAAUCUUUA&name=seq194&top=100"
./mcfold.static.exe >seq194_P5c.dada
