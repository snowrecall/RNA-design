#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGAGCUUGCAAAGGUUA&name=seq153&top=100"
./mcfold.static.exe >seq153_P5c.dada
