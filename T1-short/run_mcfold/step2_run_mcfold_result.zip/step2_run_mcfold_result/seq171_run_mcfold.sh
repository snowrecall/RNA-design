#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGAGGUCGCAAGGCUUA&name=seq171&top=100"
./mcfold.static.exe >seq171_P5c.dada
