#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGAAGGUGCUUCGGCCUUUUC&name=seq13&explore=50&top=100"
./mcfold.static.exe >seq13_p5clike_1bulgeout.data
