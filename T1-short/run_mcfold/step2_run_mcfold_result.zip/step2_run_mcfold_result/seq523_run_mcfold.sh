#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGUUUCCGCAAGGAGGA&name=seq523&top=100"
./mcfold.static.exe >seq523_P5c.dada
