#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGAGGAGCAAUUUUCA&name=seq301&top=100"
./mcfold.static.exe >seq301_P5c.dada
