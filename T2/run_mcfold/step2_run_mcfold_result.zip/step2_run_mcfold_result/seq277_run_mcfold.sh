#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUCAGGGCAACUUGGA&name=seq277&top=100"
./mcfold.static.exe >seq277_p5clike_opposite_direction.data
