#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGAUUCUGCAAGGAGUA&name=seq113&top=100"
./mcfold.static.exe >seq113_P5c.dada
