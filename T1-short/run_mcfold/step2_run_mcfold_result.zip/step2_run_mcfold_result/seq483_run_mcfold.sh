#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGGGUUGCAAAGUUCA&name=seq483&top=100"
./mcfold.static.exe >seq483_P5c.dada
