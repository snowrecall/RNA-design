#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGCUUUUGCAAAGAGGA&name=seq222&top=100"
./mcfold.static.exe >seq222_P5c.dada
