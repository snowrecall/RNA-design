#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUUGAGGCAAUUUGGA&name=seq415&top=100"
./mcfold.static.exe >seq415_p5clike_opposite_direction.data
