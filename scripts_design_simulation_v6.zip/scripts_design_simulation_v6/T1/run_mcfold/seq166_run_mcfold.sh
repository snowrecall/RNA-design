#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGCGCGCCCGGAAGGGCAACUUUCAAAUCGCGCC&name=seq166&top=100"
./mcfold.static.exe >seq166_5bp_267_GCstem_3nt_bulges.data
