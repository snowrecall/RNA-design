#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUUGGGGCAAUCUGGA&name=seq417&top=100"
./mcfold.static.exe >seq417_p5clike_opposite_direction.data
