#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGUUUCGCAAGGAAUA&name=seq543&top=100"
./mcfold.static.exe >seq543_P5c.dada
