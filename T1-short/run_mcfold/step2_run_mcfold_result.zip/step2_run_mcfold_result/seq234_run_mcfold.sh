#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGCUUUUGCAAAGGGGA&name=seq234&top=100"
./mcfold.static.exe >seq234_P5c.dada
