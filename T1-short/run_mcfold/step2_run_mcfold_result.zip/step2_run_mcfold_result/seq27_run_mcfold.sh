#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGUCUCUGCAAGGGGAA&name=seq27&top=100"
./mcfold.static.exe >seq27_P5c.dada
