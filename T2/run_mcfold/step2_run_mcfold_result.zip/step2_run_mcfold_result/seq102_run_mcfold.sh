#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUUCGAGCAAUUGGAA&name=seq102&top=100"
./mcfold.static.exe >seq102_p5clike_opposite_direction.data
