#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUCCCAGCAAUGGGGA&name=seq287&top=100"
./mcfold.static.exe >seq287_p5clike_opposite_direction.data
