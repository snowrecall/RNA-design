#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGUUUUGCAAGAAGCA&name=seq394&top=100"
./mcfold.static.exe >seq394_P5c.dada
