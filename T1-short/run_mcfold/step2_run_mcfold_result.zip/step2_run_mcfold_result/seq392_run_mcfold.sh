#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGUUUUGCAAAAAGCA&name=seq392&top=100"
./mcfold.static.exe >seq392_P5c.dada
