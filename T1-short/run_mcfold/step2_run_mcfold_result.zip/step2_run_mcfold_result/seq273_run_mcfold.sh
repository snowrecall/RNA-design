#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGACUCGCAAGGGUCA&name=seq273&top=100"
./mcfold.static.exe >seq273_P5c.dada
