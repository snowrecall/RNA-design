#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUCCAAGCAAUUGGGA&name=seq283&top=100"
./mcfold.static.exe >seq283_p5clike_opposite_direction.data
