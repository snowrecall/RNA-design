#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGCGCGUCCGGAAGGGCAACUUUCAUACCGCGCC&name=seq95&top=100"
./mcfold.static.exe >seq95_5bp_267_GCstem_3nt_bulges.data
