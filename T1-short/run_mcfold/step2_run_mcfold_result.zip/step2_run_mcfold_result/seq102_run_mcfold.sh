#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGACUUCGCAAGAGGUA&name=seq102&top=100"
./mcfold.static.exe >seq102_P5c.dada
