#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGGCCUGCAAGGGUCA&name=seq436&top=100"
./mcfold.static.exe >seq436_P5c.dada
