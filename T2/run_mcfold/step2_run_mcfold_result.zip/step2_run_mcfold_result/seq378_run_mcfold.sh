#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUUCCGGCAACGGGGA&name=seq378&top=100"
./mcfold.static.exe >seq378_p5clike_opposite_direction.data
