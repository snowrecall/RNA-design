#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=AGGGUUCGCAAGGACUA&name=seq30&explore=50&top=100"
./mcfold.static.exe >seq30_like_p5c_shift_2bp_type3.data
