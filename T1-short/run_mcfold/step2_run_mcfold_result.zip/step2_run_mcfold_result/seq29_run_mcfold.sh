#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGUCUUCGCAAGGGGAA&name=seq29&top=100"
./mcfold.static.exe >seq29_P5c.dada
