#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGAUUUUGCAAAAGGUA&name=seq122&top=100"
./mcfold.static.exe >seq122_P5c.dada
