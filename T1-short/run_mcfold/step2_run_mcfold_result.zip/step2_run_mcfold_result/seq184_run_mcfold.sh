#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGAGGUUGCAAAAUUUA&name=seq184&top=100"
./mcfold.static.exe >seq184_P5c.dada
