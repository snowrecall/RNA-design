#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGUUCCCGCAAGGGGAA&name=seq38&top=100"
./mcfold.static.exe >seq38_P5c.dada
