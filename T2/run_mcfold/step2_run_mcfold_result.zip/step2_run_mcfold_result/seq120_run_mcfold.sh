#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUUUCGGCAACGGGAA&name=seq120&top=100"
./mcfold.static.exe >seq120_p5clike_opposite_direction.data
