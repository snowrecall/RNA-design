#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGAAGCGCAAGUUUCA&name=seq266&top=100"
./mcfold.static.exe >seq266_P5c.dada
