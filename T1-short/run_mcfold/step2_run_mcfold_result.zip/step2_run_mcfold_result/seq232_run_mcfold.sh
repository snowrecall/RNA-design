#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGCUUCCGCAAGGGGGA&name=seq232&top=100"
./mcfold.static.exe >seq232_P5c.dada
