#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUAAGGGCAACUUUGA&name=seq241&top=100"
./mcfold.static.exe >seq241_p5clike_opposite_direction.data
