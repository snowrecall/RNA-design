#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGAAGGGCAACUUUUA&name=seq443&top=100"
./mcfold.static.exe >seq443_p5clike_opposite_direction.data
