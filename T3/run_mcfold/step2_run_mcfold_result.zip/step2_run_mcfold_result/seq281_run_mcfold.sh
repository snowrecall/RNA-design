#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGAGUCGCAAGGCUCA&name=seq281&explore=50&top=100"
./mcfold.static.exe >seq281_like_p5c_shift_2bp_type3.data
