#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUUGGGGCAACCUAAA&name=seq43&top=100"
./mcfold.static.exe >seq43_p5clike_opposite_direction.data
