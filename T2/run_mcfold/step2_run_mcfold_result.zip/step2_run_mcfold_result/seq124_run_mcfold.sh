#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUUUGGGCAAUCGGAA&name=seq124&top=100"
./mcfold.static.exe >seq124_p5clike_opposite_direction.data
