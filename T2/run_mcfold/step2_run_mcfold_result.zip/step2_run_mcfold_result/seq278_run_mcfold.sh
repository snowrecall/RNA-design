#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUCAGGGCAAUUUGGA&name=seq278&top=100"
./mcfold.static.exe >seq278_p5clike_opposite_direction.data
