#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGAGGGCGCAAGCUUUA&name=seq195&top=100"
./mcfold.static.exe >seq195_P5c.dada
