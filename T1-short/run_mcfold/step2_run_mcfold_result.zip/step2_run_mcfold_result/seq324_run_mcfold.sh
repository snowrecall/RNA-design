#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGGUUCGCAAGGACCA&name=seq324&top=100"
./mcfold.static.exe >seq324_P5c.dada
