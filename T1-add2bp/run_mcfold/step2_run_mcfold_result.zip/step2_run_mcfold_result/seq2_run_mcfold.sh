#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGAGAAGGGCAACUUUCUUA&name=seq2&explore=50&top=100"
./mcfold.static.exe >seq2_5bp_267_add2bp_all_possible.data
