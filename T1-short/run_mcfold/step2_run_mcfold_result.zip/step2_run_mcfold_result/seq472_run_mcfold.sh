#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGGGACGCAAGUUUCA&name=seq472&top=100"
./mcfold.static.exe >seq472_P5c.dada
