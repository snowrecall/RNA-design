#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGUCCUUGCAAAGGGAA&name=seq20&top=100"
./mcfold.static.exe >seq20_P5c.dada
