#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGCUUCUGCAAGGGGGA&name=seq233&top=100"
./mcfold.static.exe >seq233_P5c.dada
