#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGGGGGCAACUCCUA&name=seq459&top=100"
./mcfold.static.exe >seq459_p5clike_opposite_direction.data
