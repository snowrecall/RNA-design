#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGUUUUGCAAAGAAUA&name=seq542&top=100"
./mcfold.static.exe >seq542_P5c.dada
