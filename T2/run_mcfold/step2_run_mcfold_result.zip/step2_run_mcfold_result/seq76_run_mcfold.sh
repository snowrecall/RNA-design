#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUUAAGGCAAUUUGAA&name=seq76&top=100"
./mcfold.static.exe >seq76_p5clike_opposite_direction.data
