#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUUGGGGCAAUUCAGA&name=seq205&top=100"
./mcfold.static.exe >seq205_p5clike_opposite_direction.data
