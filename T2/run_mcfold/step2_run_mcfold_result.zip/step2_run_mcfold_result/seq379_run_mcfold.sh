#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUUCCUGCAAGGGGGA&name=seq379&top=100"
./mcfold.static.exe >seq379_p5clike_opposite_direction.data
