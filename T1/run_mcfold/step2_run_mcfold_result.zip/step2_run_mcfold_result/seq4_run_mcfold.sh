#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGCGCGAACGGAAGGGCAACUUUCAAAACGCGCC&name=seq4&top=100"
./mcfold.static.exe >seq4_5bp_267_GCstem_3nt_bulges.data
