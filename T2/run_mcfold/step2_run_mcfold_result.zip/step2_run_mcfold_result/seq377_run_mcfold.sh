#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUUCCCGCAAGGGGGA&name=seq377&top=100"
./mcfold.static.exe >seq377_p5clike_opposite_direction.data
