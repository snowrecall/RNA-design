#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGGGAUGCAAGUUCCA&name=seq374&top=100"
./mcfold.static.exe >seq374_P5c.dada
