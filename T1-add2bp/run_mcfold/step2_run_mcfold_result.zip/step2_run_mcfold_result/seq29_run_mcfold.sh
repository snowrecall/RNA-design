#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGUGGAAGGGCAACUUUCUAA&name=seq29&explore=50&top=100"
./mcfold.static.exe >seq29_5bp_267_add2bp_all_possible.data
