#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUCUUAGCAAUGGGGA&name=seq318&top=100"
./mcfold.static.exe >seq318_p5clike_opposite_direction.data
