#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGAGUUUGCAAAAAUUA&name=seq129&top=100"
./mcfold.static.exe >seq129_P5c.dada
