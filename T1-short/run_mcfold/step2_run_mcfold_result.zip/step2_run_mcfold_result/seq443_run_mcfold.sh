#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGGGAAGCAAUUCUCA&name=seq443&top=100"
./mcfold.static.exe >seq443_P5c.dada
