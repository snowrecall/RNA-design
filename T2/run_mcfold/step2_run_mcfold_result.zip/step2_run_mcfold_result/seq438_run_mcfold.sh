#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGAAAGGCAACUUUUA&name=seq438&top=100"
./mcfold.static.exe >seq438_p5clike_opposite_direction.data
