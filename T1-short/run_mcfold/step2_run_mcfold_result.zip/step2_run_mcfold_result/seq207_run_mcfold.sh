#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGCCCUCGCAAGGGGGA&name=seq207&top=100"
./mcfold.static.exe >seq207_P5c.dada
