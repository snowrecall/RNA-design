#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUUAGGGCAAUUUGGA&name=seq367&top=100"
./mcfold.static.exe >seq367_p5clike_opposite_direction.data
