#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGAGACCGCAAGGUUUA&name=seq141&top=100"
./mcfold.static.exe >seq141_P5c.dada
