#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGAGUCCGCAAGGGUUA&name=seq179&top=100"
./mcfold.static.exe >seq179_P5c.dada
