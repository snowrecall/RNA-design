#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGGGGGGCAACCUCCA&name=seq381&top=100"
./mcfold.static.exe >seq381_P5c.dada
