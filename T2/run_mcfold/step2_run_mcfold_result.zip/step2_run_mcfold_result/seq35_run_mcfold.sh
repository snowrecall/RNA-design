#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUUUUGGCAACGGAAA&name=seq35&top=100"
./mcfold.static.exe >seq35_p5clike_opposite_direction.data
