#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGUUCUCGCAAGGGAGA&name=seq500&top=100"
./mcfold.static.exe >seq500_P5c.dada
