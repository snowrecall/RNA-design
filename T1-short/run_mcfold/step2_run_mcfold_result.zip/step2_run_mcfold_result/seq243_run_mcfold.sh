#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGUCCCGCAAGGGACA&name=seq243&top=100"
./mcfold.static.exe >seq243_P5c.dada
