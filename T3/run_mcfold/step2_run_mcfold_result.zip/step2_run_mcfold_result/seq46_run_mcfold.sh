#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=UGUUAUGGCAAUGUAAA&name=seq46&explore=50&top=100"
./mcfold.static.exe >seq46_like_p5c_shift_2bp_type3.data
