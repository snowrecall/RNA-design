#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUCUUUGCAAAGGGGA&name=seq317&top=100"
./mcfold.static.exe >seq317_p5clike_opposite_direction.data
