#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGUUUUUGCAAGAGGGA&name=seq535&top=100"
./mcfold.static.exe >seq535_P5c.dada
