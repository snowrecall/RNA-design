#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUUUCUGCAAAGGAGA&name=seq212&top=100"
./mcfold.static.exe >seq212_p5clike_opposite_direction.data
