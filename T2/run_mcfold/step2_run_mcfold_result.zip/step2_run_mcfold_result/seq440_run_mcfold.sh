#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGAAGGGCAACCUUUA&name=seq440&top=100"
./mcfold.static.exe >seq440_p5clike_opposite_direction.data
