#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGAGGCCGCAAGGUUUA&name=seq191&top=100"
./mcfold.static.exe >seq191_P5c.dada
