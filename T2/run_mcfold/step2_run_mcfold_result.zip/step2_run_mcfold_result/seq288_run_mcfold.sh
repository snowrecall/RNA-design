#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUCCCGGCAACGGGGA&name=seq288&top=100"
./mcfold.static.exe >seq288_p5clike_opposite_direction.data
