#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGGGGGCAACUCUUA&name=seq479&top=100"
./mcfold.static.exe >seq479_p5clike_opposite_direction.data
