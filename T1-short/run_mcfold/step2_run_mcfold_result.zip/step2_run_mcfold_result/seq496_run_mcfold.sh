#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGUUUUUGCAAGGAAGA&name=seq496&top=100"
./mcfold.static.exe >seq496_P5c.dada
