#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUUCCGGCAACGGGAA&name=seq92&top=100"
./mcfold.static.exe >seq92_p5clike_opposite_direction.data
