#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGGGGUGCAAGUCCCA&name=seq359&top=100"
./mcfold.static.exe >seq359_P5c.dada
