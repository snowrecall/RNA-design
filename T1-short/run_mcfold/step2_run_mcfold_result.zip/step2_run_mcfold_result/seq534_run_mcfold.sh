#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGUUUUCGCAAGAGGGA&name=seq534&top=100"
./mcfold.static.exe >seq534_P5c.dada
