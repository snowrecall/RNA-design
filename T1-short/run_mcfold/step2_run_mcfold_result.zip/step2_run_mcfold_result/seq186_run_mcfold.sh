#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGAGGUUGCAAGAUUUA&name=seq186&top=100"
./mcfold.static.exe >seq186_P5c.dada
