#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUGGGGGCAAUCUUAA&name=seq154&top=100"
./mcfold.static.exe >seq154_p5clike_opposite_direction.data
