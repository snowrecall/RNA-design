#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUUUCGGCAACGGAAA&name=seq27&top=100"
./mcfold.static.exe >seq27_p5clike_opposite_direction.data
