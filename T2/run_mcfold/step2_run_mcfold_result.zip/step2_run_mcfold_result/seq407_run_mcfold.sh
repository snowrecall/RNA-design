#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUUUCUGCAAGGGGGA&name=seq407&top=100"
./mcfold.static.exe >seq407_p5clike_opposite_direction.data
