#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGAGGCGCAAGCUUCA&name=seq294&top=100"
./mcfold.static.exe >seq294_P5c.dada
