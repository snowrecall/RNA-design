#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGAUUCCGCAAGGAGUA&name=seq112&top=100"
./mcfold.static.exe >seq112_P5c.dada
