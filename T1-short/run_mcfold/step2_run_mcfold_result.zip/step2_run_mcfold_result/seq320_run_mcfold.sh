#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGGUUUGCAAGAACCA&name=seq320&top=100"
./mcfold.static.exe >seq320_P5c.dada
