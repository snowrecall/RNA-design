#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGUUUCCGCAAGGGAAA&name=seq14&top=100"
./mcfold.static.exe >seq14_P5c.dada
