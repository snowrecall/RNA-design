#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGUCUUGCAAAGGACA&name=seq245&top=100"
./mcfold.static.exe >seq245_P5c.dada
