#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUUUAAGCAAUUGAAA&name=seq21&top=100"
./mcfold.static.exe >seq21_p5clike_opposite_direction.data
