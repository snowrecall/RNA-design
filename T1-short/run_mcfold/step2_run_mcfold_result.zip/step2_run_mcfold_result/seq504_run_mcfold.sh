#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGUUUCCGCAAGGGAGA&name=seq504&top=100"
./mcfold.static.exe >seq504_P5c.dada
