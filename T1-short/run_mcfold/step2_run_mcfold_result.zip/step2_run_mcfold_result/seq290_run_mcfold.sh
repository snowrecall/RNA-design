#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGAGCCGCAAGGUUCA&name=seq290&top=100"
./mcfold.static.exe >seq290_P5c.dada
