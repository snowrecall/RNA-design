#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUUCUGGCAACGGGGA&name=seq385&top=100"
./mcfold.static.exe >seq385_p5clike_opposite_direction.data
