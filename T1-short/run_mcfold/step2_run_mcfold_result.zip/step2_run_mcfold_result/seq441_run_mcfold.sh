#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGGGUCGCAAGACUCA&name=seq441&top=100"
./mcfold.static.exe >seq441_P5c.dada
