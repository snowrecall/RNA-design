#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUGGGAGCAAUUCCGA&name=seq334&top=100"
./mcfold.static.exe >seq334_p5clike_opposite_direction.data
