#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGCGCGACCGGAAGGGCAACUUUCAUUACGCGCC&name=seq29&top=100"
./mcfold.static.exe >seq29_5bp_267_GCstem_3nt_bulges.data
