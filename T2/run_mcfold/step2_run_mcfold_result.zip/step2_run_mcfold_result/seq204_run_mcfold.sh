#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUUGGGGCAACUCAGA&name=seq204&top=100"
./mcfold.static.exe >seq204_p5clike_opposite_direction.data
