#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGAACUGCAAGGUUCA&name=seq260&top=100"
./mcfold.static.exe >seq260_P5c.dada
