#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGCGCGCAUGGAAGGGCAACUUUCACCCCGCGCC&name=seq189&top=100"
./mcfold.static.exe >seq189_5bp_267_GCstem_3nt_bulges.data
