#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUGGGGGCAAUUUCAA&name=seq59&top=100"
./mcfold.static.exe >seq59_p5clike_opposite_direction.data
