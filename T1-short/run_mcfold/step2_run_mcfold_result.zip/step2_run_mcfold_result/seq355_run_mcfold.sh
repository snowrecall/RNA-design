#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGGGGUGCAAAUCCCA&name=seq355&top=100"
./mcfold.static.exe >seq355_P5c.dada
