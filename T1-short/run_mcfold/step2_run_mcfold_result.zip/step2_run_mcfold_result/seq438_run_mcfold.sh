#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGGCUCGCAAGGGUCA&name=seq438&top=100"
./mcfold.static.exe >seq438_P5c.dada
