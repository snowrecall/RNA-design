#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGUUUUGCAAAGAGCA&name=seq397&top=100"
./mcfold.static.exe >seq397_P5c.dada
