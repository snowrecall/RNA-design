#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUUUGAGCAAUUAAGA&name=seq198&top=100"
./mcfold.static.exe >seq198_p5clike_opposite_direction.data
