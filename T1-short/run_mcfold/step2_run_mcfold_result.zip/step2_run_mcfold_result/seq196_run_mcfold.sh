#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGAGGGGGCAACCUUUA&name=seq196&top=100"
./mcfold.static.exe >seq196_P5c.dada
