#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGAGGUCGCAAGACUUA&name=seq157&top=100"
./mcfold.static.exe >seq157_P5c.dada
