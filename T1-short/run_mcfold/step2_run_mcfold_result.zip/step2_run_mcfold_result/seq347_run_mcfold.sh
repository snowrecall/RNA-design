#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGGGAAGCAAUUCCCA&name=seq347&top=100"
./mcfold.static.exe >seq347_P5c.dada
