#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGAGUUCGCAAGGAUUA&name=seq135&top=100"
./mcfold.static.exe >seq135_P5c.dada
