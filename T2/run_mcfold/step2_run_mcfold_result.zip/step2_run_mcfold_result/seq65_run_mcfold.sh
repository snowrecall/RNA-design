#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUUUGGGCAAUCAGAA&name=seq65&top=100"
./mcfold.static.exe >seq65_p5clike_opposite_direction.data
