#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGUCUUUGCAAAGGGAA&name=seq28&top=100"
./mcfold.static.exe >seq28_P5c.dada
