#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGUUUUUGCAAGAGAAA&name=seq13&top=100"
./mcfold.static.exe >seq13_P5c.dada
