#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGAGGAAGCAAUUUUUA&name=seq187&top=100"
./mcfold.static.exe >seq187_P5c.dada
