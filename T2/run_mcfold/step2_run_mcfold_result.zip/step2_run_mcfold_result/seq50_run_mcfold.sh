#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUGGGGGCAACUCCAA&name=seq50&top=100"
./mcfold.static.exe >seq50_p5clike_opposite_direction.data
