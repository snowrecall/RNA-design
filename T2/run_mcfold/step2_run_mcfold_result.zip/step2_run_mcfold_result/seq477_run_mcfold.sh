#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGGGGGCAAUCCUUA&name=seq477&top=100"
./mcfold.static.exe >seq477_p5clike_opposite_direction.data
