#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGAGCUGCAAGGUUCA&name=seq291&top=100"
./mcfold.static.exe >seq291_P5c.dada
