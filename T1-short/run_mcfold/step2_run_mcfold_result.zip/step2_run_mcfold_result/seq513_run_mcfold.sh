#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGUCUUUGCAAAAGGGA&name=seq513&top=100"
./mcfold.static.exe >seq513_P5c.dada
