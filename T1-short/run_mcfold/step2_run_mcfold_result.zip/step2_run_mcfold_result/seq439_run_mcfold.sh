#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGGCUUGCAAGGGUCA&name=seq439&top=100"
./mcfold.static.exe >seq439_P5c.dada
