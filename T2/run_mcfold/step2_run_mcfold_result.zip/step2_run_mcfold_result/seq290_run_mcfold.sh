#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUCCCGGCAAUGGGGA&name=seq290&top=100"
./mcfold.static.exe >seq290_p5clike_opposite_direction.data
