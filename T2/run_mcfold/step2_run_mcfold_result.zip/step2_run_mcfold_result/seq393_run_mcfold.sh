#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUUGGAGCAAUUCGGA&name=seq393&top=100"
./mcfold.static.exe >seq393_p5clike_opposite_direction.data
