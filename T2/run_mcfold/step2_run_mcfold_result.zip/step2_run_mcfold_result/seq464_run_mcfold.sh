#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGGGGGCAACCUCUA&name=seq464&top=100"
./mcfold.static.exe >seq464_p5clike_opposite_direction.data
