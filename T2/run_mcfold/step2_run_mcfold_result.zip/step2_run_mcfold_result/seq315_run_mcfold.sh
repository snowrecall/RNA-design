#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUCUGGGCAACCGGGA&name=seq315&top=100"
./mcfold.static.exe >seq315_p5clike_opposite_direction.data
