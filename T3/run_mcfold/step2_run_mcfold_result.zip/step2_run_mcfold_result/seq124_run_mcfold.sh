#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=UGCAUUCGCAAGGGUGA&name=seq124&explore=50&top=100"
./mcfold.static.exe >seq124_like_p5c_shift_2bp_type3.data
