#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGCGCGCUCGGAAGGGCAACUUUCACCACGCGCC&name=seq126&top=100"
./mcfold.static.exe >seq126_5bp_267_GCstem_3nt_bulges.data
