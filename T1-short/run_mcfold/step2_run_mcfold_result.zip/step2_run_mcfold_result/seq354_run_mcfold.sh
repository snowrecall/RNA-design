#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGGGUUGCAAGGCCCA&name=seq354&top=100"
./mcfold.static.exe >seq354_P5c.dada
