#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGCGCGCCCGGAAGGGCAACUUUCACCCCGCGCC&name=seq216&top=100"
./mcfold.static.exe >seq216_5bp_267_GCstem_3nt_bulges.data
