#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUUUCAGCAAUGGAGA&name=seq213&top=100"
./mcfold.static.exe >seq213_p5clike_opposite_direction.data
