#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUAGGGGCAAUCCUGA&name=seq244&top=100"
./mcfold.static.exe >seq244_p5clike_opposite_direction.data
