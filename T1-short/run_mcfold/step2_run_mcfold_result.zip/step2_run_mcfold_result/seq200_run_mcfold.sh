#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGAGGUCGCAAGGUUUA&name=seq200&top=100"
./mcfold.static.exe >seq200_P5c.dada
