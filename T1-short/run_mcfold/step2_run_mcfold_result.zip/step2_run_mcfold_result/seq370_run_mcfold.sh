#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGGGUCGCAAGAUCCA&name=seq370&top=100"
./mcfold.static.exe >seq370_P5c.dada
