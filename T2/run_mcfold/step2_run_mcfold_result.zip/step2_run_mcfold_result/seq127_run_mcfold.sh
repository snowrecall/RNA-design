#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUUUUCGCAAGGGGAA&name=seq127&top=100"
./mcfold.static.exe >seq127_p5clike_opposite_direction.data
