#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUUCCGGCAAUGGGGA&name=seq380&top=100"
./mcfold.static.exe >seq380_p5clike_opposite_direction.data
