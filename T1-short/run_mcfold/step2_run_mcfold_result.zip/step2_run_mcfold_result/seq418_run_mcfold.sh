#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGGUUCGCAAGGAUCA&name=seq418&top=100"
./mcfold.static.exe >seq418_P5c.dada
