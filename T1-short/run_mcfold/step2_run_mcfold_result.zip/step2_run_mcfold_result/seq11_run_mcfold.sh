#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGUUUUUGCAAAAGAAA&name=seq11&top=100"
./mcfold.static.exe >seq11_P5c.dada
