#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGGGUUGCAAAGCUCA&name=seq454&top=100"
./mcfold.static.exe >seq454_P5c.dada
