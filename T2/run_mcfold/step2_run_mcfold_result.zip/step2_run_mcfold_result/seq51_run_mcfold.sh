#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUGGGGGCAAUUCCAA&name=seq51&top=100"
./mcfold.static.exe >seq51_p5clike_opposite_direction.data
