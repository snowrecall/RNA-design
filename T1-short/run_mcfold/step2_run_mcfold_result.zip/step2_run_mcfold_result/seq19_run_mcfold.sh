#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGUCCCUGCAAGGGGAA&name=seq19&top=100"
./mcfold.static.exe >seq19_P5c.dada
