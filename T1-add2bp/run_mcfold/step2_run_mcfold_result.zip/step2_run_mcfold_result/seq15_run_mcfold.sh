#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGGACAGGGCAACUUGUCUA&name=seq15&explore=50&top=100"
./mcfold.static.exe >seq15_5bp_267_add2bp_all_possible.data
