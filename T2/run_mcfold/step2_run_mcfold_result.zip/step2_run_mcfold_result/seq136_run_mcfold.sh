#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUUGGGGCAAUUUGAA&name=seq136&top=100"
./mcfold.static.exe >seq136_p5clike_opposite_direction.data
