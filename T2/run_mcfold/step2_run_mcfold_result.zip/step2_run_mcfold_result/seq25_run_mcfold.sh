#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUUUCAGCAAUGGAAA&name=seq25&top=100"
./mcfold.static.exe >seq25_p5clike_opposite_direction.data
