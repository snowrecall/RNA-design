#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGUUCCUGCAAGGGGAA&name=seq39&top=100"
./mcfold.static.exe >seq39_P5c.dada
