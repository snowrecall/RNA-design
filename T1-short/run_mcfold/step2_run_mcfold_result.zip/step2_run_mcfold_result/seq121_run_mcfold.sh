#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGAUCUUGCAAGGGGUA&name=seq121&top=100"
./mcfold.static.exe >seq121_P5c.dada
