#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGUUUCGCAAGGAACA&name=seq241&top=100"
./mcfold.static.exe >seq241_P5c.dada
