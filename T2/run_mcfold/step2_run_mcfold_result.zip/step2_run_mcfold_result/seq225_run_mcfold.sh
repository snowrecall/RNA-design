#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUUUUGGCAAUGGAGA&name=seq225&top=100"
./mcfold.static.exe >seq225_p5clike_opposite_direction.data
