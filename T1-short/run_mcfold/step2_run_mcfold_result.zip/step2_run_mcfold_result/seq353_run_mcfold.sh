#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGGGUCGCAAGGCCCA&name=seq353&top=100"
./mcfold.static.exe >seq353_P5c.dada
