#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGUCCUUGCAAGGGGAA&name=seq22&top=100"
./mcfold.static.exe >seq22_P5c.dada
