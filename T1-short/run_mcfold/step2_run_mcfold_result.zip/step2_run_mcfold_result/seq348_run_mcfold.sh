#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGGGACGCAAGUCCCA&name=seq348&top=100"
./mcfold.static.exe >seq348_P5c.dada
