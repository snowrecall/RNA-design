#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUGAGGGCAAUCUUGA&name=seq422&top=100"
./mcfold.static.exe >seq422_p5clike_opposite_direction.data
