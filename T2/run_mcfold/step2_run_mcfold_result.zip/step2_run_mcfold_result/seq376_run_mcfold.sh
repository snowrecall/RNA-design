#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUUCCAGCAAUGGGGA&name=seq376&top=100"
./mcfold.static.exe >seq376_p5clike_opposite_direction.data
