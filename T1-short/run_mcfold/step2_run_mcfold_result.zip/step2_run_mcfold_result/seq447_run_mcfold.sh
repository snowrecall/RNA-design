#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGGGCCGCAAGGCUCA&name=seq447&top=100"
./mcfold.static.exe >seq447_P5c.dada
