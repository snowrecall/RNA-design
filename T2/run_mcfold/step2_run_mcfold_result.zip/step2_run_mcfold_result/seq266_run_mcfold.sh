#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUCUUUGCAAGGAGGA&name=seq266&top=100"
./mcfold.static.exe >seq266_p5clike_opposite_direction.data
