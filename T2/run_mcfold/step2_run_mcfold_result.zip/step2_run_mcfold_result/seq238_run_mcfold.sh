#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUAAGGGCAACCUUGA&name=seq238&top=100"
./mcfold.static.exe >seq238_p5clike_opposite_direction.data
