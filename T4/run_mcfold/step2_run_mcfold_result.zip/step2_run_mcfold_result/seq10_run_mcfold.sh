#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGGGGUGCUUCGGCCUUUCC&name=seq10&explore=50&top=100"
./mcfold.static.exe >seq10_p5clike_1bulgeout.data
