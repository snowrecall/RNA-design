#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGGGAGCAAUUUCUA&name=seq465&top=100"
./mcfold.static.exe >seq465_p5clike_opposite_direction.data
