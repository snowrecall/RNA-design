#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGACUUCGCAAGGGGUA&name=seq107&top=100"
./mcfold.static.exe >seq107_P5c.dada
