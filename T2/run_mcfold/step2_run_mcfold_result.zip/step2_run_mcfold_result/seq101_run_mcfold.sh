#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUUCUGGCAAUGGGAA&name=seq101&top=100"
./mcfold.static.exe >seq101_p5clike_opposite_direction.data
