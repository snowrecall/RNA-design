#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGGAAAGCAAUUUCCA&name=seq326&top=100"
./mcfold.static.exe >seq326_P5c.dada
