#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUCAAAGCAAUUUGGA&name=seq271&top=100"
./mcfold.static.exe >seq271_p5clike_opposite_direction.data
