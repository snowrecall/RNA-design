#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGAAGGCAACUUCA&name=seq4&top=100"
./mcfold.static.exe >seq4_5bp_267_minus1bp_all_possible.data
