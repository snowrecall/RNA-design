#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGUUUCGCAAGAGGCA&name=seq406&top=100"
./mcfold.static.exe >seq406_P5c.dada
