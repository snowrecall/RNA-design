#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGUUCUGCAAGGAAUA&name=seq541&top=100"
./mcfold.static.exe >seq541_P5c.dada
