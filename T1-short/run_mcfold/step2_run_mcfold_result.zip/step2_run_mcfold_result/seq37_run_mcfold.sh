#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGUUUUUGCAAGGAGAA&name=seq37&top=100"
./mcfold.static.exe >seq37_P5c.dada
