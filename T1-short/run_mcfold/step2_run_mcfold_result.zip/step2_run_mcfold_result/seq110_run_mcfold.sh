#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGAUUUCGCAAGAAGUA&name=seq110&top=100"
./mcfold.static.exe >seq110_P5c.dada
