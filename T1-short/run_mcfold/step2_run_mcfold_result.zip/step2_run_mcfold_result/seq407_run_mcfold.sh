#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGUUUUGCAAGAGGCA&name=seq407&top=100"
./mcfold.static.exe >seq407_P5c.dada
