#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGGGGAGCAAUCCUCA&name=seq449&top=100"
./mcfold.static.exe >seq449_P5c.dada
