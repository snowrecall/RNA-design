#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUUGGAGCAAUUCAGA&name=seq203&top=100"
./mcfold.static.exe >seq203_p5clike_opposite_direction.data
