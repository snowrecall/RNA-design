#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGCUUUCGCAAGAAGGA&name=seq218&top=100"
./mcfold.static.exe >seq218_P5c.dada
