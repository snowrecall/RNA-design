#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGGAGCGCAAGUUUCA&name=seq431&top=100"
./mcfold.static.exe >seq431_P5c.dada
