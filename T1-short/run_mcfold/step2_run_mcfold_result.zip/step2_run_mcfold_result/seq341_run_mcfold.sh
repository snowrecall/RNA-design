#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGGCUUGCAAAGGCCA&name=seq341&top=100"
./mcfold.static.exe >seq341_P5c.dada
