#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGAGAAAGCAAUUUUUA&name=seq137&top=100"
./mcfold.static.exe >seq137_P5c.dada
