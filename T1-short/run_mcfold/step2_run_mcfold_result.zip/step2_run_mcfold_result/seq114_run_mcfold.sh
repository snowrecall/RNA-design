#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGAUUUUGCAAAGAGUA&name=seq114&top=100"
./mcfold.static.exe >seq114_P5c.dada
