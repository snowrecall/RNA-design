#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGGGGGGCAACCUUCA&name=seq480&top=100"
./mcfold.static.exe >seq480_P5c.dada
