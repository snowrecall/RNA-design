#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGAUCCGCAAGGGUCA&name=seq278&top=100"
./mcfold.static.exe >seq278_P5c.dada
