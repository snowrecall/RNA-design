#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGAUUCGCAAGAGUCA&name=seq276&top=100"
./mcfold.static.exe >seq276_P5c.dada
