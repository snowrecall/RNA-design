#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGGGGGGCAAUCCUCA&name=seq453&top=100"
./mcfold.static.exe >seq453_P5c.dada
