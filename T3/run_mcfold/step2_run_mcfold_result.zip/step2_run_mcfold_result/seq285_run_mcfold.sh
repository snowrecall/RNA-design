#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGAUGCGCAAGUGUCA&name=seq285&explore=50&top=100"
./mcfold.static.exe >seq285_like_p5c_shift_2bp_type3.data
