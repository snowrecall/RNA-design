#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGCGCGCCUGGAAGGGCAACUUUCACAACGCGCC&name=seq129&top=100"
./mcfold.static.exe >seq129_5bp_267_GCstem_3nt_bulges.data
