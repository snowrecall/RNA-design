#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUGGGGGCAACUUCGA&name=seq343&top=100"
./mcfold.static.exe >seq343_p5clike_opposite_direction.data
