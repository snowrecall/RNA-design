#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUGAGGGCAACUUUAA&name=seq143&top=100"
./mcfold.static.exe >seq143_p5clike_opposite_direction.data
