#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGCGCGCCCGGAAGGGCAACUUUCAUAACGCGCC&name=seq131&top=100"
./mcfold.static.exe >seq131_5bp_267_GCstem_3nt_bulges.data
