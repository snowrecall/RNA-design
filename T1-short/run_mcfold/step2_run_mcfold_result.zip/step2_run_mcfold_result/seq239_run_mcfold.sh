#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGUUCUGCAAGGAACA&name=seq239&top=100"
./mcfold.static.exe >seq239_P5c.dada
