#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGGGGUGCAAACCUCA&name=seq448&top=100"
./mcfold.static.exe >seq448_P5c.dada
