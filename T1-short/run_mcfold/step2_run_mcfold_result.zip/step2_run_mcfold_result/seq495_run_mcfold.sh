#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGUUUUCGCAAGGAAGA&name=seq495&top=100"
./mcfold.static.exe >seq495_P5c.dada
