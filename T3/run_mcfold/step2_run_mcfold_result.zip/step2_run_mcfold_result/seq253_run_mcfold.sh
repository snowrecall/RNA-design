#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGUAUAGCAAUGUACA&name=seq253&explore=50&top=100"
./mcfold.static.exe >seq253_like_p5c_shift_2bp_type3.data
