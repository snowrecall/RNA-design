#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGGGGCGCAAGUCCCA&name=seq357&top=100"
./mcfold.static.exe >seq357_P5c.dada
