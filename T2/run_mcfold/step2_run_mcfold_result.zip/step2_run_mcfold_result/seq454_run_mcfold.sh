#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGAGGAGCAAUUUUUA&name=seq454&top=100"
./mcfold.static.exe >seq454_p5clike_opposite_direction.data
