#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGGAUUGCAAGGUCCA&name=seq319&explore=50&top=100"
./mcfold.static.exe >seq319_like_p5c_shift_2bp_type3.data
