#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUUUUAGCAAUGGAAA&name=seq33&top=100"
./mcfold.static.exe >seq33_p5clike_opposite_direction.data
