#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUUUCAGCAAUGGGGA&name=seq404&top=100"
./mcfold.static.exe >seq404_p5clike_opposite_direction.data
