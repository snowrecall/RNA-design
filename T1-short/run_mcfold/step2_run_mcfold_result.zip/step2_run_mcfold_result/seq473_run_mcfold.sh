#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGGGAUGCAAGUUUCA&name=seq473&top=100"
./mcfold.static.exe >seq473_P5c.dada
