#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUUGGGGCAACCCGAA&name=seq105&top=100"
./mcfold.static.exe >seq105_p5clike_opposite_direction.data
