#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUUUUGGCAACGAAAA&name=seq6&top=100"
./mcfold.static.exe >seq6_p5clike_opposite_direction.data
