#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGGGAAGGGCAACUUUCUCA&name=seq22&explore=50&top=100"
./mcfold.static.exe >seq22_5bp_267_add2bp_all_possible.data
