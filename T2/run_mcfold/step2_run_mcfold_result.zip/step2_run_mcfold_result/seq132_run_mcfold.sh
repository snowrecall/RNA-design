#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUUGGGGCAACCUGAA&name=seq132&top=100"
./mcfold.static.exe >seq132_p5clike_opposite_direction.data
