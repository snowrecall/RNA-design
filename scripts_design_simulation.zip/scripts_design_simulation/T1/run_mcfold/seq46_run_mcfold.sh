#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGCGCGAACGGAAGGGCAACUUUCAACCCGCGCC&name=seq46&top=100"
./mcfold.static.exe >seq46_5bp_267_GCstem_3nt_bulges.data
