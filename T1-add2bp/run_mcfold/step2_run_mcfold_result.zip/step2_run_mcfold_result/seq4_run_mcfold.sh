#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGGAAAGGGCAACUUUUCUA&name=seq4&explore=50&top=100"
./mcfold.static.exe >seq4_5bp_267_add2bp_all_possible.data
