#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUUCUUGCAAGAGGGA&name=seq370&top=100"
./mcfold.static.exe >seq370_p5clike_opposite_direction.data
