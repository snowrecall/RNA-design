#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGAGAGGGCAACUUUUA&name=seq148&top=100"
./mcfold.static.exe >seq148_P5c.dada
