#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGAAAUUGCAAAGUUUA&name=seq52&top=100"
./mcfold.static.exe >seq52_P5c.dada
