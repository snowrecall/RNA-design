#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGCGCGAACGGAAGGGCAACUUUCAUCACGCGCC&name=seq11&top=100"
./mcfold.static.exe >seq11_5bp_267_GCstem_3nt_bulges.data
