#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUUGGAGCAAUUCAAA&name=seq14&top=100"
./mcfold.static.exe >seq14_p5clike_opposite_direction.data
