#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGAGGGUGCAAACCUUA&name=seq164&top=100"
./mcfold.static.exe >seq164_P5c.dada
