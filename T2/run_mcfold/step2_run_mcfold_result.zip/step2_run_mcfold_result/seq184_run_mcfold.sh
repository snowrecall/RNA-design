#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGGGGGCAAUCUUCA&name=seq184&top=100"
./mcfold.static.exe >seq184_p5clike_opposite_direction.data
