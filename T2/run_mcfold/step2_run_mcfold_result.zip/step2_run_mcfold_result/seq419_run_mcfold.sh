#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUGAAGGCAACUUUGA&name=seq419&top=100"
./mcfold.static.exe >seq419_p5clike_opposite_direction.data
