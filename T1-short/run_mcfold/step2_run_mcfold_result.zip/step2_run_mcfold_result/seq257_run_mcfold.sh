#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGAAAUGCAAGUUUCA&name=seq257&top=100"
./mcfold.static.exe >seq257_P5c.dada
