#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGAGCCUGCAAGGGUUA&name=seq152&top=100"
./mcfold.static.exe >seq152_P5c.dada
