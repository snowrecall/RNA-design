#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUCAGGGCAACCUGGA&name=seq274&top=100"
./mcfold.static.exe >seq274_p5clike_opposite_direction.data
