#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUUUGGGCAACUGAGA&name=seq226&top=100"
./mcfold.static.exe >seq226_p5clike_opposite_direction.data
