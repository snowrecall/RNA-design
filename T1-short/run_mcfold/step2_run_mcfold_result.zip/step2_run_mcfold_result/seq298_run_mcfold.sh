#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGAGUCGCAAGGUUCA&name=seq298&top=100"
./mcfold.static.exe >seq298_P5c.dada
