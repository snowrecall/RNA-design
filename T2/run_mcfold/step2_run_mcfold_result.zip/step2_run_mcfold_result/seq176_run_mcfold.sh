#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGGGGGCAACCCUCA&name=seq176&top=100"
./mcfold.static.exe >seq176_p5clike_opposite_direction.data
