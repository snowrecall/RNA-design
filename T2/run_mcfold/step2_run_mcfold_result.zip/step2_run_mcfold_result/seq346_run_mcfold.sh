#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUUUUGGCAACAAGGA&name=seq346&top=100"
./mcfold.static.exe >seq346_p5clike_opposite_direction.data
