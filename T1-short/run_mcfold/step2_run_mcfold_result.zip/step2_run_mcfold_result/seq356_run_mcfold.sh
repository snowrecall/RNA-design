#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGGGGAGCAAUUCCCA&name=seq356&top=100"
./mcfold.static.exe >seq356_P5c.dada
