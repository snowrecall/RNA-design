#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=UGUCCUUGCAAGGGGAA&name=seq74&explore=50&top=100"
./mcfold.static.exe >seq74_like_p5c_shift_2bp_type3.data
