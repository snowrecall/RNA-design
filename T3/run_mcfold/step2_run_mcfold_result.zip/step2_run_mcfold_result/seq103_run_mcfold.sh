#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=UGUGGGGGCAACUUCAA&name=seq103&explore=50&top=100"
./mcfold.static.exe >seq103_like_p5c_shift_2bp_type3.data
