#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGAAAUUGCAAGGUUUA&name=seq54&top=100"
./mcfold.static.exe >seq54_P5c.dada
