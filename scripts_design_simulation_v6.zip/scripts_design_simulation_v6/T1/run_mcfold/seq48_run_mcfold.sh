#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGCGCGAACGGAAGGGCAACUUUCACCCCGCGCC&name=seq48&top=100"
./mcfold.static.exe >seq48_5bp_267_GCstem_3nt_bulges.data
