#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGAUCUGCAAGGGUCA&name=seq279&top=100"
./mcfold.static.exe >seq279_P5c.dada
