#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUAGAAGCAAUUUUGA&name=seq248&top=100"
./mcfold.static.exe >seq248_p5clike_opposite_direction.data
