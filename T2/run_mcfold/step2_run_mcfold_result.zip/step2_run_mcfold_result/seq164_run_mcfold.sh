#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGGGGGCAAUCUCCA&name=seq164&top=100"
./mcfold.static.exe >seq164_p5clike_opposite_direction.data
