#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUUUGAGCAAUUAGAA&name=seq71&top=100"
./mcfold.static.exe >seq71_p5clike_opposite_direction.data
