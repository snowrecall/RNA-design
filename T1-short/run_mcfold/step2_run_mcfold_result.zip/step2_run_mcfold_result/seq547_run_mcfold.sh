#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGUCUUGCAAAGGAUA&name=seq547&top=100"
./mcfold.static.exe >seq547_P5c.dada
