#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGUCCCGCAAGGGGCA&name=seq400&top=100"
./mcfold.static.exe >seq400_P5c.dada
