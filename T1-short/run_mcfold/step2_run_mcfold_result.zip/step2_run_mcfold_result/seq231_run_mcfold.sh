#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGCUUUUGCAAGAGGGA&name=seq231&top=100"
./mcfold.static.exe >seq231_P5c.dada
