#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUUUUUGCAAGAGGAA&name=seq112&top=100"
./mcfold.static.exe >seq112_p5clike_opposite_direction.data
