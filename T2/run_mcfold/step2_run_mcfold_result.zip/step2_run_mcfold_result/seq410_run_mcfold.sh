#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUUUGGGCAAUCGGGA&name=seq410&top=100"
./mcfold.static.exe >seq410_p5clike_opposite_direction.data
