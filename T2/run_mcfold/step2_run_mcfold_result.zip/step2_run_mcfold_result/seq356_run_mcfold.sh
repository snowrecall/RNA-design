#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUUUUGGCAAUGAGGA&name=seq356&top=100"
./mcfold.static.exe >seq356_p5clike_opposite_direction.data
