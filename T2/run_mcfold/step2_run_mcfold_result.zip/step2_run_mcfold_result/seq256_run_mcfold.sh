#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUCUUUGCAAAAAGGA&name=seq256&top=100"
./mcfold.static.exe >seq256_p5clike_opposite_direction.data
