#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGAAAGUGCUUCGGCCUUUUC&name=seq11&explore=50&top=100"
./mcfold.static.exe >seq11_p5clike_1bulgeout.data
