#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGCGCGACCGGAAGGGCAACUUUCAAACCGCGCC&name=seq58&top=100"
./mcfold.static.exe >seq58_5bp_267_GCstem_3nt_bulges.data
