#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUUCCAGCAAUGGGAA&name=seq90&top=100"
./mcfold.static.exe >seq90_p5clike_opposite_direction.data
