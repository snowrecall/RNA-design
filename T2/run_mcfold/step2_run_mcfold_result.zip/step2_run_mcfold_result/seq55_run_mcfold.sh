#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUGGGGGCAACCUCAA&name=seq55&top=100"
./mcfold.static.exe >seq55_p5clike_opposite_direction.data
