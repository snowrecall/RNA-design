#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGGAACGGGCAACUGUUCUA&name=seq5&explore=50&top=100"
./mcfold.static.exe >seq5_5bp_267_add2bp_all_possible.data
