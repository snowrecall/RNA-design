#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGUUCUUGCAAGGGGAA&name=seq42&top=100"
./mcfold.static.exe >seq42_P5c.dada
