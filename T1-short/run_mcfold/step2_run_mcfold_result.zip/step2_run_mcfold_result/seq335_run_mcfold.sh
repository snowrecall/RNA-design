#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGGAGUGCAAAUUCCA&name=seq335&top=100"
./mcfold.static.exe >seq335_P5c.dada
