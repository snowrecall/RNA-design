#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGCGCGCCAGGAAGGGCAACUUUCACUACGCGCC&name=seq134&top=100"
./mcfold.static.exe >seq134_5bp_267_GCstem_3nt_bulges.data
