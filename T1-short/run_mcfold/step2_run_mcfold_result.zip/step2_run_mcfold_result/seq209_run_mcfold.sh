#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGCCUUUGCAAAAGGGA&name=seq209&top=100"
./mcfold.static.exe >seq209_P5c.dada
