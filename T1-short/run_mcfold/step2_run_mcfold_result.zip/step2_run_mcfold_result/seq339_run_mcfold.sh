#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGGAGUGCAAGUUCCA&name=seq339&top=100"
./mcfold.static.exe >seq339_P5c.dada
