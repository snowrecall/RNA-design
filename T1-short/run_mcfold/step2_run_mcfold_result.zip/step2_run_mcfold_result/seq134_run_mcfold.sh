#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGAGUUUGCAAAGAUUA&name=seq134&top=100"
./mcfold.static.exe >seq134_P5c.dada
