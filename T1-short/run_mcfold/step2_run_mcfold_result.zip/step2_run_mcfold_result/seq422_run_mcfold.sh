#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGGAAUGCAAGUUUCA&name=seq422&top=100"
./mcfold.static.exe >seq422_P5c.dada
