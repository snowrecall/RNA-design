#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGUUUUGCAAAAGACA&name=seq248&top=100"
./mcfold.static.exe >seq248_P5c.dada
