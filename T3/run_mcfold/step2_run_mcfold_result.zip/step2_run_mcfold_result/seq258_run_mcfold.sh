#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGUCUUGCAAGGGACA&name=seq258&explore=50&top=100"
./mcfold.static.exe >seq258_like_p5c_shift_2bp_type3.data
