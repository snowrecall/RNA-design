#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGCGCGAACGGAAGGGCAACUUUCAUCCCGCGCC&name=seq47&top=100"
./mcfold.static.exe >seq47_5bp_267_GCstem_3nt_bulges.data
