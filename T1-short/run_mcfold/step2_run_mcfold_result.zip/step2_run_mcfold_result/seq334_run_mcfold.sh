#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGGAUUGCAAGGUCCA&name=seq334&top=100"
./mcfold.static.exe >seq334_P5c.dada
