#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUUCCGGCAAUGGGAA&name=seq94&top=100"
./mcfold.static.exe >seq94_p5clike_opposite_direction.data
