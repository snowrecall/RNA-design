#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGCGCGCCCGGAAGGGCAACUUUCAAAACGCGCC&name=seq130&top=100"
./mcfold.static.exe >seq130_5bp_267_GCstem_3nt_bulges.data
