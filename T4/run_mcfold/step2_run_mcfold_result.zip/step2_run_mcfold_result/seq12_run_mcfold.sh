#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGAAGGUGCUUCGGCCCUUUC&name=seq12&explore=50&top=100"
./mcfold.static.exe >seq12_p5clike_1bulgeout.data
