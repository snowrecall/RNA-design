#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGCGCGACAGGAAGGGCAACUUUCAAAACGCGCC&name=seq19&top=100"
./mcfold.static.exe >seq19_5bp_267_GCstem_3nt_bulges.data
