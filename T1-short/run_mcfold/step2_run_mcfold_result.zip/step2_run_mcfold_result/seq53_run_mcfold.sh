#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGAAAUCGCAAGGUUUA&name=seq53&top=100"
./mcfold.static.exe >seq53_P5c.dada
