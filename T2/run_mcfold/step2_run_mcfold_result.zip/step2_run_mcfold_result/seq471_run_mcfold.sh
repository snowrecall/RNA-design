#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGAGGGCAACCUUUA&name=seq471&top=100"
./mcfold.static.exe >seq471_p5clike_opposite_direction.data
