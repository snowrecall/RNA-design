#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGUUUCUGCAAGGGAGA&name=seq505&top=100"
./mcfold.static.exe >seq505_P5c.dada
