#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGAGGGGCAAUUUUCA&name=seq305&top=100"
./mcfold.static.exe >seq305_P5c.dada
