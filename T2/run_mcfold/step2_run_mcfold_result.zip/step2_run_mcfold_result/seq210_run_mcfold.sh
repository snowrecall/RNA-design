#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUUUAGGCAACUGAGA&name=seq210&top=100"
./mcfold.static.exe >seq210_p5clike_opposite_direction.data
