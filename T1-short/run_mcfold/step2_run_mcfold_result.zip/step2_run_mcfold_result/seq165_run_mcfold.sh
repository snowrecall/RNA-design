#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGAGGGAGCAAUCCUUA&name=seq165&top=100"
./mcfold.static.exe >seq165_P5c.dada
