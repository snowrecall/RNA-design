#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGGGUUGCAAAACCCA&name=seq344&top=100"
./mcfold.static.exe >seq344_P5c.dada
