#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUUGGGGCAAUUUAGA&name=seq235&top=100"
./mcfold.static.exe >seq235_p5clike_opposite_direction.data
