#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGCGCGCUAGGAAGGGCAACUUUCAACACGCGCC&name=seq121&top=100"
./mcfold.static.exe >seq121_5bp_267_GCstem_3nt_bulges.data
