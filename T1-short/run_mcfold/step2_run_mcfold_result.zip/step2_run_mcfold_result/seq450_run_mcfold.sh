#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGGGGCGCAAGCCUCA&name=seq450&top=100"
./mcfold.static.exe >seq450_P5c.dada
