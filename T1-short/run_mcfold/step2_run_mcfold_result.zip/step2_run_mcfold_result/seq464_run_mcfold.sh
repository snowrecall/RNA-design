#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGGUUUGCAAGAGUCA&name=seq464&top=100"
./mcfold.static.exe >seq464_P5c.dada
