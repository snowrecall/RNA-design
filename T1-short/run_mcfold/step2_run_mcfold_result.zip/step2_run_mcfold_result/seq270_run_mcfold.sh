#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGACCCGCAAGGGUCA&name=seq270&top=100"
./mcfold.static.exe >seq270_P5c.dada
