#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGGUUUGCAAAAAUCA&name=seq412&top=100"
./mcfold.static.exe >seq412_P5c.dada
