#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGAAGGGCAAUUUUUA&name=seq444&top=100"
./mcfold.static.exe >seq444_p5clike_opposite_direction.data
