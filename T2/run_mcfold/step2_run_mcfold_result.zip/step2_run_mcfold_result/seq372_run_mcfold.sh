#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUUCAAGCAAUUGGGA&name=seq372&top=100"
./mcfold.static.exe >seq372_p5clike_opposite_direction.data
