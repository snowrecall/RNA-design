#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGGGUUGCAAGACCCA&name=seq346&top=100"
./mcfold.static.exe >seq346_P5c.dada
