#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGUUCUUGCAAAGGGGA&name=seq530&top=100"
./mcfold.static.exe >seq530_P5c.dada
