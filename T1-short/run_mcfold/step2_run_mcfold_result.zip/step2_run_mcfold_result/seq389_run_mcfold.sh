#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGGGGGGCAACUUCCA&name=seq389&top=100"
./mcfold.static.exe >seq389_P5c.dada
