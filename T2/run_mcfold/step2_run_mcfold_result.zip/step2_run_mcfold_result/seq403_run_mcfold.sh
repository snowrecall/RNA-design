#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUUUCUGCAAAGGGGA&name=seq403&top=100"
./mcfold.static.exe >seq403_p5clike_opposite_direction.data
