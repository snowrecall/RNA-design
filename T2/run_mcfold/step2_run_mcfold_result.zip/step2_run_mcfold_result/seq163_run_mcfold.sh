#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGGGGGCAACCUCCA&name=seq163&top=100"
./mcfold.static.exe >seq163_p5clike_opposite_direction.data
