#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGGAAGCAAUUUUCA&name=seq180&top=100"
./mcfold.static.exe >seq180_p5clike_opposite_direction.data
