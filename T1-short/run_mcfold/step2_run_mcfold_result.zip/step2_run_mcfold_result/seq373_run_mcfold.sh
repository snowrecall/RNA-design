#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGGGACGCAAGUUCCA&name=seq373&top=100"
./mcfold.static.exe >seq373_P5c.dada
