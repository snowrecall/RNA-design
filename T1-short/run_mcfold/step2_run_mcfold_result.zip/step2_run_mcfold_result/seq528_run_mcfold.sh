#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGUUCCCGCAAGGGGGA&name=seq528&top=100"
./mcfold.static.exe >seq528_P5c.dada
