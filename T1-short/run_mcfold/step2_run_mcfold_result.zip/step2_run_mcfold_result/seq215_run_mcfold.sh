#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGCCUUCGCAAGGGGGA&name=seq215&top=100"
./mcfold.static.exe >seq215_P5c.dada
