#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGAGGGGCAACUCUUA&name=seq448&top=100"
./mcfold.static.exe >seq448_p5clike_opposite_direction.data
