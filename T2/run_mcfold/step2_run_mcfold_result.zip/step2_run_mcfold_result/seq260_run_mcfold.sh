#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUCUGGGCAACCAGGA&name=seq260&top=100"
./mcfold.static.exe >seq260_p5clike_opposite_direction.data
