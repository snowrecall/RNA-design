#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GUCCGGGCAACUGGGA&name=seq299&top=100"
./mcfold.static.exe >seq299_p5clike_opposite_direction.data
