#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGAGGGGCAACCUUCA&name=seq295&top=100"
./mcfold.static.exe >seq295_P5c.dada
