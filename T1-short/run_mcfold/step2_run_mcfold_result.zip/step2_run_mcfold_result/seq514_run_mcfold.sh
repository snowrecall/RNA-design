#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGUCUUCGCAAGAGGGA&name=seq514&top=100"
./mcfold.static.exe >seq514_P5c.dada
