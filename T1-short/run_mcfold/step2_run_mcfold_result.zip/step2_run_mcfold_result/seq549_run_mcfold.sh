#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGGUCUUGCAAGGGAUA&name=seq549&top=100"
./mcfold.static.exe >seq549_P5c.dada
