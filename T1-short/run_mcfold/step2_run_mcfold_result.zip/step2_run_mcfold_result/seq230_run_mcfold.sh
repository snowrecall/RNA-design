#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGCUUUCGCAAGAGGGA&name=seq230&top=100"
./mcfold.static.exe >seq230_P5c.dada
