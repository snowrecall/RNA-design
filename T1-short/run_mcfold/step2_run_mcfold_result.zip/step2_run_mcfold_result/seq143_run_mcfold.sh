#!/bin/csh
setenv QUERY_STRING "pass=lucy&sequence=GGAGAUUGCAAAGUUUA&name=seq143&top=100"
./mcfold.static.exe >seq143_P5c.dada
